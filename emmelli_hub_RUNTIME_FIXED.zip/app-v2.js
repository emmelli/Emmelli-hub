(()=>{"use strict";
function budgetOccurrenceAmountV125(row){
  if(!row)return 0;
  try{
    const key=typeof autopayKey==='function'?autopayKey(row):(row.key||'');
    const ev=state?.budget?.paymentEvents?.[key];
    if(key&&state?.checks?.[key]&&ev&&Number.isFinite(Number(ev.amount)))return Math.round(Number(ev.amount)*100)/100;
  }catch(e){}
  return Math.round(Number(row.a||row.amount||0)*100)/100;
}
const CURRENT_BUILD="2026-10-01-PERMANENT-V14-PAGE-CONTRACT";
const GOALS_COMMENTARY_RULE_V15="ALL unfinished goals through the selected day surface in Today Commentary until completed; Important only affects emphasis.";
const CURRENT_PAGE_CONTRACT_V14={today:"routine faith goals school weigh-in food inventory contextual receipt-readiness",food:"today-food meal-plan inventory monday-grocery cook-days",gym:"day-plan run body-progress",budget:"income autopays emergency week-by-week",history:"year month week day",wish:"categories items totals"};
const DAYS=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"];
const STUDY={Monday:"TEAS Science",Tuesday:"TEAS Math",Wednesday:"PERT Math",Thursday:"TEAS Reading",Friday:"TEAS Science / weak areas",Saturday:"PERT Reading",Sunday:"TEAS English"};

const CARE_MORNING_BASE=["RETAINER OUT - LEAVE TO SOAK","ORAL CARE","WATER FLOSS","BRUSH","TONGUE BRUSH","STRING FLOSS","LIP STAIN","GUA SHA","SKINCARE","CLEANSER","MEDICUBE TONER PAD","SNAIL MUCIN","PROBIOTIC CICA","MOISTURIZER","SPF","CLEAN EARS","PINK CREAM + UREA","COLLARS + REMOTES","PUT ON RETAINER","DISINFECT PHONE","HAND / NAIL CARE","CLEAN UNDER NAILS / HAND SCRUB","CUTICLE OIL / LOTION","GET DRESSED","HAIR","TAKE OUT / STYLE","OIL ENDS","MINOXIDIL","CASTOR OIL","DEODORANT & PERFUME","JEWELRY","FAJA"];
const CARE_NIGHT_BASE=["RETAINER OUT","GRAB PAJAMAS / TOWEL / EYE MASK / EAR PLUGS","SHOWER","LOTION AND OIL","ORAL CARE","WATER FLOSS","BRUSH","TONGUE BRUSH","STRING FLOSS","LIP STAIN","GUA SHA","SKINCARE","CLEANSER","SNAIL MUCIN","PROBIOTIC CICA","MOISTURIZER","CLEAN EARS","HAIR","OIL ENDS","MINOXIDIL","CASTOR OIL","SLEEP HAIR","PINK CREAM + UREA","COLLARS + REMOTES","PUT ON RETAINER","SET OUT NEXT DAY'S OUTFIT","SWITCH OUT TOWELS","DISINFECT PHONE","HAND / NAIL CARE","CLEAN UNDER NAILS / HAND SCRUB","CUTICLE OIL / LOTION","CHARGE ALL DEVICES","DEODORANT & PERFUME"];
function careItems(d,kind){let a=(kind==="morning"?CARE_MORNING_BASE:CARE_NIGHT_BASE).slice(),brighteningDay=["Wednesday","Friday"].includes(d);if(brighteningDay){let i=a.indexOf("PROBIOTIC CICA");a.splice(i,0,"BRIGHTENING SERUM")}if(kind==="night"&&brighteningDay){let i=a.indexOf("SHOWER");if(i>=0)a[i]="SHOWER AND WASH HAIR"}return a}

const ROUTINE={
"Monday":["GET OUT OF BED — 16 min","MORNING START — 5 min","MORNING START #2 — 5 min","PET TIME — 5 min","MORNING ROUTINE — 20 min","WHERE ARE YOU EMMELLI? — 15 min","MAKE & EAT BREAKFAST — 30 min","LAUNDRY & PET CARE — 5 min","WALK THING 1 — 20 min","PET CARE — 2 min","WALK THING 2 — 20 min","PET CARE — 2 min","MASK — 15 min","REPTAR RESET — 20 min","HOME RESET #1 — 10 min","HOME RESET #2 — 10 min","SHOE CLEANING — 30 min","TEST PRACTICE — 30 min","PIANO PRACTICE — 45 min","LAUNDRY — 10 min","DRIVE TO GYM — 15 min","GYM — 60 min","DRIVE HOME FROM GYM — 15 min","APARTMENT GYM AB CIRCUIT — 15 min","TREADMILL WALK — 30 min","MORNING CARE / SHOWER & GET READY — 30 min","DRIVE TO DETWILER’S — 25 min","GROCERY SHOPPING — 30 min","DRIVE TO REPTILE STORE — 5 min","REPTILE STORE — 5 min","DRIVE HOME — 25 min","PUT AWAY GROCERIES AND PORTION MEAT — 20 min","KITCHEN RESET — 90 min","WALK THING 1 — 20 min","WALK THING 2 — 20 min","SHOWER & GET READY — 30 min","DRIVE TO BIBLE STUDY — 30 min","BIBLE STUDY — 90 min","DRIVE HOME — 30 min","NIGHT RESET — 15 min","NIGHT CARE AND SHOWER — 30 min","FINAL — 15 min"],
"Tuesday":["GET OUT OF BED — 16 min","MORNING START — 5 min","MORNING START #2 — 5 min","PET TIME — 5 min","MORNING ROUTINE — 20 min","WHERE ARE YOU EMMELLI? — 15 min","MAKE & EAT BREAKFAST — 30 min","LAUNDRY & PET CARE — 5 min","WALK THING 1 — 20 min","PET CARE — 2 min","WALK THING 2 — 20 min","PET CARE — 2 min","LAUNDRY — 10 min","MORNING CARE / SHOWER & GET READY — 50 min","PACK — 5 min","DRIVE TO WORK — 30 min","START OF SHIFT — 10 min","PERSONAL TIME — 120 min","BAG RESET — 20 min","TEAS MATH PRACTICE — 30 min","WORK — 540 min","DRIVE HOME — 40 min","UNPACK BAGS — 5 min","PET TIME — 5 min","WALK — 80 min","WALK THING 1 — 20 min","WALK THING 2 — 20 min","NIGHT RESET — 15 min","NIGHT CARE AND POST-WORK SHOWER — 30 min","FINAL — 15 min"],
"Wednesday":["GET OUT OF BED — 16 min","MORNING START — 5 min","MORNING START #2 — 5 min","PET TIME — 5 min","MORNING ROUTINE — 20 min","WHERE ARE YOU EMMELLI? — 15 min","MAKE & EAT BREAKFAST — 30 min","LAUNDRY & PET CARE — 5 min","WALK THING 1 — 20 min","PET CARE — 2 min","WALK THING 2 — 20 min","PET CARE — 2 min","COOKING BLOCK — 90 min","HOUSE RESET — 15 min","FLOOR CARE #1 — 15 min","LAUNDRY — 10 min","MASK — 15 min","GET READY FOR GYM — 20 min","MORNING CARE / SHOWER & GET READY — 50 min","DRIVE TO GYM — 15 min","GYM — 60 min","DRIVE HOME FROM GYM — 15 min","APARTMENT GYM AB CIRCUIT — 15 min","TREADMILL WALK — 30 min","SHOWER & GET READY FOR WORK — 50 min","PACK — 5 min","DRIVE TO WORK — 40 min","START OF SHIFT — 10 min","PERSONAL TIME — 120 min","BAG RESET — 20 min","PERT MATH PRACTICE — 30 min","WORK — 300 min","DRIVE HOME — 40 min","UNPACK BAGS — 5 min","PET TIME — 5 min","WALK THING 1 — 20 min","WALK THING 2 — 20 min","NIGHT RESET — 15 min","NIGHT CARE AND POST-WORK SHOWER — 30 min","FINAL — 15 min"],
"Thursday":["GET OUT OF BED — 15 min","MORNING START — 5 min","MORNING START #2 — 5 min","PET TIME — 5 min","MORNING ROUTINE — 20 min","WHERE ARE YOU EMMELLI? — 15 min","MAKE & EAT BREAKFAST — 30 min","LAUNDRY & PET CARE — 5 min","WALK THING 1 — 20 min","PET CARE — 2 min","WALK THING 2 — 20 min","PET CARE — 2 min","COOKING BLOCK — 90 min","HOUSE RESET — 15 min","LAUNDRY — 10 min","WALK — 80 min","MORNING CARE / SHOWER & GET READY — 50 min","PACK — 5 min","DRIVE TO WORK — 40 min","START OF SHIFT — 10 min","PERSONAL TIME — 120 min","BAG RESET — 20 min","TEAS READING — 30 min","WORK — 300 min","DRIVE HOME — 40 min","UNPACK BAGS — 5 min","PET TIME — 5 min","WALK THING 1 — 20 min","WALK THING 2 — 20 min","NIGHT RESET — 15 min","NIGHT CARE AND POST-WORK SHOWER — 30 min","FINAL — 15 min"],
"Friday":["GET OUT OF BED — 15 min","MORNING START — 5 min","MORNING START #2 — 5 min","PET TIME — 5 min","MORNING ROUTINE — 20 min","WHERE ARE YOU EMMELLI? — 15 min","MAKE & EAT BREAKFAST — 30 min","LAUNDRY & PET CARE — 5 min","WALK THING 1 — 20 min","PET CARE — 2 min","WALK THING 2 — 20 min","PET CARE — 2 min","HOUSE RESET — 15 min","LAUNDRY — 10 min","MASK — 15 min","MORNING CARE / SHOWER & GET READY — 50 min","PACK — 5 min","DRIVE TO WORK — 30 min","START OF SHIFT — 10 min","PERSONAL TIME — 120 min","BAG RESET — 20 min","TEAS SCIENCE / WEAK AREAS — 30 min","WORK — 330 min","DRIVE TO GYM — 40 min","GYM — 60 min","DRIVE HOME FROM GYM — 15 min","APARTMENT GYM AB CIRCUIT — 15 min","TREADMILL WALK — 30 min","UNPACK BAGS — 5 min","PET TIME — 5 min","WALK THING 1 — 20 min","WALK THING 2 — 20 min","NIGHT RESET — 15 min","NIGHT CARE AND POST-WORK/POST-GYM SHOWER — 30 min","FINAL — 15 min"],
"Saturday":["GET OUT OF BED — 16 min","MORNING START — 5 min","MORNING START #2 — 5 min","PET TIME — 5 min","MORNING ROUTINE — 20 min","WHERE ARE YOU EMMELLI? — 15 min","MAKE & EAT BREAKFAST — 30 min","LAUNDRY & PET CARE — 5 min","WALK THING 1 — 20 min","PET CARE — 2 min","WALK THING 2 — 20 min","PET CARE — 2 min","LAUNDRY — 10 min","MORNING CARE / SHOWER & GET READY — 50 min","PACK — 5 min","DRIVE TO WORK — 40 min","START OF SHIFT — 10 min","PERSONAL TIME — 120 min","BAG RESET — 20 min","PERT READING — 30 min","WORK — 300 min","DRIVE HOME — 40 min","UNPACK BAGS — 5 min","PET TIME — 5 min","WALK THING 1 — 20 min","WALK THING 2 — 20 min","RECOVERY NAP — 60 min","HOME RESET • FLOOR CARE #2 — 120 min","NIGHT RESET — 15 min","NIGHT CARE AND POST-WORK SHOWER — 30 min","FINAL — 15 min"],
"Sunday":["GET OUT OF BED — 16 min","MORNING START — 5 min","MORNING START #2 — 5 min","PET TIME — 5 min","MORNING ROUTINE — 20 min","WHERE ARE YOU EMMELLI? — 15 min","MAKE & EAT BREAKFAST — 30 min","LAUNDRY & PET CARE — 5 min","WALK THING 1 — 20 min","PET CARE — 2 min","WALK THING 2 — 20 min","PET CARE — 2 min","LAUNDRY — 10 min","MORNING CARE / SHOWER & GET READY — 50 min","PACK — 5 min","DRIVE TO WORK — 40 min","START OF SHIFT — 10 min","PERSONAL TIME — 120 min","BAG RESET — 20 min","TEAS ENGLISH AND REVIEW MISTAKES — 30 min","WORK — 300 min","DRIVE HOME — 40 min","UNPACK BAGS — 5 min","PET TIME — 5 min","START SUNDAY LOAD — 5 min","WALK THING 1 — 20 min","WALK THING 2 — 20 min","PRAYER • LAUNDRY — 10 min","HOME RESET — 120 min","WEEKLY PLANNING — 15 min","SELF-CARE RESET PT #1 — 40 min","SELF-CARE RESET PT #2 — 40 min","SELF-CARE RESET PT #3 — 50 min","LAUNDRY — 10 min","NIGHT RESET — 15 min","NIGHT CARE AND POST-WORK SHOWER — 30 min","FINAL — 15 min"]};
const MEAL={
  "week": "2026-09-28",
  "label": "MON 9/28 → SUN 10/4",
  "targets": {
    "calories": "~2,000",
    "protein": "≥135 g",
    "carbs": "220–250 g",
    "fat": "55–70 g",
    "fiber": "≥28 g"
  },
  "gymFuel": {
    "pre": "100 g banana + 15 g honey",
    "post": "1 scoop ISO100"
  },
  "mondayCoverage": {
    "status": "MONDAY COOKING COMPLETE — 4 PORTIONS PACKED; TUESDAY PORTIONS EATEN",
    "note": "Beef & Broccoli Garlic Noodles and Marry Me Chicken Meatballs were cooked Monday 9/28 using the exact planned measurements. Beef & Broccoli Garlic Noodles finished at 1,472 g total and was packed into TWO 736 g containers. Marry Me Chicken Meatballs was packed into TWO containers, each with 272 g cooked meatballs + 140 g sauce. Tuesday 9/29 one beef container and one chicken container were eaten as planned; one beef and one chicken container remain for their later planned meals. Monday actual food remains intentionally blank."
  },
  "days": {
    "2026-09-28": {
      "day": "MONDAY",
      "activity": "GYM",
      "breakfast": "Cream-cheese raspberry sourdough — 1 sourdough slice + 31 g Philadelphia cream cheese + 50 g older raspberries + 15 g honey",
      "pre": "100 g banana + 15 g honey",
      "post": "1 scoop ISO100",
      "lunch": "",
      "dinner": "",
      "snacks": "Monday actual intake was not fully logged — do not backfill or invent food/macros",
      "cook": [
        "Beef & Broccoli Garlic Noodles — 2 portions: Tue lunch FRIDGE; Fri lunch FREEZER",
        "Marry Me Chicken Meatballs — 2 portions: Tue dinner FRIDGE; Sat lunch FREEZER"
      ],
      "prep": "MONDAY INVENTORY PASS: both cook recipes require zero grocery purchases.",
      "thaw": "Use already-on-hand proteins; if frozen, move to fridge early enough for safe thawing before cooking."
    },
    "2026-09-29": {
      "day": "TUESDAY",
      "activity": "RUN",
      "breakfast": "Protein oatmeal — Quaker Protein Maple & Brown Sugar + 1 scoop ISO100 + 50 g older berries + 15 g chia + Fairlife milk",
      "pre": "",
      "post": "",
      "lunch": "Beef & Broccoli Garlic Noodles #1",
      "dinner": "Marry Me Chicken Meatballs #1 + pasta + sauce",
      "snacks": "Tuesday already in progress/completed — log only what was actually eaten; do not add food just to force a target",
      "cook": [],
      "prep": "Move Wednesday chicken if still frozen → fridge.",
      "thaw": "Wednesday chicken: FREEZER → FRIDGE tonight if needed."
    },
    "2026-09-30": {
      "day": "WEDNESDAY",
      "activity": "GYM",
      "breakfast": "Bacon-egg-cheddar sourdough — 1 sourdough slice + 1 egg + 3 Kirkland bacon pieces + 1 cheddar slice",
      "pre": "100 g banana + 15 g honey",
      "post": "1 scoop ISO100",
      "lunch": "UNRESOLVED — Wednesday actual lunch was not confirmed; do not backfill",
      "dinner": "UNRESOLVED — Wednesday actual dinner was not confirmed; Chicken Cobbler was NOT produced Wednesday",
      "snacks": "UNRESOLVED — log only what was actually eaten",
      "cook": [],
      "prep": "MISSED COOK DAY — no Wednesday cooking completion should be inferred. Thursday 10/1 actual cooking records are authoritative.",
      "thaw": "No Wednesday finished-meal thaw handoff recorded."
    },
    "2026-10-01": {
      "day": "THURSDAY",
      "activity": "RUN",
      "breakfast": "Protein oatmeal — Quaker Protein oatmeal + 1 scoop ISO100 + berries + 15 g chia + Fairlife milk",
      "pre": "",
      "post": "",
      "lunch": "Cheesy Cottage Pie #1",
      "dinner": "Chicken + Veg/Broth Base #1",
      "snacks": "1 medium apple + 14 g almonds + 1 fruit snack pouch",
      "cook": [
        "ACTUAL: Ham & Lentil Soup — 2 packed portions",
        "ACTUAL: Cheesy Cottage Pie — 2 packed portions",
        "ACTUAL: Chicken + Veg/Broth Base — 2 packed portions",
        "PAUSED: Chicken Cobbler — reserved/prepped components only; not a finished meal"
      ],
      "prep": "OCT 1 ACTUALS SAVED. Chicken Cobbler remains PAUSED/RESERVED, not a finished container. Prep Friday bacon-egg-cheddar breakfast. Move the ONE remaining Beef & Broccoli Garlic Noodles container freezer → fridge.",
      "thaw": "ONE remaining Beef & Broccoli Garlic Noodles container: FREEZER → FRIDGE tonight for Fri 10/2 lunch."
    },
    "2026-10-02": {
      "day": "FRIDAY",
      "activity": "GYM",
      "breakfast": "Bacon + egg + cheddar on the current rosemary-garlic loaf",
      "pre": "100 g banana + 15 g honey",
      "post": "1 scoop ISO100",
      "lunch": "Beef & Broccoli Garlic Noodles — ONE remaining 736 g container",
      "dinner": "Ham & Lentil Soup #2",
      "snacks": "100 g frozen berry mix + 14 g almonds + 1 MadeGood Snickerdoodle bite",
      "cook": [],
      "prep": "Move the ONE remaining Marry Me Chicken Meatballs container + Cheesy Cottage Pie #2 freezer → fridge.",
      "thaw": "Marry Me Chicken Meatballs — ONE remaining container + Cheesy Cottage Pie #2: FREEZER → FRIDGE tonight."
    },
    "2026-10-03": {
      "day": "SATURDAY",
      "activity": "REST",
      "breakfast": "Protein oatmeal + ISO100 + berries + 15 g chia + Fairlife milk",
      "pre": "",
      "post": "",
      "lunch": "Marry Me Chicken Meatballs #2 — 272 g meatballs + 140 g sauce + pasta from 85 g dry equivalent",
      "dinner": "Cheesy Cottage Pie #2",
      "snacks": "100 g frozen mango + 14 g almonds + 1 fruit snack pouch",
      "cook": [],
      "prep": "Move Chicken + Veg/Broth Base #2 to the fridge for Sunday. Sunday lunch replacement is UNRESOLVED because Chicken Cobbler was paused and was not produced.",
      "thaw": "Chicken + Veg/Broth Base #2: FREEZER → FRIDGE tonight. DO NOT thaw a Chicken Cobbler or Chicken & Dumplings container; those finished containers were not produced."
    },
    "2026-10-04": {
      "day": "SUNDAY",
      "activity": "REST",
      "breakfast": "Protein oatmeal + ISO100 + berries + chia + Fairlife milk",
      "pre": "",
      "post": "",
      "lunch": "UNRESOLVED — replacement meal needed; Chicken Cobbler was paused and not produced",
      "dinner": "Chicken + Veg/Broth Base #2",
      "snacks": "100 g frozen berry mix + 14 g almonds + 1 MadeGood Snickerdoodle bite",
      "cook": [],
      "prep": "No cooking. Dinner uses the actual Chicken + Veg/Broth Base portion. Lunch remains unresolved until a real available meal is assigned.",
      "thaw": "No additional thaw handoff after today’s meals."
    }
  },
  "recipes": {
    "Beef & Broccoli Garlic Noodles": {
      "source": "https://www.thekitchn.com/beef-and-broccoli-noodles-recipe-23656929",
      "sourceLabel": "The Kitchn — Beef & Broccoli Noodles",
      "ingredients": [
        "454 g ground beef",
        "170 g dry pasta/noodles",
        "170 g frozen broccoli",
        "60 g red onion",
        "10 g ginger",
        "45 mL liquid aminos",
        "15 mL Worcestershire",
        "240 mL opened beef broth",
        "10 g cornstarch",
        "14 g butter"
      ],
      "bowls": [
        "BOWL 1 — SAUCE: 45 mL liquid aminos + 15 mL Worcestershire + 240 mL beef broth + 10 g cornstarch; whisk smooth.",
        "BOWL 2 — AROMATICS: 60 g diced red onion + 10 g ginger.",
        "CUTTING BOARD — BROCCOLI: weigh 170 g frozen broccoli; keep on the board if practical.",
        "BOWL 3 — NOODLES: weigh 170 g dry pasta/noodles.",
        "PLATE 1 — PROTEIN: weigh 454 g raw ground beef."
      ],
      "method": "Bring a pot of salted water to a boil and cook BEEF — Bowl 3: Noodles to package al dente; reserve 120 mL pasta water, then drain. Heat a large skillet over medium-high. Melt 14 g butter, add BEEF — Paper Plate 1: Protein, break it up, and cook until browned with no pink remaining, about 6–8 minutes. Add BEEF — Bowl 2: Aromatics and cook 2 minutes. Add BEEF — Cutting Board: Broccoli plus 30–60 mL reserved pasta water; cover 3–5 minutes until hot/tender. Re-whisk BEEF — Bowl 1: Sauce, pour it in, and simmer 2–4 minutes until glossy. Toss in the drained noodles. Add reserved pasta water a little at a time if needed so both portions stay saucy.",
      "weigh": "Weigh finished combined noodle/beef/broccoli mixture: ____ g. Recommended per container = finished grams ÷ 2. Container 1 actual ____ g (Tue 9/29, FRIDGE). Container 2 actual ____ g (Fri 10/2, FREEZER)."
    },
    "Marry Me Chicken Meatballs": {
      "source": "https://www.thekitchn.com/marry-me-chicken-meatballs-recipe-23606116",
      "sourceLabel": "The Kitchn — Marry Me Chicken Meatballs",
      "ingredients": [
        "454 g ground chicken",
        "1 large egg (~50 g)",
        "30 g panko",
        "60 g Parmesan total",
        "16 g garlic total",
        "1 g oregano",
        "1 g thyme",
        "1 g seasoned salt",
        "40 g opened sun-dried tomatoes",
        "20 g opened tomato paste",
        "180 mL opened chicken stock",
        "120 mL heavy cream",
        "60 mL Fairlife milk",
        "170 g dry pasta"
      ],
      "bowls": [
        "BOWL 1 — MEATBALL MIX: 454 g ground chicken + 1 egg (~50 g) + 30 g panko + 30 g Parmesan + 8 g garlic + 1 g oregano + 1 g seasoned salt.",
        "BOWL 2 — SAUCE BASE: 40 g chopped sun-dried tomatoes + 20 g tomato paste + 8 g garlic + 1 g thyme.",
        "BOWL 3 — SAUCE LIQUID: 180 mL chicken stock + 120 mL heavy cream + 60 mL Fairlife milk + 30 g Parmesan.",
        "BOWL 4 — PASTA: weigh 170 g dry pasta."
      ],
      "method": "Bring a pot of salted water to a boil for CHICKEN — Bowl 4: Pasta. Form CHICKEN — Bowl 1: Meatball Mix into evenly sized meatballs. Heat a large skillet over medium with a light coating of cooking fat; brown the meatballs on all sides, then continue cooking until the centers reach 165°F. Transfer to a clean plate. Cook CHICKEN — Bowl 4: Pasta to package al dente and drain. In the meatball skillet cook CHICKEN — Bowl 2: Sauce Base over medium for 1–2 minutes. Add CHICKEN — Bowl 3: Sauce Liquid, bring to a gentle simmer, and cook 3–5 minutes until creamy; do not hard-boil the cream. Return the meatballs and simmer until coated/hot. Keep meatballs, sauce, and pasta separate for the required finished weights before portioning.",
      "weigh": "Weigh cooked meatballs ____ g and sauce ____ g separately; divide each by 2. Weigh cooked pasta ____ g; divide by 2. Container 1 Tue 9/29 FRIDGE; Container 2 Sat 10/3 FREEZER."
    },
    "Ham & Lentil Soup": {
      "source": "https://www.foodnetwork.com/recipes/food-network-kitchen/lentil-and-ham-soup-3363563",
      "sourceLabel": "Food Network — Lentil and Ham Soup",
      "ingredients": [
        "remaining Hillshire honey ham — weigh ____ g",
        "180 g dry green lentils",
        "114 g carrots",
        "80 g onion",
        "80 g celery",
        "12 g garlic",
        "720 mL opened chicken stock + water as needed",
        "2 g thyme",
        "2 g paprika",
        "14 g butter"
      ],
      "bowls": [
        "HAM & LENTIL SOUP — CUTTING BOARD: 114 g carrots + 80 g onion + 80 g celery + 12 g garlic. Keep together; they enter the pot together.",
        "HAM & LENTIL SOUP — BOWL 1: 180 g dry green lentils, rinsed + 2 g thyme + 2 g paprika. One bowl because all three are added together.",
        "HAM & LENTIL SOUP — MEASURING JUG: 720 mL chicken stock. Measure water only later if the soup needs thinning.",
        "HAM & LENTIL SOUP — PAPER PLATE 1: weigh remaining ham ____ g; dice."
      ],
      "method": "Melt 14 g butter in a soup pot over medium. Add SOUP — Cutting Board: Aromatics and sauté 6–8 minutes until the vegetables begin to soften. Add HAM & LENTIL SOUP — Bowl 1: Lentils + Seasoning and stir 30 seconds, then add HAM & LENTIL SOUP — Measuring Jug: Stock. Bring to a boil, reduce to a steady simmer, partially cover, and cook about 25–35 minutes, stirring occasionally, until the lentils are tender. Add measured water if the soup gets thicker than you want. Stir in SOUP — Paper Plate 1: Ham for the final 5 minutes, just until hot. Keep it brothy for reheating.",
      "weigh": "Weigh finished soup ____ g; divide by 2. Wed 9/30 portion can be eaten today; Fri 10/2 portion FREEZER after cooling."
    },
    "Chicken Cobbler": {
      "source": "https://www.allrecipes.com/savory-chicken-cobbler-11845890",
      "sourceLabel": "Allrecipes — Savory Chicken Cobbler",
      "ingredients": [
        "existing freezer chicken — weigh actual ____ g",
        "113 g carrots",
        "80 g onion",
        "120 g corn",
        "12 g garlic",
        "360 mL chicken stock",
        "180 mL Fairlife milk",
        "20 g cornstarch",
        "140 g flour",
        "8 g baking powder",
        "56 g butter",
        "85 g mild cheddar",
        "2 g thyme",
        "2 g poultry seasoning"
      ],
      "bowls": [
        "CHICKEN COBBLER — CUTTING BOARD: 113 g carrots + 80 g onion + 120 g corn + 12 g garlic. Keep together; they enter the skillet together.",
        "CHICKEN COBBLER — LARGE BOWL 1: 140 g flour + 8 g baking powder + 2 g thyme + 2 g poultry seasoning. Leave room in this SAME bowl to add 56 g melted butter + 85 g cheddar later; no separate finish bowl.",
        "CHICKEN COBBLER — MEASURING JUG: 360 mL chicken stock + 180 mL Fairlife milk + 20 g cornstarch; whisk smooth in the jug.",
        "CHICKEN COBBLER — PAPER PLATE 1: weigh actual suitable freezer chicken ____ g."
      ],
      "method": "Heat oven to 400°F. Cook COBBLER — Paper Plate 1: Chicken in a large oven-safe skillet over medium-high until it reaches 165°F; remove and cut/shred as needed. Add COBBLER — Cutting Board: Vegetables to the same skillet and cook 5–7 minutes until beginning to soften. Re-whisk CHICKEN COBBLER — Measuring Jug: Gravy, pour it in, and simmer 3–5 minutes until a saucy gravy forms; return the chicken. Add 56 g melted butter + 85 g cheddar directly to CHICKEN COBBLER — Large Bowl 1: Cobbler Dry and combine just until a thick spoonable topping forms—do not overmix. Spoon the topping evenly over the hot filling. Bake at 400°F about 18–25 minutes, until the topping is golden and cooked through and the filling is bubbling.",
      "weigh": "Weigh finished cobbler ____ g; divide by 2. Wed 9/30 portion; Sun 10/4 LUNCH portion FREEZER."
    },
    "Cheesy Cottage Pie": {
      "source": "https://www.bbcgoodfood.com/recipes/cottage-pie",
      "sourceLabel": "Good Food — Cottage Pie • adapted to remaining Bell & Evans ground chicken",
      "ingredients": [
        "454 g Bell & Evans ground chicken — remaining 1 lb pack",
        "500 g potatoes",
        "120 g corn",
        "114 g carrots",
        "80 g onion",
        "12 g garlic",
        "30 g tomato paste",
        "300 mL beef broth",
        "30 mL liquid aminos",
        "15 g flour",
        "42 g butter total",
        "120 mL Fairlife milk",
        "85 g cheddar"
      ],
      "bowls": [
        "CHEESY COTTAGE PIE — CUTTING BOARD: Put 500 g peeled/cut potatoes on one side; keep 120 g corn + 114 g carrots + 80 g onion + 12 g garlic together on the other side. One board, two zones; no extra bowl.",
        "CHEESY COTTAGE PIE — MEASURING JUG: 30 g tomato paste + 300 mL beef broth + 30 mL liquid aminos + 15 g flour; whisk smooth.",
        "CHEESY COTTAGE PIE — BOWL 1: 28 g butter + 120 mL Fairlife milk + 85 g cheddar for the mash finish.",
        "CHEESY COTTAGE PIE — PAPER PLATE 1: 454 g raw Bell & Evans ground chicken."
      ],
      "method": "Heat oven to 400°F. Put COTTAGE PIE — Cutting Board: Potatoes in a pot, cover with cold water, bring to a boil, and simmer 12–18 minutes until fork-tender. Meanwhile brown COTTAGE PIE — Paper Plate 1: Ground Chicken in a skillet over medium-high, about 6–8 minutes. Add COTTAGE PIE — Cutting Board: Filling Veg and cook about 5 minutes. Re-whisk CHEESY COTTAGE PIE — Measuring Jug: Gravy, add it, and simmer 3–5 minutes into a generous gravy. MEASURE FINISHED TOTALS the finished chicken filling before it is covered by mash. Drain the potatoes well and mash with CHEESY COTTAGE PIE — Bowl 1: Mash Finish until smooth. MEASURE FINISHED TOTALS the finished mash separately. Spread the chicken filling in a baking dish, top with mash, and bake 15–20 minutes at 400°F until hot; broil briefly only if you want extra browning.",
      "weigh": "Weigh finished chicken filling ____ g and mash ____ g separately; divide each by 2. Thu 10/1 portion; Sat 10/3 portion FREEZER."
    },
    "Chicken & Dumplings": {
      "source": "https://www.kingarthurbaking.com/recipes/chicken-and-dumplings-recipe",
      "sourceLabel": "King Arthur Baking — Chicken and Dumplings • use suitable existing freezer chicken",
      "ingredients": [
        "existing freezer chicken — weigh actual ____ g; use a boneless cut suitable for the recipe",
        "113 g carrots",
        "80 g onion",
        "80 g celery",
        "12 g garlic",
        "480 mL chicken stock",
        "180 mL Fairlife milk",
        "140 g flour",
        "8 g baking powder",
        "42 g butter",
        "2 g poultry seasoning",
        "1 g thyme"
      ],
      "bowls": [
        "CHICKEN & DUMPLINGS — CUTTING BOARD: 113 g carrots + 80 g onion + 80 g celery + 12 g garlic. Keep together; they enter the pot together.",
        "CHICKEN & DUMPLINGS — BOWL 1: 140 g flour + 8 g baking powder + 2 g poultry seasoning + 1 g thyme. Leave room to add 60 mL Fairlife milk + 28 g melted butter directly to this SAME bowl when it is time to make the dumplings.",
        "CHICKEN & DUMPLINGS — MEASURING JUG: 480 mL chicken stock + 120 mL Fairlife milk.",
        "CHICKEN & DUMPLINGS — PAPER PLATE 1: weigh actual suitable boneless freezer chicken ____ g."
      ],
      "method": "Melt 14 g butter in a wide pot over medium-high. Brown DUMPLINGS — Paper Plate 1: Chicken, then add DUMPLINGS — Cutting Board: Vegetables and cook about 5 minutes. Add CHICKEN & DUMPLINGS — Measuring Jug: Gravy Liquid, bring to a gentle simmer, and cook until the chicken reaches 165°F and the vegetables are tender. Add 60 mL Fairlife milk + 28 g melted butter directly to CHICKEN & DUMPLINGS — Bowl 1: Dumpling Dry and combine just until combined; do not overmix. Drop even spoonfuls over the simmering filling. Cover tightly, reduce to medium-low, and cook 12–15 minutes without lifting the lid during the first 12 minutes. Check a center dumpling for doneness before portioning.",
      "weigh": "Weigh finished chicken/gravy/dumplings ____ g; divide by 2. Thu 10/1 portion; Sun 10/4 portion FREEZER."
    },
    "Mild Curried Beef & Potatoes": {
      "source": "https://www.food.com/recipe/ground-beef-and-potato-curry-74769",
      "sourceLabel": "Food.com — Ground Beef and Potato Curry",
      "ingredients": [
        "454 g ground beef",
        "450 g potatoes",
        "120 g corn",
        "12 g garlic",
        "10 g ginger",
        "30 g tomato paste",
        "360 mL beef broth",
        "8 g mild curry powder",
        "2 g turmeric",
        "14 g ghee"
      ],
      "bowls": [
        "MILD CURRIED BEEF & POTATOES — CUTTING BOARD: 450 g diced potatoes + 120 g corn. Keep together; they enter the pot together.",
        "MILD CURRIED BEEF & POTATOES — BOWL 1: 12 g garlic + 10 g ginger + 8 g mild curry powder + 2 g turmeric. One bowl: aromatics go in first, then tip the spices from the SAME bowl 1 minute later; no reason for two bowls.",
        "MILD CURRIED BEEF & POTATOES — MEASURING JUG: 30 g tomato paste + 360 mL beef broth; whisk smooth.",
        "MILD CURRIED BEEF & POTATOES — PAPER PLATE 1: 454 g raw ground beef."
      ],
      "method": "Heat 14 g ghee in a wide pot over medium-high. Brown CURRY — Paper Plate 1: Beef for 6–8 minutes. Add MILD CURRIED BEEF & POTATOES — Bowl 1: Garlic + Ginger and cook about 1 minute, then tip the curry powder + turmeric from that SAME bowl into the pot and stir about 30 seconds until fragrant. Add CURRY — Cutting Board: Potatoes/Corn and MILD CURRIED BEEF & POTATOES — Measuring Jug: Gravy. Bring to a boil, then reduce to a steady simmer. Cover partially and cook about 18–25 minutes, stirring occasionally, until the potatoes are fork-tender. Uncover for the last few minutes only if the gravy is too thin; keep it generous and mild.",
      "weigh": "Weigh finished curry ____ g; divide by 2. Fri 10/2 portion FRIDGE; Mon 10/5 portion FREEZER."
    }
  },
  "grocery": {
    "Detwiler’s": [
      "NO BUY — use remaining 1 lb Bell & Evans ground chicken for Thursday Cheesy Cottage Pie",
      "NO BUY — use suitable existing freezer chicken for Thursday Chicken & Dumplings; weigh actual before prep",
      "~500 g potatoes — Thursday Cheesy Cottage Pie; buy only if not already on hand"
    ],
    "Walmart": [
      "fresh/minced garlic — need about 48 g usable across Wednesday + Thursday recipes; buy only if current garlic is insufficient",
      "Fairlife milk — recipe demand is about 480 mL across Wednesday + Thursday before breakfasts; current prior inventory was ~2 cups, so buy 1 carton unless a newer carton is already on hand"
    ]
  },
  "inventoryPriority": [
    "SEPT 30 SHOPPING RECONCILED: do not rebuy carrots, celery, bananas, chicken broth, beef broth, honey, baking powder, Nature’s Seasons, black pepper, cinnamon sugar, garlic powder, garlic salt, ground ginger, Italian seasoning, or the other confirmed haul items. The 1 lb / ~454 g carrots are allocated across Wed/Thu recipes as 114 g + 113 g + 114 g + 113 g = 454 g total.",
    "Monday cooking is fully logged: 2 beef + 2 meatball containers; Tuesday portions eaten; Friday/Saturday portions remain",
    "Ground beef used Monday batch is gone; opened beef broth + shredded Parmesan + pasta noodles used up; fudge + Hershey’s Affogato bars are gone",
    "Older raspberries/blackberries first",
    "Rosemary-garlic loaf sell-by Oct 3 — use first; sourdough is out",
    "Opened chicken stock before new",
    "Opened tomato paste before unopened",
    "Partial Worcestershire/liquid aminos before backups",
    "Fairlife milk before buying milk",
    "Remaining cream cheese and ham"
  ],
  "rollover": {
    "date": "2026-10-05",
    "lunch": "To be planned by the Friday meal-plan workflow under the exactly-two-recipes-per-cook-day rule.",
    "dinner": "To be planned by the Friday meal-plan workflow under the exactly-two-recipes-per-cook-day rule."
  }
};
const PREPARED_CONTAINER_TRUTH_2026_09_29={beefNoodles:{originalContainers:2,eatenTuesday:1,remaining:1,remainingGrams:736,use:"Fri 10/2 lunch"},marryMeMeatballs:{originalContainers:2,eatenTuesday:1,remaining:1,meatballsGrams:272,sauceGrams:140,use:"Sat 10/3 lunch"},rule:"Never recreate a second remaining Monday container. Tuesday already consumed one of each."};
const V34_AUDIT_NOTES={
fixed:["Removed stale Thursday third-recipe curry steps","Removed stale Monday Cottage Pie rollover","Removed duplicate old build meta","Corrected meatball container macros using the known 85 g dry-pasta equivalent without inventing cooked pasta grams","Wednesday/Thursday wake starts are 5:10 AM / 7:46 AM"],
requiresActualInput:["Remaining ham grams for Ham & Lentil Soup","Finished component weights for Wednesday and Thursday recipes","Exact package-label nutrition where Hub currently uses planning nutrition bases"],
rule:"Never display an exact final macro as complete when required actual weight or package nutrition is missing."
};
const COOKING_LIMIT_2026_09_29={days:["Monday","Wednesday","Thursday"],recipesPerCookDay:2,maxSessionMinutes:90,includes:["tools","get everything out","prep + measure","cook together","measurements","portion + labels","storage","cleanup"],wakeShift:{Wednesday:"5:10 AM",Thursday:"7:46 AM"},rule:"Exactly two recipes on every cooking day. Portion yield is flexible: make 2, 3, 4+ portions when needed so every lunch and dinner is a specific named home-cooked recipe. Never use a vague inventory meal. Optimize the two recipes together for the shortest practical session; 90 minutes / 1 hr 30 min is the scheduled cooking block ceiling including prep, cooking, Measurements, portioning, storage, and cleanup."};
const COOK_DISH_AUDIT={
 "2026-09-30":{
   "Ham & Lentil Soup":"1 cutting board + 1 small bowl + 1 measuring jug + 1 paper plate + 1 soup pot.",
   "Chicken Cobbler":"1 cutting board + 1 large mixing bowl + 1 measuring jug + 1 paper plate + 1 oven-safe skillet.",
   note:"No separate seasoning bowl, liquid bowl, or cobbler-finish bowl. Measuring jugs may be washed/reused between recipes after contents are poured."
 },
 "2026-10-01":{
   "Cheesy Cottage Pie":"1 cutting board with two zones + 1 small bowl + 1 measuring jug + 1 paper plate + 1 potato pot + 1 skillet/baking dish.",
   "Chicken & Dumplings":"1 cutting board + 1 mixing bowl + 1 measuring jug + 1 paper plate + 1 wide pot.",
   note:"No separate wet/dry dumpling bowls; no separate curry-spice bowl; no second cutting board for cottage-pie potatoes."
 }
};
const GROCERY_AUDIT_2026_09_29={
 postMondayInventory:true,
 removedConsumed:["454 g ground beef used Monday","454 g ground chicken used Monday","240 mL opened beef broth used up","60 g shredded Parmesan used up","170 g pasta noodles used up","Hershey’s Affogato bars","Kilwins fudge"],
 remainingPrepared:["Beef & Broccoli Garlic Noodles • Fri 10/2 • 736 g","Marry Me Chicken Meatballs • Sat 10/3 • 272 g meatballs + 140 g sauce"],
 rule:"Groceries cover only confirmed shortages for the remaining week; no conditional fruit/rice/flour lines."
};
const DAY_MACRO_PLAN={
"2026-09-30":{status:"RECALCULATE FROM ACTUAL CONTAINERS",note:"Use saved container macros after Wednesday cooking Measurements."},
"2026-10-01":{status:"RECALCULATE FROM ACTUAL CONTAINERS",note:"Use saved container macros after Thursday cooking Measurements."},
"2026-10-02":{status:"PARTIAL",note:"Beef container has a planning macro estimate; Ham & Lentil Soup final macros depend on actual ham and finished weight."},
"2026-10-03":{status:"PARTIAL",note:"Marry Me Chicken Meatballs container includes pasta nutrition from 85 g dry-pasta equivalent; Cottage Pie final macros still come from Thursday Measurements."},
"2026-10-04":{status:"UNRESOLVED",note:"Sunday lunch replacement is not assigned. Dinner uses the actual Chicken + Veg/Broth Base #2 container. Do not count Chicken Cobbler or Chicken & Dumplings as finished food."}
};
const RECIPE_MACROS_EST={
 "Beef & Broccoli Garlic Noodles":{servings:2,kcal:760,protein:48,carbs:82,fat:27,fiber:7,note:"Estimated per portion from Hub ingredient amounts; actual 736 g container keeps one-half batch macros."},
 "Marry Me Chicken Meatballs":{servings:2,kcal:1010,protein:66,carbs:91,fat:42,fiber:4,note:"Estimated per portion including pasta + sauce; actual packed meatballs 272 g + sauce 140 g per portion."},
 "Ham & Lentil Soup":{servings:2,kcal:610,protein:39,carbs:82,fat:14,fiber:18,note:"Estimated per portion; ham amount is still not weighed, so this remains provisional."},
 "Chicken Cobbler":{servings:2,kcal:990,protein:83,carbs:74,fat:40,fiber:6,note:"Estimated per portion from Hub recipe ingredients."},
 "Cheesy Cottage Pie":{servings:2,kcal:960,protein:55,carbs:79,fat:47,fiber:9,note:"Estimated per portion from Hub recipe ingredients."},
 "Chicken & Dumplings":{servings:2,kcal:790,protein:55,carbs:70,fat:31,fiber:5,note:"Estimated per portion from Hub recipe ingredients."},
 "Mild Curried Beef & Potatoes":{servings:2,kcal:690,protein:42,carbs:55,fat:33,fiber:7,note:"Estimated per portion from Hub recipe ingredients."}
};
const DAILY_MACRO_TARGETS={kcal:2000,proteinMin:135,carbsMin:220,carbsMax:250,fatMin:55,fatMax:70,fiberMin:28,note:"Planning estimates until all package labels and finished component weights are confirmed."};
const FOOD_RULES={noBackToBack:true,repeatGap:"The same entrée/recipe may NEVER be eaten on consecutive calendar days. There must be at least one full intervening calendar day before that entrée is eaten again.",audit:"Check actual eaten history, prior week, current week, prepared Containers, and Monday rollover before finalizing or moving a portion."};
const CURRENT_WEEK_ENTREE_AUDIT={
"Beef & Broccoli Garlic Noodles":["2026-09-29","2026-10-02"],
"Marry Me Chicken Meatballs":["2026-09-29","2026-10-03"],
"Ham & Lentil Soup":["2026-10-02"],
"Cheesy Cottage Pie":["2026-10-01","2026-10-03"],
"Chicken + Veg/Broth Base":["2026-10-01","2026-10-04"]
};
function entreeSpacingAudit(){
 let issues=[];Object.entries(CURRENT_WEEK_ENTREE_AUDIT).forEach(([name,dates])=>{
  let ds=dates.map(x=>new Date(x+"T12:00:00")).sort((a,b)=>a-b);
  for(let i=1;i<ds.length;i++)if((ds[i]-ds[i-1])/86400000<2)issues.push(name)
 });return issues
}
const WEEK_SPACING_AUDIT={
"Beef & Broccoli Garlic Noodles":["Tue 9/29","Fri 10/2"],
"Marry Me Chicken Meatballs":["Tue 9/29","Sat 10/3"],
"Ham & Lentil Soup":["Fri 10/2"],
"Cheesy Cottage Pie":["Thu 10/1","Sat 10/3"],
"Chicken + Veg/Broth Base":["Thu 10/1","Sun 10/4"]
};
const WISHCATS=["Clothes","Shoes","Jewelry","Dogs","Jeremiah","Home","Miscellaneous","Car"];
const NORMAL_RENT=2065,EMERGENCY_RENT=2150;
const BILLS=[
["Rent",NORMAL_RENT,1],["Amped",35,1],["Apple One Family",27.95,1],["Car Wash",43,2],["Angel Guild",20,4],["Phone",200,5],
["Scentbird",39.01,7],["Eyebrows",100,8],["Nails",215,8],["Dog Food",80,8],["Grooming",110,8],["BarkBox",40.66,8],
["Car Insurance",200,9],["Ring",9.99,12],["Ring",5,12],["Tiamo Insurance",85,19],["Summit",40,20],
["Busch Gardens",60,22],["Credit Card Bill",25,22],["FPL",100,25],["Netflix",29,28]
];
const UNDATED_BILLS=[["HP Instant Ink",17],["ChatGPT Plus",19.99]];
const JOB_INCOME={job1:650,job2:325,jeremiah:185};
const WEEKLY_INCOME=JOB_INCOME.job1+JOB_INCOME.job2+JOB_INCOME.jeremiah,WEEKLY_ENVELOPES=180,WEEKLY_SAVINGS=0;
const SKEY="emmelliHubVISIBLEPROOF2026_09_30_v11";
function base(){return{day:(new Date().getDay()+6)%7,route:"today",sub:null,routine:{},goals:[],water:{},weight:{},measure:{},studyNotes:{},studyResources:{},bible:{},run:{},gym:{},inventory:{Fridge:[
{name:"Raspberries — older",qty:"~12 oz"},{name:"Blackberries — older",qty:"~1/4 cup"},{name:"Raspberries — newer",qty:"amount not supplied"},{name:"Blackberries — newer",qty:"6 oz"},{name:"Blackberries — newer partial",qty:"~4 oz"},{name:"Apples",qty:"2"},{name:"Red onion",qty:"remaining amount unknown after 60 g used",notes:"Prior amount was about 1/2 onion; 60 g used Monday."},{name:"Lemon",qty:"1"},{name:"Orange",qty:"1"},{name:"Eggs",qty:"6"},{name:"Philadelphia cream cheese",qty:"~5 tbsp"},{name:"Hummus",qty:"~4 tbsp"},{name:"Fairlife milk",qty:"GENERAL REMAINING AMOUNT UNRESOLVED",notes:"OCT 1 CURRENT TRUTH • PRE-MEASURED COBBLER FAIRLIFE CUP IS RESERVED PREP AND IS NOT GENERAL MILK INVENTORY."},{name:"Heavy cream",qty:"remaining amount unknown after 120 mL used",notes:"Monday cooking used 120 mL; original container volume was not supplied."},{name:"Mozzarella",qty:"~3/4 cup"},{name:"Honey ham",qty:"~15 slices"},{name:"Cabot sliced cheddar",qty:"3 slices"},{name:"Mild cheddar",qty:"8 oz"},{name:"Philadelphia cream cheese block",qty:">1/2 of 8 oz"},{name:"Sour cream",qty:"14 oz"},{name:"Butter",qty:"~178 g",notes:"OCT 1 LIVE COOK ACTUAL"},{name:"Laughing Cow",qty:"3 wedges"},{name:"McCormick brown gravy",qty:"~1 1/2 cups"},{name:"Kitchen Basics chicken stock — opened",qty:"0 — OUT",notes:"OCT 1 LIVE COOK ACTUAL • CHICKEN STOCK/BROTH USED UP"},{name:"Tomato paste — opened",qty:"~108 g remaining (approx.)",notes:"Prior amount was ~3/4 of a 6 oz can; 20 g used Monday."},{name:"Classico pesto — opened",qty:"nearly full 8.1 oz"},{name:"Dijon mustard",qty:"on hand"},{name:"Zero sugar ketchup",qty:"on hand"},{name:"Minced ginger",qty:"remaining amount unknown after 10 g used",notes:"10 g used Monday; starting quantity was not supplied."},{name:"Skinnygirl Caesar",qty:"on hand"},{name:"Yellow mustard",qty:"on hand"},{name:"Mixed fruit jam",qty:"on hand"},{name:"G Hughes sugar-free teriyaki",qty:"<1/2"},{name:"Bachan’s Original",qty:"full"},{name:"Liquid Aminos — partial",qty:"0 — EMPTY",notes:"OCT 1 LIVE COOK ACTUAL • PARTIAL BOTTLE EMPTIED"},{name:"Lime juice",qty:"~1/2"},{name:"Sun-dried tomatoes",qty:"remaining amount unknown after 40 g used",notes:"Prior amount was ~1/2 jar; jar size was not supplied."},{name:"Heinz sweet relish — check before use",qty:"on hand; Best By Jul 4, 2026"},{name:"La Legume celery",qty:"665 g prepared/cut",expires:"Estimated ~Oct 7, 2026",expiryType:"ESTIMATED USE WINDOW",useSoon:true,notes:"No printed date • weighed after cutting/prep 9/30/26"},{name:"Baby carrots",qty:"1 lb",expires:"Oct 17, 2026",expiryType:"PRINTED DATE",notes:"Brand recorded from haul as Cal-Organic Farms / voice confirmation"},{name:"Bananas",qty:"2",notes:"Purchased 9/30/26 • still partly green"},{name:"Rosemary-garlic loaf",qty:"1 loaf",expires:"Oct 3, 2026",expiryType:"SELL BY",useSoon:true,notes:"Packed Sep 28, 2026 • current bread; sourdough is out"}],
Freezer:[{name:"Broccoli florets",qty:"~18 oz"},{name:"Super sweet corn",qty:"36 oz"},{name:"Seasoned Brussels sprouts",qty:"13.5 oz"},{name:"Filet steak",qty:"weight unknown"},{name:"Frozen spinach",qty:"~2 cups"},{name:"Bell & Evans ground chicken",qty:"1 x 1 lb"},{name:"Blue Bunny Salted Caramel Craze",qty:"46 fl oz"},{name:"Frozen mango",qty:"~2 cups"},{name:"Frozen berry mix",qty:"~8 cups"},{name:"Kirkland bacon",qty:"2 packs"},{name:"Frozen chicken",qty:"on hand — actual total weight pending",notes:"Substantial freezer chicken supply. Weigh actual amount before cooking; never assume 600 g or auto-buy more."},{name:"Great Value frozen cauliflower",qty:"4 bags × ~340 g = ~1,360 g",expires:"May 11, 2028",expiryType:"BEST IF USED BY",notes:"All four bags share printed date"}],
Pantry:[{name:"Limes",qty:"6"},{name:"Potatoes",qty:"0 — OUT",notes:"OCT 1 LIVE COOK ACTUAL"},{name:"Great Value Organic reduced-sodium chicken broth — existing",qty:"0 — OUT",notes:"OCT 1 LIVE COOK ACTUAL • CHICKEN STOCK/BROTH USED UP"},{name:"Great Value Organic reduced-sodium chicken broth — new",qty:"0 — OUT",expires:"Jul 20, 2027",expiryType:"PRINTED DATE",store:"Walmart",purchasedDate:"2026-09-30",notes:"OCT 1 LIVE COOK ACTUAL • CHICKEN STOCK/BROTH USED UP"},{name:"Great Value Organic beef broth",qty:"32 oz",expires:"Dec 25, 2027",expiryType:"PRINTED DATE",store:"Walmart",purchasedDate:"2026-09-30"},{name:"Royal basmati rice",qty:"20 lb",expires:"Estimated Mar 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"No printed best-by • this is Emmelli’s regular rice"},{name:"Snack Factory Pretzel Crisps — Apple Spice White Crème",qty:"113 g",expires:"Jan 23, 2027",expiryType:"PRINTED DATE"},{name:"Great Value raw honey",qty:"32 oz",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"No printed date found"},{name:"Chick-fil-A Sauce — individual",qty:"2 × 28 g = 56 g total",notes:"Use naturally with compatible sandwiches/chicken meals before opening/buying another similar sauce"},{name:"Sweetened condensed coconut milk — opened",qty:"~6 tbsp"},{name:"Worcestershire — partial",qty:"~1 tbsp"},{name:"Mayonnaise — partial",qty:"~2 tbsp"},{name:"Kirkland honey",qty:"~1 tbsp"},{name:"Fettuccine",qty:"~1 box"},{name:"Jumbo shells",qty:"amount unknown"},{name:"Penne",qty:"~1 1/2 cups"},{name:"Brown sugar",qty:"~4 cups"},{name:"AP flour",qty:"~1/4 cup LOOSE",notes:"OCT 1 CURRENT TRUTH • PREPARED COBBLER DRY MIX IS RESERVED PREP AND NOT INCLUDED IN LOOSE FLOUR",legacyQty:"~2 cups"},{name:"Cornstarch",qty:"remaining amount unknown after 10 g used",notes:"10 g used Monday; starting quantity was recorded approximately in cups."},{name:"Bread flour",qty:"~7 cups"},{name:"Powdered sugar",qty:"~2 cups"},{name:"White sugar",qty:"~4 tbsp"},{name:"Panko",qty:"remaining amount unknown after 30 g used",notes:"30 g used Monday; starting quantity was approximate."},{name:"Green lentils",qty:"16 oz"},{name:"Jiffy corn muffin mix",qty:"2 boxes"},{name:"Quaker Maple & Brown Sugar oatmeal",qty:"16"},{name:"Quaker PROTEIN Maple & Brown Sugar oatmeal",qty:"4"},{name:"Other instant oatmeal",qty:"7 assorted"},{name:"Nature Valley Protein granola",qty:"~3/4 bag"},{name:"Goldfish Pretzels",qty:"full"},{name:"BBQ Pringles",qty:"2.5 oz"},{name:"MadeGood Snickerdoodle",qty:"8"},{name:"Fruit snacks",qty:"21"},{name:"York Peppermint Patty cocoa",qty:"8"},{name:"Regular cocoa",qty:"4"},{name:"Whole almonds",qty:"16 oz"},{name:"Chia seeds",qty:"~1/3 of 32 oz"},{name:"Carb Counter street taco tortillas",qty:"14 unopened"},{name:"Goya black beans",qty:"3 x 439 g"},{name:"Chipotle peppers in adobo",qty:"199 g"},{name:"Dole pineapple tidbits",qty:"20 oz"},{name:"Dairy-free sweetened condensed milk",qty:"2"},{name:"Brookdale corned beef",qty:"12 oz"},{name:"Tomato paste — unopened",qty:"6 oz"},{name:"Bush’s baked beans",qty:"~454 g"},{name:"Old El Paso enchilada sauce",qty:"10 oz"},{name:"Cream-style corn",qty:"14.75 oz"},{name:"Pinto beans",qty:"~15.5 oz"},{name:"Cider vinegar",qty:"on hand"},{name:"Toasted sesame oil",qty:"~1/2"},{name:"Beef tallow",qty:"on hand"},{name:"Mirin",qty:"on hand"},{name:"Soy/all-purpose seasoning",qty:"~1 cup"},{name:"Ghee",qty:"on hand"},{name:"Concord lime juice",qty:"on hand"},{name:"Liquid smoke",qty:"on hand"},{name:"Thai peanut satay",qty:"on hand"},{name:"Pretty Thai peanut stir-fry",qty:"2"},{name:"Coconut gel",qty:"on hand"},{name:"Lea & Perrins Worcestershire",qty:"full"},{name:"Oyster sauce",qty:"full — fish conflict; verify before use"},{name:"Liquid Aminos",qty:"473 mL • FULL",notes:"OCT 1 LIVE COOK ACTUAL • FULL BACKUP REMAINS"},{name:"Balsamic vinegar",qty:"on hand"},{name:"Rice vinegar",qty:"~3/4"},{name:"Hoisin",qty:"full"}],
Seasonings:[{name:"Bay leaves",qty:"on hand"},{name:"Chili powder",qty:"on hand"},{name:"Dried cilantro",qty:"on hand"},{name:"Onion powder",qty:"on hand"},{name:"Oregano",qty:"on hand"},{name:"Paprika",qty:"on hand"},{name:"Poppy seed",qty:"on hand"},{name:"Taco seasoning",qty:"on hand"},{name:"Seasoned salt",qty:"on hand"},{name:"Sazón / Savory Crust",qty:"on hand"},{name:"Sea salt",qty:"on hand"},{name:"Himalayan pink salt",qty:"on hand"},{name:"Rosemary",qty:"on hand"},{name:"Pumpkin pie spice",qty:"on hand"},{name:"Poultry seasoning",qty:"on hand"},{name:"Thyme",qty:"on hand"},{name:"Turmeric",qty:"on hand"},{name:"White sesame",qty:"on hand"},{name:"Chicken bouillon",qty:"on hand"},{name:"Cumin",qty:"on hand"},{name:"Goya Sazón",qty:"12"},{name:"Caribbean jerk",qty:"on hand"},{name:"Hidden Valley Black Pepper Parmesan Ranch",qty:"2"},{name:"Chili seasoning",qty:"on hand"},{name:"Morton Nature’s Seasons",qty:"212 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW"},{name:"Cinnamon sugar",qty:"122 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"Brand not confirmed; keep generic until identified"},{name:"Baking powder",qty:"~460 g total across ~2 containers",expires:"Estimated Sep 30, 2027",expiryType:"ESTIMATED QUALITY WINDOW",notes:"Plenty on hand; includes new 230 g Great Value container"},{name:"Baking soda",qty:"0 — OUT",notes:"Separate ingredient from baking powder; restock only when needed"},{name:"Ground cloves",qty:"51 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"Brand not confirmed"},{name:"Italian seasoning",qty:"27 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"Brand not confirmed"},{name:"Great Value garlic powder",qty:"96 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW"},{name:"Garlic salt",qty:"85 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"Brand not confirmed"},{name:"Great Value black pepper",qty:"170 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW"},{name:"Ground ginger",qty:"42 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"Brand not confirmed"},{name:"Cream of tartar",qty:"on hand",notes:"Confirmed on hand; not a restock"},{name:"RESTOCK — lemon pepper",qty:"needed"},{name:"RESTOCK — Mexican seasoning (green cap)",qty:"needed"}],
Containers:[]},actualFood:{},budget:{balance:2.63,balanceAsOf:"2026-09-28",expectedIncome:0,unplanned:[],buys:{},emergency:{},beautyByMonth:{}},wish:{},history:[],checks:{},routineV2:{},routineStatus:{},routineSnapshots:{},cookLog:{},cookDraft:{},foodHistory:[],gymLog:{},goalHistory:{},groceryPrices:{}}}
function mergeCurrentStateDefaults(current,saved){
 if(saved===null||saved===undefined)return current;
 if(Array.isArray(current))return Array.isArray(saved)?saved:current;
 if(typeof current==="object"&&current){
   let out={...current};
   if(saved&&typeof saved==="object"&&!Array.isArray(saved)){
     Object.keys(saved).forEach(k=>{
       if(Object.prototype.hasOwnProperty.call(current,k))out[k]=mergeCurrentStateDefaults(current[k],saved[k]);
       else out[k]=saved[k];
     });
   }
   return out;
 }
 return saved;
}
const LEGACY_SKEY="emmelliHubClean";
const DURABLE_LEGACY_KEYS=[
 "goals","water","weight","measure","studyNotes","studyResources","bible","run","gym",
 "actualFood","wish","foodHistory","gymLog","goalHistory","groceryPrices",
 "groceryCustom","groceryBarcodes","rawPortions","nutritionFacts","mondayHaul",
 "treadmill",
];
function importDurableLegacyStateV1(fresh){
 try{
   if(localStorage.getItem(SKEY))return fresh;
   const old=JSON.parse(localStorage.getItem(LEGACY_SKEY)||"null");
   if(!old||typeof old!=="object")return fresh;
   DURABLE_LEGACY_KEYS.forEach(k=>{
     if(old[k]!==undefined)fresh[k]=mergeCurrentStateDefaults(fresh[k],old[k]);
   });
   fresh.checks=fresh.checks||{};
   fresh.checks["migration|newGenerationStorage|2026-09-30"]=true;
   return fresh;
 }catch(e){return fresh}
}
let state=(()=>{try{
 const existing=JSON.parse(localStorage.getItem(SKEY)||"null");
 if(existing&&typeof existing==="object")return mergeCurrentStateDefaults(base(),existing);
 return importDurableLegacyStateV1(base());
}catch(e){return base()}})();
let uiSheet=null;
let uiToast=null,toastTimer=null;
function showToast(message,title=""){uiToast={message:String(message||""),title:String(title||"")};render();clearTimeout(toastTimer);toastTimer=setTimeout(()=>{uiToast=null;render()},2800)}
function toastMarkup(){return uiToast?`<div class="app-toast" role="status" aria-live="polite">${uiToast.title?`<b>${esc(uiToast.title)}</b>`:""}<span>${esc(uiToast.message).replace(/\n/g,"<br>")}</span></div>`:""}
function askConfirm(title,message,action,confirmText="Remove"){uiSheet={type:"confirm",title,message,action,confirmText};render()}
(function migrateLegacy(){
 try{
  let cats=["Fridge","Freezer","Pantry","Seasonings","Containers"],hasCurrent=!!localStorage.getItem(SKEY);
  if(!hasCurrent){
   let old=JSON.parse(localStorage.getItem("v87inventory")||"[]");
   if(Array.isArray(old)&&old.length){
    cats.forEach(c=>state.inventory[c]=[]);
    old.filter(x=>x&&x.item).forEach(x=>{
      let name=[x.brand,x.item].filter(Boolean).join(" — "),qty=[x.qty,x.unit].filter(Boolean).join(" ");
      let season=/season|pepper|paprika|cumin|oregano|thyme|turmeric|cinnamon|nutmeg|rosemary|salt|bouillon|curry|poultry/i.test(x.item||"");
      let cat=season?"Seasonings":({FRIDGE:"Fridge",FREEZER:"Freezer",PANTRY:"Pantry"}[String(x.place||"").toUpperCase()]||"Pantry");
      state.inventory[cat].push({name,qty,brand:x.brand||"",opened:x.opened||"",expires:x.expires||"",notes:x.notes||""});
    });
   }
  }
  let oldMain=localStorage.getItem("v197mainbalance");if(!hasCurrent&&oldMain!==null&&Number.isFinite(Number(oldMain)))state.budget.balance=Number(oldMain);
 }catch(e){}
})();
function validDateKeyRaw(x){if(!/^\d{4}-\d{2}-\d{2}$/.test(String(x||"")))return false;let [y,m,d]=String(x).split("-").map(Number),z=new Date(y,m-1,d,12);return z.getFullYear()===y&&z.getMonth()===m-1&&z.getDate()===d}
function normalizeState(){state.hubSchemaVersion=400;let objs=["routine","water","weight","measure","studyNotes","studyResources","run","gym","actualFood","wish","checks","routineV2","routineStatus","routineSnapshots","routineStarts","cookLog","cookDraft","gymLog","goalHistory","groceryPrices","groceryCustom","groceryBarcodes","gymTargets","gymUndo","goalsByDate","routineDates","mondayHaul","rawPortions","nutritionFacts"];objs.forEach(k=>{if(!state[k]||Array.isArray(state[k])||typeof state[k]!=="object")state[k]={}});if(!state.bible||Array.isArray(state.bible)||typeof state.bible!=="object")state.bible={};if(!Array.isArray(state.goals))state.goals=[];if(!Array.isArray(state.foodHistory))state.foodHistory=[];if(!state.inventory||typeof state.inventory!=="object"||Array.isArray(state.inventory))state.inventory={};["Fridge","Freezer","Pantry","Seasonings","Containers"].forEach(k=>{if(!Array.isArray(state.inventory[k]))state.inventory[k]=[]});if(!["Fridge","Freezer","Pantry","Seasonings","Containers"].includes(state.inventoryTab))state.inventoryTab="Fridge";if(typeof state.inventorySearch!=="string")state.inventorySearch="";if(!Number.isInteger(state.day)||state.day<0||state.day>6)state.day=(new Date().getDay()+6)%7;if(!Number.isInteger(state.weekOffset))state.weekOffset=0;if(!state.budget||typeof state.budget!=="object"||Array.isArray(state.budget))state.budget={};["buys","emergency","unplannedByMonth","beautyByMonth","supportByMonth","outstandingByMonth","autopayOverrides"].forEach(k=>{if(!state.budget[k]||typeof state.budget[k]!=="object"||Array.isArray(state.budget[k]))state.budget[k]={}});if(!Array.isArray(state.budget.unplanned))state.budget.unplanned=[];Object.keys(state.budget.buys).forEach(k=>{if(!Array.isArray(state.budget.buys[k]))state.budget.buys[k]=[]});Object.keys(state.budget.unplannedByMonth).forEach(k=>{if(!Array.isArray(state.budget.unplannedByMonth[k]))state.budget.unplannedByMonth[k]=[]});Object.keys(state.budget.emergency).forEach(k=>{let e=state.budget.emergency[k];if(!e||typeof e!=="object"||Array.isArray(e))state.budget.emergency[k]={on:false,skip:{}};else if(!e.skip||typeof e.skip!=="object"||Array.isArray(e.skip))e.skip={}});if(!Number.isFinite(Number(state.budget.balance)))state.budget.balance=2.63;else state.budget.balance=Number(state.budget.balance);if(!validDateKeyRaw(state.budget.balanceAsOf)){state.budget.balance=2.63;state.budget.balanceAsOf="2026-09-28"}if(new Date().getFullYear()===2026&&new Date().getMonth()===8&&state.checks["budgetRule|2026-8|noSuppHair"]===undefined)state.checks["budgetRule|2026-8|noSuppHair"]=true;Object.keys(state.wish).forEach(k=>{if(!Array.isArray(state.wish[k]))state.wish[k]=[]});if(!["today","food","gym","budget","history","wish"].includes(state.route))state.route="today";if(state.sub!=null&&typeof state.sub!=="string")state.sub=null;let allowedSubs={today:["routine","faith","goals","school","weigh","measure","reset"],food:["inventory","grocery","cook","todayfood","mealplan"],gym:["run","body"]};if(allowedSubs[state.route]&&state.sub&&!allowedSubs[state.route].includes(state.sub))state.sub=null;if(state.route==="history"&&state.sub&&!state.sub.startsWith("hist:"))state.sub=null;if(state.route==="budget"&&state.sub&&!/^(year:|month:|week:|buy:|unplanned:|emergency:|weeks:)/.test(state.sub))state.sub=null;if(state.route==="wish"&&state.sub&&!state.sub.startsWith("wish:"))state.sub=null;if(state.route==="history"&&state.sub?.startsWith("hist:")){let p=state.sub.split(":");if(!["complete","bible","goals","school","body","food","gym"].includes(p[1])||!["year","month","week","days","day"].includes(p[2]||"year"))state.sub=null;else if(p[2]==="year"&&p.length!==3)state.sub=null;else if(p[2]==="month"&&(!/^\d{4}$/.test(p[3]||"")||p.length!==4))state.sub=null;else if(p[2]==="week"&&(!/^\d{4}-(0[1-9]|1[0-2])$/.test(p[3]||"")||p.length!==4))state.sub=null;else if(p[2]==="days"){let v=p.slice(3).join(":"),q=v.split("|");if(q.length!==2||!/^\d{4}-(0[1-9]|1[0-2])$/.test(q[0])||!validDateKeyRaw(q[1]))state.sub=null}else if(p[2]==="day"&&(!validDateKeyRaw(p[3])||p.length!==4))state.sub=null}if(state.route==="budget"&&state.sub){let p=state.sub.split(":");if(p[0]==="year"&&(!/^\d{4}$/.test(p[1]||"")||p.length!==2))state.sub=null;else if(p[0]==="month"&&(!/^\d{4}$/.test(p[1]||"")||!/^\d{1,2}$/.test(p[2]||"")||+p[2]<0||+p[2]>11||p.length!==3))state.sub=null;else if(p[0]==="week"&&(!/^\d{4}$/.test(p[1]||"")||!/^\d{1,2}$/.test(p[2]||"")||+p[2]<0||+p[2]>11||!/^\d+$/.test(p[3]||"")||+p[3]<1||+p[3]>6||p.length!==4))state.sub=null;else if(["buy","unplanned","emergency","weeks"].includes(p[0])&&(!/^\d{4}$/.test(p[1]||"")||!/^\d{1,2}$/.test(p[2]||"")||+p[2]<0||+p[2]>11||!["budget","month"].includes(p[3]||"")||p.length!==4))state.sub=null}if(state.route==="wish"&&state.sub?.startsWith("wish:")&&!["Clothes","Shoes","Jewelry","Dogs","Jeremiah","Home","Miscellaneous","Car"].includes(state.sub.slice(5)))state.sub=null}
function sanitizeNestedState(){
 const obj=x=>x&&typeof x==="object"&&!Array.isArray(x), num=x=>Number.isFinite(Number(x));
 ["Fridge","Freezer","Pantry","Seasonings","Containers"].forEach(c=>{state.inventory[c]=(state.inventory[c]||[]).filter(obj).map(x=>{let name=String(x.name||"").trim();return {...x,name,qty:String(x.qty??""),useSoon:x.useSoon===undefined?/older|opened|partial|sourdough|joseph.s pita|limes|kirkland honey|rice vinegar/i.test(name):!!x.useSoon}}).filter(x=>x.name)});
 Object.keys(state.wish).forEach(c=>{state.wish[c]=(state.wish[c]||[]).filter(obj).map(x=>({item:String(x.item||"").trim(),price:Math.max(0,num(x.price)?Number(x.price):0),link:safeLink(x.link),done:!!x.done})).filter(x=>x.item)});
 Object.keys(state.budget.buys).forEach(k=>{state.budget.buys[k]=(state.budget.buys[k]||[]).filter(obj).map(x=>({item:String(x.item||"").trim(),price:Math.max(0,num(x.price)?Number(x.price):0)})).filter(x=>x.item)});
 Object.keys(state.budget.unplannedByMonth).forEach(k=>{state.budget.unplannedByMonth[k]=(state.budget.unplannedByMonth[k]||[]).filter(obj).map(x=>({item:String(x.item||"").trim(),amount:Math.max(0,num(x.amount)?Number(x.amount):0),day:Math.max(1,Math.min(31,Math.trunc(num(x.day)?Number(x.day):1)))})).filter(x=>x.item&&x.amount>0)});
 Object.keys(state.budget.beautyByMonth||{}).forEach(k=>{let b=state.budget.beautyByMonth[k];if(!obj(b)){state.budget.beautyByMonth[k]={};return}["nails","eyebrows"].forEach(kind=>{let x=b[kind];if(!obj(x)){delete b[kind];return}let amount=Math.max(0,num(x.amount)?Number(x.amount):0),date=validDateKeyRaw(x.date)?x.date:"";b[kind]={amount,date,done:!!x.done}})});
 state.foodHistory=(state.foodHistory||[]).filter(obj).filter(x=>validDateKeyRaw(String(x.date||"").slice(0,10))).map(x=>({...x,date:String(x.date).slice(0,10),type:String(x.type||"Food"),recipe:String(x.recipe||""),container:String(x.container||"")}));
 Object.keys(state.goalsByDate).forEach(k=>{if(!validDateKeyRaw(k)){delete state.goalsByDate[k];return}state.goalsByDate[k]=(state.goalsByDate[k]||[]).filter(obj).map(g=>({text:String(g.text||"").trim(),important:!!g.important})).filter(g=>g.text)});
 Object.keys(state.goalHistory).forEach(k=>{if(!validDateKeyRaw(k)||!obj(state.goalHistory[k])){delete state.goalHistory[k];return}Object.keys(state.goalHistory[k]).forEach(i=>{let g=state.goalHistory[k][i];if(!obj(g))delete state.goalHistory[k][i];else state.goalHistory[k][i]={text:String(g.text||""),done:!!g.done,important:!!g.important}})});
 Object.keys(state.weight).forEach(k=>{if(!validDateKeyRaw(k)||(state.weight[k]!==""&&!num(state.weight[k])))delete state.weight[k];else if(state.weight[k]!=="")state.weight[k]=Math.max(0,Number(state.weight[k]))});
 Object.keys(state.measure).forEach(k=>{if(!validDateKeyRaw(k)||!obj(state.measure[k])){delete state.measure[k];return}Object.keys(state.measure[k]).forEach(f=>{let v=state.measure[k][f];state.measure[k][f]=v===""?"":(num(v)?Math.max(0,Number(v)):"")})});
 Object.keys(state.studyNotes).forEach(k=>{if(!validDateKeyRaw(k)||typeof state.studyNotes[k]!=="string")delete state.studyNotes[k]});
 Object.keys(state.studyResources).forEach(k=>{if(!validDateKeyRaw(k)||typeof state.studyResources[k]!=="string")delete state.studyResources[k];else state.studyResources[k]=state.studyResources[k].trim();if(state.studyResources[k]==="")delete state.studyResources[k]});
 Object.keys(state.bible).forEach(k=>{let b=state.bible[k];if(!validDateKeyRaw(k)||!obj(b)||!Array.isArray(b.entries)){delete state.bible[k];return}b.entries=b.entries.slice(0,4).map(x=>String(x||""));if(!b.entries.some(v=>v.trim()))delete state.bible[k];});
 Object.keys(state.actualFood).forEach(k=>{let a=state.actualFood[k];if(!validDateKeyRaw(k)||!obj(a)){delete state.actualFood[k];return}Object.keys(a).forEach(f=>{let v=a[f];a[f]=v===""?"":(num(v)?Math.max(0,Number(v)):"")})});
 Object.keys(state.run).forEach(k=>{let r=state.run[k];if(!validDateKeyRaw(k)||!obj(r)){delete state.run[k];return}["incline","speed","duration"].forEach(f=>r[f]=num(r[f])?Math.max(0,Number(r[f])):0)});
 Object.keys(state.gymLog).forEach(k=>{let g=state.gymLog[k];if(!validDateKeyRaw(k)||!obj(g)){delete state.gymLog[k];return}Object.keys(g).forEach(n=>{if(!obj(g[n]))delete g[n]})});
 Object.keys(state.routineStatus).forEach(k=>{if(!validDateKeyRaw(k)||!obj(state.routineStatus[k]))delete state.routineStatus[k]});
 Object.keys(state.routineStarts).forEach(k=>{if(!validDateKeyRaw(k)||!num(state.routineStarts[k]))delete state.routineStarts[k];else state.routineStarts[k]=Number(state.routineStarts[k])});
 Object.keys(state.routineDates||{}).forEach(k=>{let q=state.routineDates[k];if(!validDateKeyRaw(k)||!obj(q)||!Array.isArray(q.tasks)){delete state.routineDates[k];return}q.start=num(q.start)?Number(q.start):routineStart(q.day);q.open=String(q.open||"Morning");q.tasks=q.tasks.filter(obj).map(t=>({...t,id:String(t.id||""),name:String(t.name||""),duration:num(t.duration)?Math.max(0,Number(t.duration)):0,section:String(t.section||"Day"),customFixed:(t.customFixed&&num(t.customFixed.st)&&num(t.customFixed.en))?{st:Number(t.customFixed.st),en:Number(t.customFixed.en)}:null,subtasks:Array.isArray(t.subtasks)?t.subtasks.filter(obj).map(z=>({...z,id:String(z.id||""),name:String(z.name||"")})).filter(z=>z.id&&z.name):[]})).filter(t=>t.id&&t.name)});
 Object.keys(state.routineSnapshots).forEach(k=>{let q=state.routineSnapshots[k];if(!validDateKeyRaw(k)||!obj(q)||!Array.isArray(q.tasks)){delete state.routineSnapshots[k];return}q.tasks=q.tasks.filter(obj).map(t=>({...t,id:String(t.id||""),name:String(t.name||""),duration:num(t.duration)?Math.max(0,Number(t.duration)):0,done:!!t.done,customFixed:t.customFixed||null,subtasks:Array.isArray(t.subtasks)?t.subtasks.filter(obj).map(z=>({...z,id:String(z.id||""),name:String(z.name||""),done:!!z.done})):[]})).filter(t=>t.id&&t.name)});
 DAYS.forEach(d=>{let rd=state.routineV2[d];if(rd==null)return;if(!obj(rd)||!Array.isArray(rd.tasks)||rd.tasks.some(t=>!obj(t)||!t.id||!t.name)){delete state.routineV2[d];return}rd.start=num(rd.start)?Number(rd.start):routineStart(d);rd.tasks=rd.tasks.map(t=>({...t,id:String(t.id),name:String(t.name),duration:num(t.duration)?Math.max(0,Number(t.duration)):0,section:String(t.section||"Day"),done:!!t.done,customFixed:(t.customFixed&&num(t.customFixed.st)&&num(t.customFixed.en))?{st:Number(t.customFixed.st),en:Number(t.customFixed.en)}:null,subtasks:Array.isArray(t.subtasks)?t.subtasks.filter(obj).filter(z=>z.id&&z.name).map(z=>({...z,id:String(z.id),name:String(z.name),done:!!z.done})):[]}))});
 Object.keys(state.water).forEach(k=>{let m=k.match(/^(\d{4}-\d{2}-\d{2})\|([1-5])$/);if(!m||!validDateKeyRaw(m[1]))delete state.water[k];else state.water[k]=!!state.water[k]});
}
let uidSeq=0;function uid(prefix){uidSeq=(uidSeq+1)%1000000;return prefix+Date.now().toString(36)+uidSeq.toString(36)}
normalizeState();sanitizeNestedState();
function applyMondayCookSync(){
 const mark="sync|2026-09-28|mondayCookedV2";if(state.checks[mark])return;
 const recipes=["Beef & Broccoli Garlic Noodles","Marry Me Chicken Meatballs"];
 recipes.forEach(recipe=>{let tx=`2026-09-28|${recipe}`;state.cookLog[tx]={...(state.cookLog[tx]||{}),date:"2026-09-28",day:"Monday",recipe,status:"awaitingPacking",inventorySynced:true,actual:{},finishedAt:state.cookLog[tx]?.finishedAt||"2026-09-28T22:24:00-04:00"};delete state.cookDraft[tx]});
 state.inventory.Containers=(state.inventory.Containers||[]).filter(x=>!(x.created==="2026-09-28"&&recipes.includes(x.recipe)));
 state.foodHistory=(state.foodHistory||[]).filter(x=>!((x.date||"").slice(0,10)==="2026-09-28"&&recipes.includes(x.recipe)&&x.type==="COOKED"));
 recipes.forEach(recipe=>state.foodHistory.push({id:uid("food"),date:"2026-09-28",type:"COOKED — AWAITING WEIGHTS/PACKING",recipe,containers:0}));
 delete state.actualFood["2026-09-28"];
 state.checks[mark]=true;localStorage.setItem(SKEY,JSON.stringify(state));
}
applyMondayCookSync();
function applyMondayActualContainersV1(){
 const mark="migration|mondayActualContainersV5|2026-09-29";
 if(state.checks?.[mark])return;
 state.checks=state.checks||{};
 state.inventory=state.inventory||{};state.inventory.Containers=state.inventory.Containers||[];
 const add=(recipe,i,target,main,side,mainLabel,sideLabel)=>{
   state.inventory.Containers=state.inventory.Containers.filter(x=>!(x.created==="2026-09-28"&&x.recipe===recipe&&x.name===`${recipe} • Container ${i}`));
   let parts=[];
   if(main!=null)parts.push(`${mainLabel||"MAIN"} ${main} g`);
   if(side!=null)parts.push(`${sideLabel||"SIDE"} ${side} g`);
   state.inventory.Containers.push({
     name:`${recipe} • Container ${i}`,
     qty:`${target.storage} • EAT ${shortDayDate(target.date)} ${target.meal} • ${parts.join(" • ")}`,
     storage:target.storage,eat:shortDayDate(target.date),meal:target.meal,
     labelRows:physicalLabel(target),recipe,created:"2026-09-28",
     gramsMain:main,gramsSide:side,
     weightLabels:{main:mainLabel||"MAIN",side:sideLabel||"SIDE"}
   });
 };
 // Four physical containers were made total: 2 beef + 2 chicken.
 // Tuesday's beef and chicken containers were eaten as planned; the second of each recipe remains for its later meal.
 state.inventory.Containers=state.inventory.Containers.filter(x=>!(x.created==="2026-09-28"&&["Beef & Broccoli Garlic Noodles","Marry Me Chicken Meatballs"].includes(x.recipe)));
 add("Beef & Broccoli Garlic Noodles",2,{date:"2026-10-02",meal:"LUNCH",storage:"FREEZER"},736,null,"FINISHED DISH",null);
 add("Marry Me Chicken Meatballs",2,{date:"2026-10-03",meal:"LUNCH",storage:"FREEZER"},272,140,"MEATBALLS","SAUCE");
 state.foodHistory=(state.foodHistory||[]).filter(x=>!((x.date||"").slice(0,10)==="2026-09-28"&&["Beef & Broccoli Garlic Noodles","Marry Me Chicken Meatballs"].includes(x.recipe)&&String(x.type||"").startsWith("COOKED")));
 state.foodHistory.push({id:uid("food"),date:"2026-09-28",type:"COOKED + PACKED",recipe:"Beef & Broccoli Garlic Noodles",containers:2,totalFinishedGrams:1472,gramsPerContainer:736});
 state.foodHistory.push({id:uid("food"),date:"2026-09-28",type:"COOKED + PACKED",recipe:"Marry Me Chicken Meatballs",containers:2,meatballsTotalGrams:544,meatballsPerContainerGrams:272,sauceTotalGrams:280,saucePerContainerGrams:140});
 state.foodHistory.push({id:uid("food"),date:"2026-09-29",type:"EATEN",recipe:"Beef & Broccoli Garlic Noodles",containers:1,grams:736,meal:"LUNCH"});
 state.foodHistory.push({id:uid("food"),date:"2026-09-29",type:"EATEN",recipe:"Marry Me Chicken Meatballs",containers:1,meatballsGrams:272,sauceGrams:140,meal:"DINNER"});
 state.checks[mark]=true;
 localStorage.setItem(SKEY,JSON.stringify(state));
}

function applyPreparedContainerMacrosSep29(){
 const mark="migration|preparedContainerMacrosSep29V2|2026-09-29";if(localStorage.getItem(mark))return;
 let beef=(state.inventory.Containers||[]).find(x=>x.id==="actual-beef-noodles-remaining-20260929");
 if(beef)Object.assign(beef,{macros:{calories:1024,protein:74.4,carbs:81.4,fat:46.1,fiber:5.9},nutritionComplete:true,macroSource:"Monday recipe ingredients + actual 1472 g finished batch / 2 equal 736 g containers"});
 let chicken=(state.inventory.Containers||[]).find(x=>x.id==="actual-marry-me-meatballs-remaining-20260929");
 if(chicken)Object.assign(chicken,{macros:{calories:1163.8,protein:74.6,carbs:94.5,fat:54.5,fiber:6.6},nutritionComplete:true,macroSource:"272 g cooked meatballs + 140 g sauce + pasta from 85 g dry-pasta equivalent (170 g dry recipe pasta divided equally across 2 portions). Cooked pasta gram weight is intentionally not invented."});
 localStorage.setItem(mark,"1");save()
}
function applyPreparedContainerTruthSep29(){
 const mark="migration|preparedContainerTruthSep29V2|2026-09-29";if(localStorage.getItem(mark))return;
 state.inventory.Containers=(state.inventory.Containers||[]).filter(x=>!["Beef & Broccoli Garlic Noodles","Marry Me Chicken Meatballs"].some(n=>String(x.name||x.recipe||"").startsWith(n)));
 state.inventory.Containers.push({
   id:"actual-beef-noodles-remaining-20260929",name:"Beef & Broccoli Garlic Noodles",qty:"736 g",count:1,
   storage:"FREEZER",date:"2026-10-02",useDate:"2026-10-02",component:"FINISHED DISH",
   labelRows:["FRI 10/2","FREEZER","THAW THU"],
   notes:"ONE remaining container from Monday 9/28 cooking. Tuesday 9/29 portion was already eaten. Do not recreate or duplicate."
 });
 state.inventory.Containers.push({
   id:"actual-marry-me-meatballs-remaining-20260929",name:"Marry Me Chicken Meatballs",qty:"272 g meatballs + 140 g sauce + pasta from 85 g dry equivalent",count:1,
   storage:"FREEZER",date:"2026-10-03",useDate:"2026-10-03",mainGrams:272,sideGrams:140,component:"MEATBALLS + SAUCE",
   labelRows:["SAT 10/3","FREEZER","THAW FRI"],
   notes:"ONE remaining container from Monday 9/28 cooking. Tuesday 9/29 portion was already eaten. Do not recreate or duplicate."
 });
 localStorage.setItem(mark,"1");save()
}

applyMondayActualContainersV1();
function applySep28BudgetSync(){
 const mark="sync|2026-09-29|budgetSupportV1";if(state.checks[mark])return;
 state.budget.balance=2.63;state.budget.balanceAsOf="2026-09-28";
 state.budget.beautyByMonth=state.budget.beautyByMonth||{};
 state.budget.supportByMonth=state.budget.supportByMonth||{};
 state.budget.unplannedByMonth=state.budget.unplannedByMonth||{};
 state.budget.beautyByMonth["2026-8"]={...(state.budget.beautyByMonth["2026-8"]||{}),nails:{amount:215,date:"2026-09-28",done:true},eyebrows:{amount:160,date:"2026-09-19",done:true}};
 if(state.budget.beautyByMonth["2026-9"]?.eyebrows){delete state.budget.beautyByMonth["2026-9"].eyebrows;}
 // September Jeremiah support was already received before/inside the previously established live-balance anchor, so do not add it again to projected cash flow.
 state.budget.supportByMonth["2026-8"]={...(state.budget.supportByMonth["2026-8"]||{}),carInsurance:{amount:100,date:"",received:true,absorbedIntoAnchor:true},phone:{amount:100,date:"",received:true,absorbedIntoAnchor:true}};
 // September Car Insurance and FPL were still unpaid after the 9/28 balance anchor. Carry them forward as outstanding obligations.
 let sep=state.budget.unplannedByMonth["2026-8"]||[];
 sep=sep.filter(x=>!(["September Car Insurance — still due","September FPL — still due"].includes(x.item)));
 sep.push({item:"September Car Insurance — still due",amount:200,day:29,carryover:true});
 sep.push({item:"September FPL — still due",amount:55,day:29,carryover:true});
 state.budget.unplannedByMonth["2026-8"]=sep;
 state.checks[mark]=true;localStorage.setItem(SKEY,JSON.stringify(state));
}
applySep28BudgetSync();
function applyBudgetAuditV2(){
 const mark="sync|2026-09-29|budgetAuditV2";if(state.checks[mark])return;
 state.budget.outstandingByMonth=state.budget.outstandingByMonth||{};
 // Move September unpaid fixed bills out of generic Unplanned Spending and into true outstanding obligations.
 let sep=state.budget.unplannedByMonth["2026-8"]||[];
 sep=sep.filter(x=>!(["September Car Insurance — still due","September FPL — still due"].includes(x.item)));
 state.budget.unplannedByMonth["2026-8"]=sep;
 state.budget.outstandingByMonth["2026-8"]=[
   {name:"Car Insurance",amount:200,carryDate:"2026-09-29",originalDate:"2026-09-09"},
   {name:"FPL",amount:55,carryDate:"2026-09-29",originalDate:"2026-09-25"}
 ];
 state.checks[mark]=true;localStorage.setItem(SKEY,JSON.stringify(state));
}
applyBudgetAuditV2();
function applyBudgetUpdateSep28PaidFPL(){
 const mark="sync|2026-09-29|budgetUpdatePaidFPLV3";if(state.checks[mark])return;
 state.budget.balance=2.63;
 state.budget.balanceAsOf="2026-09-28";
 state.budget.outstandingByMonth=state.budget.outstandingByMonth||{};
 state.budget.unplannedByMonth=state.budget.unplannedByMonth||{};
 // FPL was paid on 9/28. It must not remain as a carried unpaid obligation.
 for(const mk of Object.keys(state.budget.outstandingByMonth)){
   state.budget.outstandingByMonth[mk]=(state.budget.outstandingByMonth[mk]||[]).filter(x=>x.name!=="FPL");
 }
 for(const mk of Object.keys(state.budget.unplannedByMonth)){
   state.budget.unplannedByMonth[mk]=(state.budget.unplannedByMonth[mk]||[]).filter(x=>!String(x.item||"").includes("FPL"));
 }
 // The recurring FPL amount is permanently $100/month. September is already paid.
 state.checks["autopay|2026-09-25|FPL|100.00"]=true;
 state.checks[mark]=true;
 localStorage.setItem(SKEY,JSON.stringify(state));
}
applyBudgetUpdateSep28PaidFPL();

function goalsForDate(k=selectedKey()){if(!Array.isArray(state.goalsByDate[k]))state.goalsByDate[k]=[];return state.goalsByDate[k]}
function openGoalsThroughSelectedDay(k=selectedKey()){
 let sel=new Date(k+"T12:00:00"),dow=(sel.getDay()+6)%7,mon=new Date(sel);mon.setDate(sel.getDate()-dow);let rows=[];
 for(let n=0;n<=dow;n++){let dt=new Date(mon);dt.setDate(mon.getDate()+n);let dk=localDateKey(dt),list=state.goalsByDate[dk]||[],hist=state.goalHistory[dk]||{};list.forEach((g,i)=>{if(g&&g.text&&!hist[i]?.done)rows.push({date:dk,index:i,text:g.text,important:!!g.important,origin:n===dow?"Today":DAYS[n]})})}
 return rows
}
if(Array.isArray(state.goals)&&state.goals.length&&!Object.keys(state.goalsByDate).length){state.goalsByDate[selectedKey()]=state.goals.map(g=>({text:String(g?.text||""),important:!!g?.important})).filter(g=>g.text);state.goals=[];save()}

function save(){localStorage.setItem(SKEY,JSON.stringify(state))}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function key(){let d=new Date(),y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,"0"),q=String(d.getDate()).padStart(2,"0");return `${y}-${m}-${q}`}
function selectedKey(){let now=new Date(),mon=new Date(now);mon.setHours(12,0,0,0);mon.setDate(now.getDate()-((now.getDay()+6)%7)+state.day+(state.weekOffset||0)*7);let y=mon.getFullYear(),m=String(mon.getMonth()+1).padStart(2,"0"),d=String(mon.getDate()).padStart(2,"0");return `${y}-${m}-${d}`}
function money(n){let v=Number(n);if(!Number.isFinite(v))v=0;return (v<0?"-$":"$")+Math.abs(v).toFixed(2)}
function safeLink(v){try{let u=new URL(String(v||""));return /^https?:$/.test(u.protocol)?u.href:""}catch(e){return ""}}
function icon(name){const p={today:'<path d="M4 11l8-7 8 7v9H5z"/><path d="M9 20v-6h6v6"/>',food:'<path d="M7 3v8M4 3v5c0 2 6 2 6 0V3M7 11v10M15 3v18M15 3c4 2 4 8 0 9"/>',gym:'<path d="M3 9v6M7 7v10M17 7v10M21 9v6M7 12h10"/>',budget:'<rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18M16 15h2"/>',history:'<circle cx="12" cy="12" r="9"/><path d="M12 7v6l4 2"/>',wish:'<path d="M12 20S4 15 4 9a4 4 0 017-3 4 4 0 017 3c0 6-8 11-8 11z"/>'};return '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true">'+p[name]+'</svg>'}
function appTop(){requestAnimationFrame(()=>scrollTo({top:0,left:0,behavior:"auto"}))}
function applyPermanentCurrentRequirementsV10(){
 const mark="migration|permanentCurrentRequirementsV10|2026-10-01";
 state.checks=state.checks||{}; if(state.checks[mark])return;
 if(state.routines&&typeof state.routines==="object")Object.values(state.routines).forEach(rd=>{(rd?.tasks||[]).forEach(t=>{if(t?.id==="careN"||/^Night Care$/i.test(String(t?.name||"")))t.duration=30})});
 state.checks[mark]=true; save();
}
applyPermanentCurrentRequirementsV10();

function ensurePermanentV13CurrentRules(){
 const mark="migration|permanentV13CurrentRules|2026-10-01";
 state.checks=state.checks||{};
 if(state.checks[mark])return;
 // Navigation state only; preserve all user data.
 if(state.route==="food" && ![null,"todayfood","mealplan","inventory","grocery","cook"].includes(state.sub))state.sub=null;
 state.checks[mark]=true;
 save();
}
ensurePermanentV13CurrentRules();
function setRoute(r,sub=null){state.route=r;state.sub=sub;save();render();appTop()}
function nav(){let a=[["today","Today"],["food","Food"],["gym","Gym"],["budget","Budget"],["history","History"],["wish","Wish List"]];document.getElementById("nav").innerHTML=a.map(([r,l])=>`<button class="${state.route===r?'on':''}" data-main-route="${r}">${icon(r)}<span>${l}</span></button>`).join("")}
function week(){let sel=new Date(selectedKey()+"T12:00:00"),mon=new Date(sel);mon.setDate(sel.getDate()-state.day);let sun=new Date(mon);sun.setDate(mon.getDate()+6);let label=`${mon.toLocaleDateString("en",{month:"short",day:"numeric"})} – ${sun.toLocaleDateString("en",{month:"short",day:"numeric",year:"numeric"})}`;return `<div class="weeknav"><button class="weekshift" data-week-shift="-1" aria-label="Previous week">‹</button><div class="weekbar">${DAYS.map((d,i)=>`<button class="daybtn ${state.day===i?'on':''}" data-day="${i}">${d.slice(0,3).toUpperCase()}</button>`).join("")}</div><button class="weekshift" data-week-shift="1" aria-label="Next week">›</button><div class="weekrange">${esc(label)}</div></div>`}
function fullSelectedDate(){return new Date(selectedKey()+"T12:00:00").toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric",year:"numeric"})}
function hero(title,sub=""){return `<section class="hero"><div class="eyebrow">${esc(fullSelectedDate())}</div><h1>${esc(title)}</h1>${sub?`<div class="muted">${esc(sub)}</div>`:""}${week()}</section>`}
function back(label="Back"){return `<button class="btn back" data-back="${esc(label)}">‹ ${esc(label)}</button>`}
function note(text){return `<section class="comment-widget"><p>${esc(text)}</p></section>`}
function pageComment(page,day){
 let k=selectedKey(),msg="";
 if(page==="Bible + Faith"){let n=(state.bible[k]?.entries||[]).filter(Boolean).length;msg=n?`${n}/4 Faith sections saved for ${day}.`:`Faith is ready for ${day}. Save only what you actually complete.`}
 else if(page==="Gym"){let log=state.gymLog[k]||{},n=Object.values(log).filter(x=>x&&x.done).length;msg=n?`${n} exercise${n===1?"":"s"} checked complete for ${day}.`:`Use the pink hearts as you finish each exercise on ${day}.`}
 else if(page==="History")msg="History is built from dated saved activity; changing weeks does not rewrite prior dates.";
 else msg=`${page} • ${day}`;
 return `<section class="comment-widget"><p>${esc(msg)}</p></section>`
}
function checkbox(id,label,checked=null){let on=checked===null?!!state.checks[id]:!!checked;return `<label class="checkrow"><input type="checkbox" data-check="${esc(id)}" ${on?"checked":""}><span>${esc(label)}</span></label>`}
function waterTracker(k){return `<div class="watertrack" aria-label="Five water bottles">${[1,2,3,4,5].map(i=>`<label class="waterbottle" aria-label="Water bottle ${i}"><input type="checkbox" data-check="water|${esc(k)}|${i}" ${state.water[k+"|"+i]?"checked":""}><span class="bottleicon" aria-hidden="true"></span><span class="waternum" aria-hidden="true">${i}</span></label>`).join("")}</div>`}
function today(){
 let d=DAYS[state.day], k=selectedKey(), rtl=timeline(d), done=rtl.filter(x=>x.t.done).length, total=rtl.length;
 let openWeekGoals=openGoalsThroughSelectedDay(k),waterDone=[1,2,3,4,5].filter(i=>state.water[k+"|"+i]).length;
 let next=rtl.find(x=>!x.t.done), meal=todayMeal(), signals=[];
 if(next)signals.push(`NEXT: ${next.t.name} • ${fmt(next.st)}–${fmt(next.en)}.`);else signals.push("Routine is complete for this day.");
 if(state.day===1||state.day===3){let r=state.run[k];signals.push(r?.duration?`RUN SAVED: ${r.duration} min • incline ${r.incline} • speed ${r.speed}.`:`RUN TODAY: enter incline, speed, and time when you finish.`)}
 if(meal?.cook?.length)signals.push(`COOKING TODAY: ${meal.cook.length} recipes.`);
 if(meal?.thaw&& !/^Nothing/i.test(meal.thaw))signals.push(`TONIGHT: ${meal.thaw}`);
 let commentaryGoals=openWeekGoals;
 if(commentaryGoals.length)signals.push("GOALS: "+commentaryGoals.map(g=>g.text).join(" • ")+".");
 if(!commentaryGoals.length&&waterDone<5)signals.push(`Water: ${waterDone}/5 bottles.`);
 let contextual=state.day===0
   ?`<button class="tile" data-route="gym"><b>Gym</b><span>Glutes & Quads</span></button>
      <button class="tile" data-sub="measure"><b>Monday Measurements</b><span>Weight • glutes • waist • arms</span></button>
      <button class="tile" data-route="food" data-sub="grocery"><b>Grocery List</b><span>Open Monday grocery list</span></button>`
   :DAY_ACTIVITY[DAYS[state.day]]==="RUN"
   ?`<button class="tile" data-route="gym" data-sub="run"><b>Run</b><span>Enter incline • speed • time</span></button>`
   :[2,4].includes(state.day)
   ?`<button class="tile" data-route="gym"><b>Gym</b><span>${state.day===2?"Upper Body":"Glutes & Hamstrings"}</span></button>`
   :state.day===6
   ?`<button class="tile" data-sub="reset"><b>Sunday Reset</b><span>Home + week reset</span></button>`:"";
 let fullTodayDate=fullSelectedDate();
  return `<section class="hero"><div class="eyebrow">TODAY</div><h1>${esc(fullTodayDate)}</h1>${week()}</section>`+`
 <section class="comment-widget"><p>${esc(signals.join(" "))}</p></section>
 <div class="grid today-destinations">
   <button class="tile" data-sub="routine"><b>Routine</b><span>${done}/${total} complete</span></button>
   <button class="tile" data-sub="faith"><b>Bible + Faith</b><span>Reading • prayer • devotional • reflection</span></button>
   <button class="tile" data-sub="goals"><b>Goals</b><span>Daily goals • important reminders • water</span></button>
   <button class="tile" data-sub="school"><b>Study Today</b><span>${esc(STUDY[d])} • 30 min</span></button>
   <button class="tile" data-sub="weigh"><b>Daily Weigh-In</b><span>Feeds Body Progress + History</span></button>
   <button class="tile" data-route="food" data-sub="todayfood"><b>What I Actually Ate</b><span>Meals at a Glance • actual food • macros</span></button>
   <button class="tile" data-route="food" data-sub="inventory"><b>What’s in the Fridge + Inventory</b><span>Search Fridge • Freezer • Pantry • Seasonings • Containers</span></button>
   ${contextual}
 </div>
 <section class="card today-goals">
   <h2>Open Goals</h2>
   ${openWeekGoals.map(g=>`<label class="checkrow"><input type="checkbox" data-goal-done="${g.index}" data-goal-date="${esc(g.date)}"><span><b>${esc(g.text)}</b>${g.origin!=="Today"?` <small>• from ${esc(g.origin)}</small>`:""}${g.important?" <small>• reminder</small>":""}</span></label>`).join("")||'<p class="muted">No open goals through this day.</p>'}
   ${waterTracker(k)}
   ${checkbox(`daily|${k}|vitamins`,"Vitamins",!!state.checks[`daily|${k}|vitamins`])}
   ${checkbox(`daily|${k}|creatine`,"Creatine",!!state.checks[`daily|${k}|creatine`])}
 </section>
 <aside class="thaw-strip"><b>TONIGHT — FREEZER → FRIDGE</b><span>${esc(meal?.thaw||"Nothing needs to move tonight.")}</span></aside>
 <section class="card receipt-readiness"><h2>RECEIPT READINESS</h2>${(()=>{let r=dayReceiptStatus();return `<p><b>${r.done}/${r.total} REQUIRED ITEMS LOGGED • ${r.pct}%</b></p>${r.missing.length?`<p class="muted">STILL MISSING:<br>${r.missing.map(x=>`• ${esc(x)}`).join("<br>")}</p>`:`<p class="muted">THIS DAY’S REQUIRED RECEIPT ITEMS ARE LOGGED.</p>`}`})()}</section>`;
}
function parseDuration(label){
 let h=(label.match(/(\d+)\s*(?:hr|hour)/i)||[])[1],m=(label.match(/(\d+)\s*min/i)||[])[1],explicit=(+h||0)*60+(+m||0);if(explicit)return explicit;
 let rg=label.match(/(\d{1,2}):(\d{2})\s*(AM|PM)?\s*[–-]\s*(\d{1,2}):(\d{2})\s*(AM|PM)/i);
 if(rg){let sh=+rg[1],sm=+rg[2],sap=(rg[3]||rg[6]).toUpperCase(),eh=+rg[4],em=+rg[5],eap=rg[6].toUpperCase();let cv=(hh,mm,ap)=>(hh%12)+(ap==="PM"?12:0),a=cv(sh,sm,sap)*60+sm,b=cv(eh,em,eap)*60+em;if(b<a)b+=1440;return b-a}
 return 30
}
function fmt(min){min=((min%1440)+1440)%1440;let h=Math.floor(min/60),m=min%60,ap=h>=12?"PM":"AM";h=h%12||12;return `${h}:${String(m).padStart(2,"0")} ${ap}`}
function fixedRange(name){
 let rg=String(name||"").match(/(\d{1,2}):(\d{2})\s*(AM|PM)?\s*[–-]\s*(\d{1,2}):(\d{2})\s*(AM|PM)/i);if(!rg)return null;
 let cv=(h,m,ap)=>{h=+h%12+(String(ap).toUpperCase()==="PM"?12:0);return h*60+(+m)};
 let firstAP=(rg[3]||rg[6]).toUpperCase(),st=cv(rg[1],rg[2],firstAP),en=cv(rg[4],rg[5],rg[6]);if(en<st)en+=1440;return {st,en,duration:en-st}
}
// ROUTINE WAKE LOCK: Wednesday 5:10 AM; Thursday 7:46 AM. The saved hour comes from shortening the old 2 hr 30 min cooking block to 1 hr 30 min; everything after cooking reconnects to the original timetable.
function routineStart(d){let starts={Monday:360,Tuesday:180,Wednesday:310,Thursday:466,Friday:256,Saturday:170,Sunday:170};return starts[d]||360}
function sectionFor(d,text){
 let x=String(text||"").toLowerCase();
 if(d==="Monday")return /night care|night routine/.test(x)?"Night Routine":"Monday Errands";
 if(/night care|night routine/.test(x))return "Night Routine";
 if(/\bwork\b|at work|start of shift|personal time|bag reset|teas math practice|pert math practice|teas reading|teas science \/ weak areas|pert reading|teas english and review mistakes/.test(x))return "While at Work";
 if(/get out of bed|morning start|pet time|morning care|morning routine|where are you|breakfast|tiamo|hercules|pet care|shower|laundry/.test(x))return "Morning";
 return "Afternoon Routine";
}
function routineSectionOrder(d,sections){
 let wanted=d==="Monday"?["Monday Errands","Night Routine"]:["Morning","While at Work","Afternoon Routine","Night Routine"];
 return wanted.filter(x=>sections.includes(x)).concat(sections.filter(x=>!wanted.includes(x)));
}
function initialRoutineDay(d){
 let tasks=[],seq=0;
 (ROUTINE[d]||[]).forEach(raw=>{let dur=parseDuration(raw)||30,text=raw.replace(/\s*[—-]\s*(?:\d+\s*(?:hr|hour)s?(?:\s*\d+\s*min)?|\d+\s*min).*$/i,"").trim();tasks.push({id:"t"+(++seq),name:text,duration:dur,section:sectionFor(d,text),done:false,subtasks:[]})});
 let mi=tasks.findIndex(t=>/^MORNING CARE \/ SHOWER & GET READY$/i.test(t.name));
 if(mi<0&&d==="Monday")mi=tasks.findIndex(t=>/^MORNING CARE \/ SHOWER & GET READY$/i.test(t.name));
 if(mi>=0)tasks[mi]={...tasks[mi],id:"careM",name:"Morning Care / Shower & Get Ready",subtasks:careItems(d,"morning").map((name,i)=>({id:"m"+i,name,done:false}))};
 let ni=tasks.findIndex(t=>/^NIGHT CARE/i.test(t.name));
 if(ni>=0)tasks[ni]={...tasks[ni],id:"careN",name:tasks[ni].name,subtasks:careItems(d,"night").map((name,i)=>({id:"n"+i,name,done:false})),section:"Night Routine"};
 return {start:routineStart(d),tasks,open:"Morning"};
}
function cloneRoutineDay(src){return {start:Number(src.start),open:String(src.open||"Morning"),tasks:(src.tasks||[]).map(t=>({...t,customFixed:t.customFixed?{st:Number(t.customFixed.st),en:Number(t.customFixed.en)}:null,subtasks:(t.subtasks||[]).map(q=>({...q}))}))}}
function rday(d){
 let k=selectedKey();state.routineDates=state.routineDates||{};state.checks=state.checks||{};
 const ver="routineCanonical|2026-10-01|fullSevenDayV1";
 if(!state.routineV2[d]||!Array.isArray(state.routineV2[d].tasks)||!state.checks[ver+"|"+d]){state.routineV2[d]=initialRoutineDay(d);state.checks[ver+"|"+d]=true;}
 state.routineV2[d].start=routineStart(d);
 if(!state.routineDates[k]||state.routineDates[k].day!==d||!Array.isArray(state.routineDates[k].tasks)||!state.routineDates[k].canonicalFullSevenDayV1){
   let old=state.routineDates[k],fresh={day:d,...cloneRoutineDay(state.routineV2[d]),canonicalFullSevenDayV1:true};
   if(old&&Array.isArray(old.tasks)){let errands=old.tasks.filter(t=>String(t.id||"").startsWith("errand"));fresh.tasks.push(...errands)}
   state.routineDates[k]=fresh;
 }
 let rd=state.routineDates[k];rd.start=routineStart(d);delete state.routineStarts[k];
 let status=state.routineStatus[k]||{};rd.tasks.forEach(t=>{t.done=!!status[t.id];(t.subtasks||[]).forEach(q=>q.done=!!status[t.id+"|"+q.id])});return rd;
}
function timeline(d){let rd=rday(d),cur=+(((d==="Wednesday"||d==="Thursday")?rd.start:(state.routineStarts[selectedKey()]??rd.start)))||routineStart(d),conflicts=[];let rows=rd.tasks.map((t,i)=>{let anchor=(!t.errandMeta&&t.customFixed&&Number.isFinite(Number(t.customFixed.st))&&Number.isFinite(Number(t.customFixed.en)))?{st:Number(t.customFixed.st),en:Number(t.customFixed.en)}:fixedRange(t.name),st,en,conflict=false;if(anchor){st=anchor.st;en=anchor.en;if(st<cur){conflict=true;conflicts.push(`${t.name} overlaps the flexible routine by ${cur-st} min`)}cur=Math.max(cur,en)}else{st=cur;en=cur+(+t.duration||0);cur=en}return {t,i,st,en,anchor:!!anchor,conflict}});rows.conflicts=conflicts;return rows}
function saveRoutineSnapshot(d){let k=selectedKey(),rd=rday(d);state.routineSnapshots[k]={day:d,tasks:rd.tasks.map(t=>({id:t.id,name:t.name,duration:t.duration,section:t.section,customFixed:t.customFixed?{st:Number(t.customFixed.st),en:Number(t.customFixed.en)}:null,errandMeta:t.errandMeta?{enteredStart:Number(t.errandMeta.enteredStart),enteredEnd:Number(t.errandMeta.enteredEnd)}:null,done:!!t.done,subtasks:(t.subtasks||[]).map(q=>({id:q.id,name:q.name,done:!!q.done}))}))}}
function routineComment(d,tl){
 let complete=tl.filter(x=>x.t.done).length,total=tl.length,subs=tl.flatMap(x=>x.t.subtasks||[]),sd=subs.filter(x=>x.done).length;
 let msg=complete===0?"Nothing is checked off yet. Start with the first block when you’re ready.":complete===total?"Your Routine is fully checked off for this day.":`${complete}/${total} main blocks complete.`;
 if(tl.conflicts?.length)msg+=` Schedule conflict: ${tl.conflicts[0]}. Shorten or move an earlier flexible block.`;
 if(subs.length)msg+=` Care/subtasks: ${sd}/${subs.length}.`;let mc=tl.find(x=>x.t.id==="careM"),nc=tl.find(x=>x.t.id==="careN");if(mc&&!mc.t.done)msg+=" Morning Care still has unchecked items.";else if(nc&&!nc.t.done)msg+=" Night Care remains for the end of the day.";
 if(selectedKey()===localDateKey()){let overdue=tl.find(x=>!x.t.done&&x.en<new Date().getHours()*60+new Date().getMinutes());if(overdue)msg+=` ${overdue.t.name} is the earliest unfinished block based on the timetable.`;}
 return msg;
}
function parseClock(v){let m=String(v||"").trim().match(/(\d{1,2}):(\d{2})\s*(AM|PM)?/i);if(!m)return null;let h=+m[1],mi=+m[2],ap=(m[3]||"").toUpperCase();if(mi>59||h<1||h>12)return null;if(ap==="PM"&&h<12)h+=12;if(ap==="AM"&&h===12)h=0;return h*60+mi}
function sheetMarkup(){
 if(!uiSheet)return "";
 let d=uiSheet.day||DAYS[state.day],a=rday(d).tasks;
 const shell=(title,subtitle,body,actions)=>`<div class="sheet-backdrop" data-sheet-close><section class="app-sheet" role="dialog" aria-modal="true" aria-label="${esc(title)}" onclick="event.stopPropagation()"><div class="sheet-handle"></div><div class="sheet-head"><div><h2>${esc(title)}</h2><p class="muted">${esc(subtitle)}</p></div><button class="tinybtn" data-sheet-cancel aria-label="Close">×</button></div>${body}<div class="app-actions"><button class="btn" data-sheet-cancel>Cancel</button>${actions}</div></section></div>`;
 if(uiSheet.type==="errand"){
  let editing=Number.isInteger(uiSheet.index),x=editing?a[uiSheet.index]:null,meta=x?.errandMeta||{};
  let defaultAfter=editing?Math.max(0,uiSheet.index-1):Math.max(0,a.findIndex(t=>!t.done)-1);
  let opts=a.map((t,i)=>i===uiSheet.index?"":`<option value="${i}" ${i===defaultAfter?"selected":""}>${i+1}. ${esc(t.name)}</option>`).join("");
  let body=`<div class="sheet-grid"><label class="wide">Last task you completed<select id="errAfter">${opts}</select></label><label class="wide">Errand name<input id="errName" value="${esc(x?.name||"")}" placeholder="Target, pharmacy, appointment…"></label><label>Start time<input id="errStart" value="${meta.enteredStart!=null?fmt(meta.enteredStart):""}" placeholder="1:30 PM"></label><label>End time<input id="errEnd" value="${meta.enteredEnd!=null?fmt(meta.enteredEnd):""}" placeholder="2:10 PM"></label></div><div class="sheet-note errand-recent"><span class="muted">INSERT AFTER</span><br><b>${esc(mostRecentRoutineName())}</b></div><div class="sheet-note"><b>How this works</b><br>The start/end calculate the errand duration. It is inserted immediately after the task you choose, and every later flexible block moves by that duration. Fixed commitments stay fixed and collisions are flagged.</div>`;
  return shell(editing?"Edit Errand":"Add an Errand","This change belongs only to this selected date.",body,`<button class="btn primary" data-sheet-save-errand="${d}" ${editing?`data-sheet-edit-index="${uiSheet.index}"`:""}>${editing?"Save Changes":"Add to Routine"}</button>`)
 }
 if(uiSheet.type==="task"){
  let x=a[uiSheet.index]; if(!x)return "";
  let body=`<div class="sheet-grid"><label class="wide">Task name<input id="taskName" value="${esc(x.name)}"></label><label class="wide">Duration in minutes<input id="taskDuration" type="number" min="0" step="1" value="${Number(x.duration)||0}"></label></div><div class="sheet-note">Editing this block changes only ${esc(selectedKey())}. Later flexible blocks recalculate automatically.</div>`;
  return shell("Edit Routine Block","Keep the selected day’s timeline clean and date-specific.",body,`<button class="btn primary" data-sheet-save-task="${d}" data-sheet-index="${uiSheet.index}">Save Changes</button>`)
 }
 if(uiSheet.type==="subtask"){
  let x=a[uiSheet.index],q=Number.isInteger(uiSheet.subIndex)?x?.subtasks?.[uiSheet.subIndex]:null;if(!x)return "";
  let body=`<div class="sheet-grid"><label class="wide">${q?"Subtask":"New subtask"}<input id="subtaskName" value="${esc(q?.name||"")}" placeholder="What needs to be checked separately?"></label></div><div class="sheet-note">Each subtask keeps its own independent checkmark. Care-parent duration stays unchanged.</div>`;
  return shell(q?"Edit Subtask":"Add Subtask",x.name,body,`<button class="btn primary" data-sheet-save-subtask="${d}" data-sheet-index="${uiSheet.index}" ${q?`data-sheet-sub-index="${uiSheet.subIndex}"`:""}>${q?"Save Changes":"Add Subtask"}</button>`)
 }
 if(uiSheet.type==="wake"){
  let val=state.routineStarts[selectedKey()]??rday(d).start;
  let body=`<div class="sheet-grid"><label class="wide">Actual wake / routine start<input id="wakeTime" value="${fmt(val)}" placeholder="7:18 AM"></label></div><div class="sheet-note">The flexible routine starts from this time for ${esc(selectedKey())}. Fixed commitments do not move; any collision is shown in Routine.</div>`;
  return shell("I Woke Up Late","Shift this date’s flexible schedule from your actual wake time.",body,`<button class="btn primary" data-sheet-save-wake="${d}">Update Routine</button>`)
 }
 if(uiSheet.type==="goalEdit"){let x=goalsForDate(uiSheet.key)[uiSheet.index];if(!x)return "";return shell("Edit Goal","This date only.",`<div class="sheet-grid"><label class="wide">Goal<input id="sheetGoalText" value="${esc(x.text)}"></label></div>`,`<button class="btn primary" data-sheet-save-goal>Save Changes</button>`)}
 if(uiSheet.type==="wishEdit"){let x=state.wish[uiSheet.cat]?.[uiSheet.index];if(!x)return "";return shell("Edit Wish Item",uiSheet.cat,`<div class="sheet-grid"><label class="wide">Item<input id="sheetWishItem" value="${esc(x.item)}"></label><label>Price<input id="sheetWishPrice" type="number" min="0" step=".01" value="${esc(x.price??"")}"></label><label class="wide">Optional link<input id="sheetWishLink" type="url" value="${esc(x.link||"")}"></label></div>`,`<button class="btn primary" data-sheet-save-wish>Save Changes</button>`)}
 if(uiSheet.type==="invEdit"){let x=state.inventory[uiSheet.cat]?.[uiSheet.index];if(!x)return "";return shell("Edit Inventory Item",uiSheet.cat,`<div class="sheet-grid"><label class="wide">Item<input id="sheetInvName" value="${esc(x.name)}"></label><label class="wide">Quantity / amount<input id="sheetInvQty" value="${esc(x.qty||"")}"></label></div>`,`<button class="btn primary" data-sheet-save-inv>Save Changes</button>`)}
 if(uiSheet.type==="autopayEdit"){let x=uiSheet.row;if(!x)return "";return shell("Edit Autopay",`${x.date.toLocaleDateString("en-US",{month:"short",day:"numeric"})} • ${x.n}`,`<div class="sheet-grid"><label class="wide">Actual amount<input id="sheetAutopayAmount" type="number" min="0" step=".01" inputmode="decimal" value="${Number(x.a).toFixed(2)}"></label></div><div class="sheet-note">This edits this autopay occurrence only. The new amount flows into its paycheck week, month projection, emergency/rent math, checked-off summary, and live balance if you already marked it paid.</div>`,`<button class="btn primary" data-sheet-save-autopay>Save Amount</button>`)}
 if(uiSheet.type==="confirm"){let body=`<div class="sheet-note"><b>${esc(uiSheet.title||"Confirm")}</b><br>${esc(uiSheet.message||"")}</div>`;return shell(uiSheet.title||"Confirm","This action updates the same saved Hub data.",body,`<button class="btn primary" data-sheet-confirm>${esc(uiSheet.confirmText||"Confirm")}</button>`)}
 return ""
}

function mostRecentRoutineName(){
 let d=DAYS[state.day], tl=timeline(d);
 let recent=[...tl].reverse().find(x=>x.t.done);
 return recent?recent.t.name:"Nothing completed yet";
}
function routine(){
 let d=DAYS[state.day],rd=rday(d),tl=timeline(d),isToday=selectedKey()===localDateKey(),mins=isToday?new Date().getHours()*60+new Date().getMinutes():-1;
 let next=isToday?(tl.find(x=>!x.t.done&&x.en>=mins)||tl.find(x=>!x.t.done)):tl.find(x=>!x.t.done), now=isToday?(tl.find(x=>!x.t.done&&mins>=x.st&&mins<x.en)||next):next;
 let nowIndex=now?tl.indexOf(now):-1, nextItem=now?tl.slice(nowIndex+1).find(x=>!x.t.done):null;
 let recent=[...tl].reverse().find(x=>x.t.done);
 let sections=routineSectionOrder(d,[...new Set(tl.map(x=>x.t.section))]),open=sections.includes(rd.open)?rd.open:sections[0];
 let shown=tl.filter(x=>x.t.section===open);
 let tabs=sections.map(x=>`<button class="sectionTab ${x===open?"on":""}" data-rsection="${esc(x)}">${esc(x)}</button>`).join("");
 let cards=shown.map(x=>{
  const isCare=x.t.id==="careM"||x.t.id==="careN";
  if(isCare){
   const done=(x.t.subtasks||[]).filter(q=>q.done).length,total=(x.t.subtasks||[]).length;
   return `<details class="taskcard care-parent" data-care-parent="${x.t.id}"><summary class="care-parent-summary"><span class="care-check-wrap" onclick="event.stopPropagation()"><input class="taskcheck" type="checkbox" aria-label="${esc(x.t.name)} complete" data-rtask-check="${d}|${x.i}" ${x.t.done?"checked":""}></span><span class="care-summary-copy"><b>${esc(x.t.name)}</b><small>${fmt(x.st)}–${fmt(x.en)} • ${x.t.id==="careM"&&x.t.duration===0?"CHECKLIST":x.t.duration+" MIN"}</small></span><span class="care-summary-count">${done}/${total}</span><span class="care-chevron" aria-hidden="true"></span></summary><div class="care-dropdown-body"><div class="subtasks">${(x.t.subtasks||[]).map((q,j)=>`<div class="subrow"><input type="checkbox" aria-label="${esc(q.name)} complete" data-rsub-check="${d}|${x.i}|${j}" ${q.done?"checked":""}><span class="sub-name">${esc(q.name)}</span><button class="tinybtn icon-action" data-rsub-edit="${d}|${x.i}|${j}" aria-label="Edit ${esc(q.name)}">Edit</button><button class="tinybtn icon-action" data-rsub-del="${d}|${x.i}|${j}" aria-label="Remove ${esc(q.name)}">×</button></div>`).join("")}</div><div class="routine-maintenance"><button class="tinybtn" data-rsub-add="${d}|${x.i}">+ Care Item</button><span class="muted">${x.t.duration===0?"Checklist • no extra time block":"${x.t.duration}-minute daily anchor"}</span></div></div></details>`;
  }
  return `<div class="taskcard" id="routine-block-${x.i}"><div class="taskhead"><input class="taskcheck" type="checkbox" aria-label="${esc(x.t.name)} complete" data-rtask-check="${d}|${x.i}" ${x.t.done?"checked":""}><div class="task-title-copy"><b>${esc(x.t.name)}</b><div class="tasktime">${fmt(x.st)}–${fmt(x.en)} • ${x.t.duration+" min"}${x.anchor?" • FIXED TIME":""}${x.conflict?" • ⚠ CONFLICT":""}</div>${x.t.errandMeta?`<div class="muted" style="margin-top:3px">Entered ${fmt(x.t.errandMeta.enteredStart)}–${fmt(x.t.errandMeta.enteredEnd)} • shifts later flexible blocks ${x.t.duration} min</div>`:""}</div><button class="tinybtn" data-rtask-edit="${d}|${x.i}">Edit</button></div>${(x.t.subtasks||[]).length?`<div class="subtasks">${x.t.subtasks.map((q,j)=>`<div class="subrow"><input type="checkbox" aria-label="${esc(q.name)} complete" data-rsub-check="${d}|${x.i}|${j}" ${q.done?"checked":""}><span class="sub-name">${esc(q.name)}</span><button class="tinybtn" data-rsub-edit="${d}|${x.i}|${j}">Edit</button><button class="tinybtn" data-rsub-del="${d}|${x.i}|${j}" aria-label="Remove subtask">×</button></div>`).join("")}</div>`:""}<div class="routine-maintenance"><button class="tinybtn" data-rsub-add="${d}|${x.i}">+ Subtask</button><button class="tinybtn" data-rtask-del="${d}|${x.i}">Remove</button></div></div>`;
 }).join("");
 return hero("Routine",d)+back("Today")+`
 <section class="card soft"><div class="nowgrid"><div class="nowbox routine-jump" ${now?`data-rjump="${now.i}"`:""}><span class="muted">NOW</span><b>${esc(now?(now.t.subtasks?.find(q=>!q.done)?now.t.name+" • "+now.t.subtasks.find(q=>!q.done).name:now.t.name):"Routine complete")}</b>${now?`<span class="tasktime">${fmt(now.st)}–${fmt(now.en)}</span>`:""}</div><div class="nowbox routine-jump" ${nextItem?`data-rjump="${nextItem.i}"`:""}><span class="muted">NEXT</span><b>${esc(nextItem?.t.name||"Nothing next")}</b>${nextItem?`<span class="tasktime">${fmt(nextItem.st)}–${fmt(nextItem.en)}</span>`:""}</div></div><div class="comment-widget routine-commentary" style="margin-top:12px"><p>${esc(routineComment(d,tl))}</p></div><div class="app-actions"><button class="btn" data-woke-late="${d}">I WOKE UP LATE</button><button class="btn" data-add-errand="${d}">ADD AN ERRAND</button></div></section>
 <section class="card"><div class="row between"><h2 style="margin:0">Routine Sections</h2><button class="btn" data-copy-routine>Copy Routine</button></div><div class="wake-time-strip" aria-label="Wake time, informational only"><span>WAKE TIME</span><b>${fmt((d==="Wednesday"||d==="Thursday")?rd.start:(state.routineStarts[selectedKey()]??rd.start))}</b><small>DISPLAY ONLY</small></div><div class="sectionTabs">${tabs}</div>${cards||'<p class="muted">No blocks in this section.</p>'}</section>
 `;
}
function faith(){
 let k=selectedKey(),x=state.bible[k]||{},cats=["READING / PASSAGE","PRAYER","DEVOTIONAL","WHAT GOD IS TEACHING ME"],done=x.done||[],ps=x.psalms||{};
 let psalms=[23,91,51];
 return hero("Bible + Faith",DAYS[state.day])+back("Today")+`<section class="card"><div class="row" style="align-items:center"><span class="theme-heart"></span><h2 style="margin:0">${esc(k)}</h2></div><p class="muted">CHECK EACH ITEM AS YOU COMPLETE IT. EVERYTHING SAVES TO THIS EXACT DATE.</p><div class="psalm-grid">${psalms.map(n=>`<div class="psalm-card ${ps[n]?"done":""}"><label class="psalm-check"><input type="checkbox" data-faith-psalm="${n}" ${ps[n]?"checked":""}><span><b>PSALM ${n}</b><small>${ps[n]?"READ ✓":"TAP TO CHECK OFF AFTER READING"}</small></span></label><a class="btn psalm-read" href="https://www.biblegateway.com/passage/?search=Psalm%20${n}&version=KJV" target="_blank" rel="noopener noreferrer">OPEN PSALM ${n}</a></div>`).join("")}</div>${cats.map((c,i)=>`<div class="info-accordion"><div class="checkrow" style="padding:12px 14px"><label style="display:flex;align-items:center;gap:10px;flex:1"><input type="checkbox" data-faith-done="${i}" ${done[i]?"checked":""}><b>${c}</b></label></div><div><textarea data-faith-field="${i}" placeholder="${i===0?"BOOK + CHAPTER / VERSES":i===1?"PRAYER NOTES":i===2?"DEVOTIONAL NOTES":"REFLECTION / LESSON"}">${esc((x.entries||[])[i]||"")}</textarea></div></div>`).join("")}<div class="app-actions"><button class="btn primary" data-save-faith="${k}">SAVE FAITH ENTRY</button><button class="btn danger" data-clear-faith="${k}">REMOVE ENTRY</button></div></section><section class="card"><h2>FAITH CALENDAR</h2>${faithCalendar()}</section>`;
}
function faithCalendar(){
 let rows=Object.keys(state.bible).sort().reverse().slice(0,31);
 return rows.length?rows.map(k=>`<div class="checkrow"><span style="flex:1"><b>${esc(k)}</b></span><span>${(state.bible[k].entries||[]).filter(Boolean).length}/4 saved</span></div>`).join(""):'<p class="muted">Your saved Bible/Faith days will appear here.</p>'
}
function goals(){let k=selectedKey(),gd=state.goalHistory[k]||{},dayGoals=goalsForDate(k);return hero("Goals",DAYS[state.day])+back("Today")+`<section class="card"><h2>Daily Goals</h2><p class="muted">Goals save to this exact date. Every unfinished goal automatically appears in Today Commentary until you complete it. Important is optional and only marks a goal for extra emphasis.</p><div id="goalList">${dayGoals.map((g,i)=>`<div class="checkrow"><label style="display:flex;align-items:center;gap:10px;flex:1"><input type="checkbox" data-goal-done="${i}" ${gd[i]?.done?'checked':''}><span><b>${esc(g.text)}</b>${g.important?' <small>• reminder</small>':''}</span></label><button class="btn" data-goal-edit="${i}">Edit</button><button class="btn" data-goal-remove="${i}" aria-label="Remove goal">Remove</button></div>`).join("")||'<p class="muted">No goals yet.</p>'}</div><div class="formgrid"><input id="goalText" aria-label="New goal" placeholder="Add a goal"><label class="checkrow"><input id="goalImportant" type="checkbox"><span>Important / extra emphasis</span></label></div><button class="btn primary" data-add-goal>Add Goal</button></section><section class="card"><h2>Water</h2>${waterTracker(k)}</section>`}
function school(){let d=DAYS[state.day],k=selectedKey(),suggested=STUDY[d].toUpperCase().includes("PERT")?"PERT practice / lesson resource":"ATI TEAS study resource";return hero("School / Study Today",d)+back("Today")+`<section class="card"><h2>${esc(STUDY[d])}</h2><p class="muted">30-minute study block • Suggested resource family: <b>${esc(suggested)}</b></p><label>Resource<input id="studyResource" aria-label="Study resource" placeholder="${esc(suggested)}" value="${esc(state.studyResources[k]||"")}"></label><label>What I Studied Today<textarea id="studyNote" aria-label="What I studied today" placeholder="What I studied today">${esc(state.studyNotes[k]||"")}</textarea></label><div class="app-actions"><button class="btn primary" data-save-study>Save Study</button><button class="btn danger" data-clear-study>Remove Saved Study</button></div></section>`}
function weigh(){let k=selectedKey();return hero("Daily Weigh-In",DAYS[state.day])+back("Today")+`<section class="card"><label>Weight (lb)<input id="weightInput" type="number" min="0" step=".1" value="${esc(state.weight[k]??"")}"></label><div class="app-actions"><button class="btn primary" data-save-weight>Save Weight</button><button class="btn danger" data-clear-weight>Remove Weigh-In</button></div></section>`}
function measure(){if(state.day!==0)return hero("Monday Measurements",DAYS[state.day])+back("Today")+note("Monday Measurements are available on Monday only. Choose MON in the day bar to enter them.");let k=selectedKey(),m=state.measure[k]||{};return hero("Monday Measurements","Feeds Body Progress")+back("Today")+`<section class="card formgrid">${["weight","glutes","waist","arms"].map(x=>`<label>${x[0].toUpperCase()+x.slice(1)}<input data-measure="${x}" type="number" min="0" step=".1" value="${esc(m[x]??"")}"></label>`).join("")}</section><div class="app-actions"><button class="btn primary" data-save-measure>Save Measurements</button><button class="btn danger" data-clear-measure>Remove Measurements</button></div>`}
function reset(){if(state.day!==6)return hero("Sunday Reset",DAYS[state.day])+back("Today")+note("Sunday Reset is available on Sunday only. Choose SUN in the day bar to complete it.");return hero("Sunday Reset","Sunday only")+back("Today")+`<section class="card">${["Home reset","Floor care","Fridge / food inventory","Plan upcoming week","Check school priorities"].map((x,i)=>checkbox("reset|"+selectedKey()+"|"+i,x)).join("")}</section>`}
function todayMeal(){return (MEAL.days||{})[selectedKey()]||null}
function macroTargetNum(k){let t=MEAL.targets||{};if(k==="calories")return 2000;if(k==="protein")return 135;if(k==="carbs")return 235;if(k==="fat")return 62.5;if(k==="fiber")return 28;return 0}
function macroPanel(){
 let k=selectedKey(),a=state.actualFood[k]||{},labels={calories:"Calories",protein:"Protein (g)",carbs:"Carbs (g)",fat:"Fat (g)",fiber:"Fiber (g)"};
 return `<section class="card"><h2>Daily Macros — Planned vs Actual</h2><p class="muted">Targets: ${esc(MEAL.targets.calories)} kcal • ${esc(MEAL.targets.protein)} protein • ${esc(MEAL.targets.carbs)} carbs • ${esc(MEAL.targets.fat)} fat • ${esc(MEAL.targets.fiber)} fiber. Actuals stay blank until you enter what you really ate.</p><div class="macrogrid">${Object.keys(labels).map(x=>{let v=Math.max(0,Number(a[x])||0),tg=macroTargetNum(x),pct=tg?Math.max(0,Math.min(100,v/tg*100)):0;return `<div class="macrobox"><b>${labels[x]}</b><input type="number" min="0" step=".1" data-macro="${x}" aria-label="${labels[x]} actual" value="${Number.isFinite(Number(a[x]))&&Number(a[x])>=0?esc(a[x]):""}" placeholder="Actual"><div class="macrobar"><div class="macrofill" style="width:${pct}%"></div></div><small>${v?`${v} / ${tg}`:`Target ${tg}`}</small></div>`}).join("")}</div><button class="btn primary" data-save-macros>Save Actual Macros</button></section>`
}
function foodHome(){
 const d=todayMeal();
 return hero("Food",DAYS[state.day])+`<section class="card soft"><h2>COOKING RULES</h2><p><b>NO OVEN RECIPES.</b> MONDAY • WEDNESDAY • THURSDAY ONLY • EXACTLY 2 RECIPES PER FUTURE COOK DAY • BOTH RECIPES MUST BE COMPLETELY FINISHED WITHIN 1 HOUR 30 MINUTES TOTAL, INCLUDING PREP, COOKING, MEASUREMENTS, PORTIONING, LABELS, STORAGE + BASIC CLEANUP.</p><p class="muted">PREFER FAST STOVETOP / ONE-POT / ONE-SKILLET / QUICK AIR-FRYER MEALS. 90 MINUTES IS THE CEILING, NOT THE TARGET.</p></section><div class="grid"><button class="tile" data-sub="todayfood"><b>Today’s Food</b><span>Meals at a Glance • gym fuel • actual macros</span></button><button class="tile" data-sub="mealplan"><b>Meal Plan</b><span>${esc(MEAL.label||"Current week")}</span></button><button class="tile" data-sub="inventory"><b>Inventory</b><span>Fridge • freezer • pantry • seasonings • containers</span></button>${state.day===0?'<button class="tile" data-sub="grocery"><b>Grocery</b><span>Monday shopping list</span></button>':""}${d?.cook?.length?'<button class="tile" data-sub="cook"><b>Cook</b><span>Guided cooking for today</span></button>':""}</div>${d?`<section class="card soft"><b>${esc(d.day)}</b><p class="muted">${d.cook?.length?`Cooking session recorded for this day.`:"No cooking scheduled."} ${esc(d.thaw||"")}</p></section>`:""}`;
}
function food(){
 if(state.sub==="todayfood")return todayFoodScreen();
 if(state.sub==="mealplan")return mealPlanScreen();
 if(state.sub==="inventory")return inventory();
 if(state.sub==="grocery")return grocery();
 if(state.sub==="cook")return cook();
 return foodHome();
}

function ensureFoodHistoryIdsV52(){const mark="migration|foodHistoryStableIdsV52|2026-09-29";state.checks=state.checks||{};if(state.checks[mark])return;state.foodHistory=Array.isArray(state.foodHistory)?state.foodHistory:[];state.foodHistory.forEach(x=>{if(x&&typeof x==="object"&&!x.id)x.id=uid("food")});state.checks[mark]=true;save()}ensureFoodHistoryIdsV52();
function addMacrosToActual(date,macros,sign=1){
 if(!macros||typeof macros!=="object")return;
 let keys=["calories","protein","carbs","fat","fiber"],a=state.actualFood[date]||{},changed=false;
 keys.forEach(k=>{let v=Number(macros[k]);if(Number.isFinite(v)){a[k]=Math.max(0,(Number(a[k])||0)+sign*v);a[k]=Math.round(a[k]*10)/10;changed=true}});
 if(changed)state.actualFood[date]=a;
}
function recordEatenContainer(x,date=selectedKey()){
 if(!x)return;
 let rec={id:uid("food"),date,type:"ATE",name:x.name||x.recipe||"Saved container",recipe:x.recipe||x.name,container:x.name||x.recipe,amount:x.qty||"",macros:x.macros?{...x.macros}:null,nutritionComplete:x.nutritionComplete!==false,macroSource:x.macroSource||"Saved container macros"};
 state.foodHistory.push(rec);
 addMacrosToActual(date,rec.macros,1);
 return rec;
}
function todayFoodScreen(){let d=todayMeal(),k=selectedKey(),logs=(state.foodHistory||[]).filter(x=>(x.date||"").slice(0,10)===k&&(x.type==="ATE"||x.type==="ATE CONTAINER"));return hero("Today’s Food",DAYS[state.day])+back("Food")+`<section class="card meal-glance"><div class="cute-title"><span>♡</span><h2>MEALS AT A GLANCE</h2><span></span></div><div class="meal-tiles">${d?["breakfast","pre","post","lunch","dinner","snacks"].map(x=>d[x]?`<div class="meal-tile"><b>${x==="pre"?"Pre-Workout":x==="post"?"Post-Workout":x[0].toUpperCase()+x.slice(1)}</b><p>${esc(d[x])}</p></div>`:"").join(""):"<p>No plan for this day.</p>"}</div></section><section class="card"><h2>What I Actually Ate</h2><p class="muted">LOG FROM A SAVED CONTAINER OR ENTER ANY FOOD. BARCODE IS OPTIONAL — IT IS NOT THE MAIN WORKFLOW.</p>${logs.map(x=>`<div class="checkrow"><span style="flex:1"><b>${esc(x.name||x.container||"Food")}</b>${x.amount?`<small> • ${esc(x.amount)}</small>`:""}</span><button class="tinybtn" data-foodlog-del="${esc(x.id)}">×</button></div>`).join("")||'<p class="muted">Nothing logged yet today.</p>'}<div class="formgrid"><label class="wide">Food / brand / fruit / veggie<input id="ateName" placeholder="e.g. 100 g raspberries or Fairlife milk"></label><label>Amount<input id="ateAmount" placeholder="100 g / 1 serving"></label><label>Barcode (optional)<input id="ateBarcode" inputmode="numeric" placeholder="Scan or type UPC"></label></div><div class="app-actions"><button class="btn" data-log-container>Choose Saved Container</button><button class="btn primary" data-log-food>Add What I Ate</button></div><div id="containerChoices" class="container-choices">${(state.inventory.Containers||[]).map((c,i)=>`<button class="tinybtn" data-eat-container="${i}">${esc(c.name||c.recipe||"Container "+(i+1))}</button>`).join("")}</div></section>`+macroPanel()}
function mealPlanScreen(){let days=Object.entries(MEAL.days||{});let chosen=selectedKey(),x=MEAL.days?.[chosen];return hero("Meal Plan",MEAL.label||"Current week")+`<section class="card soft"><h2>COOKING LIMIT</h2><p><b>NO OVEN • EXACTLY 2 RECIPES PER MON/WED/THU COOK • ≤ 1:30 TOTAL ALL-IN.</b></p></section>`+back("Food")+`<section class="card"><h2>Choose a Day</h2><div class="meal-day-tabs">${days.map(([k,v])=>`<button class="sectionTab ${k===chosen?"on":""}" data-meal-day="${esc(k)}">${esc(v.day)}</button>`).join("")}</div></section>${x?`<section class="card"><h2>${esc(x.day)} • ${esc(chosen)}</h2><p><b>Breakfast:</b> ${esc(x.breakfast)}</p>${x.pre?`<p><b>Pre-Workout:</b> ${esc(x.pre)}</p>`:""}${x.post?`<p><b>Post-Workout:</b> ${esc(x.post)}</p>`:""}<p><b>Lunch:</b> ${esc(x.lunch)}</p><p><b>Dinner:</b> ${esc(x.dinner)}</p><p><b>Snacks / Treats:</b> ${esc(x.snacks||"—")}</p>${DAY_MACRO_PLAN[chosen]?(()=>{let m=DAY_MACRO_PLAN[chosen];return `<div class="macro-mini"><b>PLANNED DAY MACROS • ${m.status?"PENDING ACTUALS":"EST."}</b><br>${m.status?esc(m.status+" — "+(m.note||"")):`${m.calories} kcal • ${m.protein} g protein • ${m.carbs} g carbs • ${m.fat} g fat • ${m.fiber} g fiber`}</div>`})():""}<p><b>Cooking:</b> ${x.cook?.length?x.cook.map(esc).join(" • "):"No cooking today"}</p></section>`:""}`;}
function inventory(){
 const cats=["Fridge","Freezer","Pantry","Seasonings","Containers"],cat=cats.includes(state.inventoryTab)?state.inventoryTab:"Fridge",q=String(state.inventorySearch||"").trim().toLowerCase(),arr=state.inventory[cat]||[],visible=arr.map((x,i)=>({x,i})).filter(({x})=>!q||`${x.name} ${x.qty||""}`.toLowerCase().includes(q));
 const urgent=cats.flatMap(c=>(state.inventory[c]||[]).map((x,i)=>({c,x,i}))).filter(z=>z.x.useSoon),purchased=purchasedGroceries(),pending=purchased.filter(x=>!state.mondayHaul[x.key]?.added);
 let haul=purchased.length?`<section class="card monday-haul"><h2>Monday Purchases to Add</h2><p class="muted">ONLY GROCERIES YOU CHECKED AS PURCHASED APPEAR HERE. THE HUB CARRIES THE ORIGINAL GROCERY SPECIFICATION, STORE, PLANNED BUY, PRICE, AND UPC FORWARD. CONFIRM THE ACTUAL PRODUCT, PACKAGE / WEIGHT, AND STORAGE LOCATION BEFORE SAVING.</p>${purchased.map(x=>{let h=state.mondayHaul[x.key]||{},loc=h.location||purchaseDefaultLocation(x.item);return `<details class="haul-item" ${h.added?"":"open"}><summary>${h.added?"✓ ":""}${esc(x.item)}</summary><div class="suggested-portions"><b>FROM GROCERY LIST</b><br>${esc(x.item)}<br><small>${esc(groceryBuyUnit(x.item))} • ${esc(x.store)}</small></div><div class="formgrid"><label class="wide">ACTUAL PRODUCT / BRAND<input data-haul-name="${esc(x.key)}" value="${esc(h.name||x.item.replace(/\s+[—-].*$/,""))}" placeholder="What you actually bought"></label><label>ACTUAL QTY / SIZE<input data-haul-qty="${esc(x.key)}" value="${esc(h.qty||"")}" placeholder="e.g. 2 lb / 32 oz"></label><label>LOCATION<select data-haul-location="${esc(x.key)}">${["Fridge","Freezer","Pantry","Seasonings"].map(z=>`<option ${loc===z?"selected":""}>${z}</option>`).join("")}</select></label><label>UPC / BARCODE<input data-haul-upc="${esc(x.key)}" inputmode="numeric" value="${esc(h.upc||"")}" placeholder="optional"></label></div><div class="app-actions"><label class="btn scan-mini">SCAN<input class="barcode-file" type="file" accept="image/*" capture="environment" data-haul-scan="${esc(x.key)}"></label><button class="btn primary" data-add-haul="${esc(x.key)}">${h.added?"SAVED TO INVENTORY ✓":"ADD TO INVENTORY"}</button></div></details>`}).join("")}<p class="muted">${pending.length?`${pending.length} purchased item${pending.length===1?"":"s"} still need to be added.`:"All checked purchases are entered."}</p></section>`:"";
 return hero("Inventory","Fridge • freezer • pantry • seasonings • containers")+back("Food")+haul+(purchased.length?mondayPortioningPanel():"")+`<section class="card"><div class="sectionTabs">${cats.map(c=>`<button class="sectionTab ${c===cat?'on':''}" data-inv-tab="${c}">${c}</button>`).join("")}</div><div class="row"><input id="inventorySearch" aria-label="Search inventory" placeholder="Search inventory" value="${esc(state.inventorySearch||"")}"><button class="btn" data-inv-search>Search</button><button class="btn" data-inv-clear>Clear</button></div>${urgent.length?`<details class="card soft"><summary><b>USE ASAP / USE SOON • ${urgent.length}</b></summary>${urgent.map(z=>`<div class="checkrow"><span style="flex:1">${esc(z.c)} • ${esc(z.x.name)}${z.x.qty?' • '+esc(z.x.qty):''}</span></div>`).join("")}</details>`:""}</section><section class="card"><h2>${cat}</h2>${visible.map(({x,i})=>`<div class="inventory-row"><div class="inventory-main"><b>${esc(x.name)}</b><div class="inventory-meta">${x.qty?esc(x.qty):"Quantity not entered"}${x.useSoon?" • USE ASAP":""}${x.expires?`<br><small><b>${x.expiryType||"DATE"}:</b> ${esc(x.expires)}</small>`:""}${x.grocerySpec?`<br><small><b>GROCERY SPEC:</b> ${esc(x.grocerySpec)}</small>`:""}${x.store?`<br><small><b>BOUGHT AT:</b> ${esc(x.store)}${Number.isFinite(Number(x.purchasePrice))&&Number(x.purchasePrice)>0?` • ${money(Number(x.purchasePrice))}`:""}</small>`:""}${x.upc?`<br><small><b>UPC:</b> ${esc(x.upc)}</small>`:""}${x.notes?`<br><small>${esc(x.notes)}</small>`:""}${cat==="Containers"&&x.labelRows?.length?`<div class="label-preview">${x.labelRows.map(esc).join("<br>")}</div>`:""}${cat==="Containers"&&String(x.id||"").startsWith("actual-")?`<div class="muted"><b>ACTUAL PREPARED CONTAINER • 1 REMAINING</b></div>`:""}${cat==="Containers"&&x.macros?`<div class="macro-preview"><b>SAVED MACROS</b><br>${macroLine(x.macros)}${x.nutritionComplete===false?`<br><small class="muted">Contains an ingredient needing confirmed nutrition.</small>`:""}</div>`:""}</div></div><div class="inventory-actions">${cat==="Containers"?`${x.storage==="FREEZER"?`<button class="btn" data-container-move="${i}">Fridge</button>`:""}<button class="btn" data-container-eat="${i}">Eaten</button><button class="btn" data-container-discard="${i}">Discard</button>`:""}<button class="btn ${x.useSoon?"primary":""}" data-inv-soon="${cat}|${i}">${x.useSoon?"ASAP ✓":"ASAP"}</button><button class="btn" data-edit-inv="${cat}|${i}">Edit</button><button class="btn" data-del-inv="${cat}|${i}">×</button></div></div>`).join("")||'<p class="muted">No matching saved items.</p>'}<div class="formgrid"><input data-inv-name="${cat}" aria-label="${esc(cat)} item name" placeholder="Item"><input data-inv-qty="${cat}" aria-label="${esc(cat)} quantity or amount" placeholder="Qty / amount"></div><button class="btn" data-add-inv="${cat}">Add</button></section>`
}
function groceryPriceKey(store,item){return store+"|"+String(item||"")}
function groceryCategory(x){x=String(x).toLowerCase();if(/chicken|beef|meat/.test(x))return "Meat / Protein";if(/potato|carrot|celery|onion|banana|fruit/.test(x))return "Produce";if(/milk/.test(x))return "Dairy";return "Pantry / Grocery"}
function groceryBuyUnit(x){let q=String(x);if(/454 g \/ 1 lb boneless chicken thighs/i.test(q))return "BUY: 1 × 1-LB PACK";if(/~1 kg potatoes/i.test(q))return "BUY: 1 × 3-LB BAG";if(/~360 g carrots/i.test(q))return "BUY: 1 × 1-LB BAG";if(/~240 g celery/i.test(q))return "BUY: 1 BUNCH";if(/2–3 onions/i.test(q))return "BUY: 3 LOOSE ONIONS";if(/bananas/i.test(q))return "BUY: ~3 MEDIUM BANANAS (≥300 G EDIBLE)";if(/fruit only/i.test(q))return "BUY ONLY IF NEEDED: 1 SMALL PACK";if(/honey/i.test(q))return "BUY: 1 BOTTLE";if(/rice/i.test(q))return "BUY ONLY IF WANTED: 1 SMALL BAG";if(/milk/i.test(q))return "BUY ONLY AFTER FAIRLIFE: 1 CARTON";return "BUY: 1 STORE UNIT"}
function groceryEstimate(store,x){let q=String(x).toLowerCase();if(/chicken thighs/.test(q))return 5.49;if(/potatoes/.test(q))return 3.99;if(/carrots/.test(q))return 1.79;if(/celery/.test(q))return 2.49;if(/onions/.test(q))return 2.25;if(/bananas/.test(q))return 0.90;if(/fruit only/.test(q))return 4.00;if(/honey/.test(q))return 5.98;if(/rice/.test(q))return 2.48;if(/milk/.test(q))return 3.98;return 0}
function grocery(){let g=MEAL.grocery||{},isMonday=DAYS[state.day]==="Monday";state.groceryCustom=state.groceryCustom||{};let stores=["Walmart","Detwiler’s"].filter(x=>Array.isArray(g[x]));if(!isMonday)return hero("Grocery List",DAYS[state.day])+back("Food")+`<section class="card"><h2>No grocery trip planned for ${esc(DAYS[state.day])}</h2><p class="muted">This list stays specific to the day. Choose Monday for the planned grocery trip.</p></section>`;let totals={};stores.forEach(store=>{let arr=(g[store]||[]).filter(x=>!/^NO BUY/i.test(String(x))),custom=state.groceryCustom[store]||[];totals[store]=arr.reduce((a,x,i)=>a+Math.max(0,Number(state.groceryPrices[groceryPriceKey(store,x)]??state.groceryPrices[store+"|"+i]??groceryEstimate(store,x))||0),0)+custom.reduce((a,x)=>a+Math.max(0,Number(x.price)||0),0)});let grand=stores.reduce((a,x)=>a+totals[x],0);return hero("Grocery List","Monday")+back("Food")+`<section class="card grocery-total-card"><div><span class="muted">ESTIMATED TOTAL</span><div class="metric money">${money(grand)}</div></div><div class="store-mini-totals">${stores.map(x=>`<span><b>${esc(x)}</b> ${money(totals[x])}</span>`).join("")}</div><p class="muted">CHECK = PURCHASED. ALREADY HAVE = DO NOT BUY. NOTHING IS ADDED TO INVENTORY WHILE YOU SHOP.</p></section>${stores.map(store=>{let arr=(g[store]||[]).filter(x=>!/^NO BUY/i.test(String(x))),custom=state.groceryCustom[store]||[];return `<section class="card"><div class="row between"><h2>${esc(store)}</h2><b>${money(totals[store])}</b></div>${arr.map((x,i)=>{let key=`grocery|${store}|${i}`,have=`groceryHave|${store}|${i}`,saved=state.groceryPrices[groceryPriceKey(store,x)]??state.groceryPrices[store+"|"+i],val=saved??groceryEstimate(store,x);return `<div class="grocery-row clean-grocery"><div style="flex:1">${checkbox(key,x)}<div class="grocery-mini-actions"><label class="already-have"><input type="checkbox" data-grocery-have="${esc(store)}|${i}" ${state.checks[have]?"checked":""}> ALREADY HAVE</label></div></div><label class="price-est">EST. PRICE<input type="number" min="0" step=".01" data-grocery-price="${esc(store)}|${i}" value="${esc(val)}"></label></div>`}).join("")}${custom.map((x,i)=>`<div class="grocery-row"><b>${esc(x.item)}</b><span>${money(x.price)}</span></div>`).join("")}</section>`}).join("")}<section class="card soft after-home"><h2>After You Get Home</h2><p class="muted">Go to Inventory to add the exact products you actually brought home. It will show only the items checked as purchased. Then confirm Monday meat portioning.</p><button class="btn primary" data-grocery-to-inventory>ADD PURCHASES + MONDAY PORTIONING</button></section>`;}

function normFood(v){return String(v||"").toLowerCase().replace(/[’']/g,"").replace(/[^a-z0-9]+/g," ").replace(/\s+/g," ").trim()}
function foodTokens(v){return normFood(v).split(" ").filter(x=>x.length>2&&!new Set(["opened","remaining","existing","frozen","fresh","raw","dry","total","approx","about","large","small","medium","use","first","before","new"]).has(x))}
function invMatches(line,item){let a=normFood(line),b=normFood(item?.name);if(!a||!b)return false;let forms=["ground chicken","chicken thigh","chicken breast","whole chicken","ground beef","beef steak","ham"];let af=forms.find(x=>a.includes(x)),bf=forms.find(x=>b.includes(x));if(af||bf){if(af!==bf)return false}if(/\bchicken\b/.test(a)&&!af&&!/broth|stock/.test(a)&&(/ground|thigh|breast/.test(b)))return false;let aliases=[["chicken thighs","chicken thigh"],["ground chicken","ground chicken"],["ground beef","ground beef"],["fairlife milk","fairlife milk"],["chicken stock","chicken stock"],["beef broth","beef broth"],["tomato paste","tomato paste"],["liquid aminos","liquid aminos"],["worcestershire","worcestershire"],["sun dried tomatoes","sun dried tomatoes"],["green lentils","lentils"],["mild cheddar","cheddar"],["parmesan","parmesan"],["pasta noodles","pasta"],["pasta","noodles"],["corn","corn"],["broccoli","broccoli"],["potatoes","potato"],["carrots","carrot"],["onion","onion"],["celery","celery"],["garlic","garlic"],["ginger","ginger"],["heavy cream","heavy cream"],["butter","butter"],["flour","flour"],["panko","panko"],["ham","ham"]];for(let [x,y] of aliases)if(a.includes(x)&&(b.includes(x)||b.includes(y)))return true;let toks=foodTokens(a);return toks.some(t=>b.includes(t))}
function parseQty(v){let m=String(v||"").replace(/,/g,"").match(/~?\s*(\d+(?:\.\d+)?)\s*(kg|g|lb|lbs|oz|ml|mL|l|tbsp|tsp|cups?|eggs?|slices?|scoops?|pieces?)\b/i);return m?{n:Number(m[1]),u:m[2].toLowerCase()}:null}
function unitKind(u){u=String(u||"").toLowerCase();if(["kg","g","lb","lbs","oz"].includes(u))return "mass";if(["ml","l","tbsp","tsp","cup","cups"].includes(u))return "volume";return "count"}
function toBaseAmount(n,u){u=String(u||"").toLowerCase();let f={kg:1000,g:1,lb:453.592,lbs:453.592,oz:28.3495,ml:1,l:1000,tbsp:14.7868,tsp:4.92892,cup:236.588,cups:236.588}[u]??1;return Number(n)*f}
function fromBaseAmount(n,u){u=String(u||"").toLowerCase();let f={kg:1000,g:1,lb:453.592,lbs:453.592,oz:28.3495,ml:1,l:1000,tbsp:14.7868,tsp:4.92892,cup:236.588,cups:236.588}[u]??1;return Number(n)/f}

function inventoryCandidates(line){
 let a=normFood(line),out=[];for(let cat of ["Fridge","Freezer","Pantry","Seasonings"])(state.inventory[cat]||[]).forEach((item,i)=>{if(invMatches(line,item)){let b=normFood(item.name),score=0;if(/opened|partial/.test(b))score+=30;if(item.useSoon)score+=20;if(a.includes("mild cheddar")&&b.includes("mild cheddar"))score+=40;if(a.includes("flour")&&b.includes("ap flour"))score+=40;if(/\bcorn\b/.test(a)&&b.includes("super sweet corn"))score+=40;if(a.includes("tomato paste")&&b.includes("opened"))score+=40;if(a.includes("liquid aminos")&&b.includes("partial"))score+=40;if(a.includes("worcestershire")&&b.includes("partial"))score+=40;out.push({cat,i,item,score})}});return out.sort((x,y)=>y.score-x.score)
}
function appendUsage(item,text){let d=selectedKey(),msg=`${d}: ${text}`;item.notes=item.notes?`${item.notes} • ${msg}`:msg}
function consumeIngredient(line,overrideAmount=null){
 let parsed=parseIngredientAmount(line),amt=overrideAmount&&Number(overrideAmount)>0?{n:Number(overrideAmount),u:"g"}:parsed?{n:parsed.amount,u:parsed.unit}:null,cands=inventoryCandidates(line);
 if(!amt)return {ingredient:line,deducted:false,updated:false,reason:/____/.test(line)?"actual ingredient weight is still blank":"recipe amount could not be parsed"};
 if(!cands.length)return {ingredient:line,deducted:false,updated:false,reason:"no matching inventory item"};
 let need=toBaseAmount(amt.n,amt.u),kind=unitKind(amt.u),used=[],unknown=[];
 for(let c of cands){if(!(need>1e-8))break;let q=parseQty(c.item.qty),qkind=q?unitKind(q.u):"";if(!q||!q.u||qkind!==kind){unknown.push(c);continue}let have=toBaseAmount(q.n,q.u);if(!Number.isFinite(have))continue;let take=Math.min(need,have),left=have-take,newN=fromBaseAmount(left,q.u);c.item.qty=left<=1e-8?"0":`${+newN.toFixed(2)} ${q.u}`;appendUsage(c.item,`used ${+(fromBaseAmount(take,amt.u)).toFixed(2)} ${amt.u} for ${line}`);used.push({item:c.item.name,category:c.cat,usedBase:take});need-=take}
 if(need>1e-8&&unknown.length){let c=unknown[0],usedAmt=fromBaseAmount(need,amt.u);appendUsage(c.item,`NEEDS QUANTITY CONFIRMATION: ${+usedAmt.toFixed(2)} ${amt.u} used for ${line}; Inventory quantity was not exact enough to deduct`);return {ingredient:line,item:used.map(x=>x.item).join(" + "),category:[...new Set(used.map(x=>x.category))].join(" + "),deducted:false,updated:used.length>0,reason:`Inventory quantity for ${c.item.name} is not exact enough to deduct ${+usedAmt.toFixed(2)} ${amt.u}`}}
 return {ingredient:line,item:used.map(x=>x.item).join(" + "),category:[...new Set(used.map(x=>x.category))].join(" + "),deducted:need<=1e-8,updated:used.length>0,reason:need>1e-8?`insufficient tracked quantity; ${+fromBaseAmount(need,amt.u).toFixed(2)} ${amt.u} still unresolved`:""}
}
function cookRecipeName(n){return Object.keys(MEAL.recipes||{}).find(x=>String(n||"").startsWith(x))||String(n||"").split(" — ")[0]}
function ingredientNameOnly(line){return String(line||"").replace(/^\s*(?:remaining\s+)?(?:~?\d+(?:\.\d+)?\s*(?:g|mL|ml|oz|tbsp|tsp|cups?|large)?\s*)+/i,"").replace(/\s*[—•].*$/g,"").replace(/^opened\s+/i,"").replace(/^existing\s+/i,"").replace(/^dry\s+/i,"").replace(/^frozen\s+/i,"").replace(/^raw\s+/i,"").replace(/\s+total$/i,"").trim()||String(line||"")}
function cookSourceGroup(line){let a=normFood(line);if(/seasoning|thyme|oregano|paprika|turmeric|curry powder|salt|pepper/.test(a))return "Seasonings";if(/ground beef|ground chicken|chicken thigh|existing chicken|ham|egg|parmesan|cheddar|butter|cream|milk|broccoli|carrot|onion|celery|garlic|ginger|potato|corn|sun dried/.test(a))return /broccoli|corn/.test(a)?"Freezer":"Fridge";return "Pantry"}
function cookAssignments(name){const A={
"Beef & Broccoli Garlic Noodles":[{date:"2026-09-29",meal:"LUNCH",storage:"FRIDGE"},{date:"2026-10-02",meal:"LUNCH",storage:"FREEZER"}],
"Marry Me Chicken Meatballs":[{date:"2026-09-29",meal:"DINNER",storage:"FRIDGE"},{date:"2026-10-03",meal:"LUNCH",storage:"FREEZER"}],
"Ham & Lentil Soup":[{date:"2026-10-02",meal:"DINNER",storage:"FRIDGE"}],
"Cheesy Cottage Pie":[{date:"2026-10-01",meal:"LUNCH",storage:"FRIDGE"},{date:"2026-10-03",meal:"DINNER",storage:"FREEZER"}],
"Chicken + Veg/Broth Base":[{date:"2026-10-01",meal:"DINNER",storage:"FRIDGE"},{date:"2026-10-04",meal:"DINNER",storage:"FREEZER"}]};return A[name]||[]}
function shortDayDate(iso){let d=new Date(iso+"T12:00:00");return `${DAYS[(d.getDay()+6)%7].slice(0,3).toUpperCase()} ${d.getMonth()+1}/${d.getDate()}`}
function thawCode(iso){let d=new Date(iso+"T12:00:00");d.setDate(d.getDate()-1);return DAYS[(d.getDay()+6)%7].slice(0,3).toUpperCase()}
function physicalLabel(target){if(!target?.date||!target?.meal||!target?.storage)return [];let line2=String(target.meal).toUpperCase()+"/"+String(target.storage).toUpperCase();let rows=[v7DateLabel(target.date),line2];if(String(target.storage).toUpperCase()==="FREEZER")rows.push(v7DateLabel(target.date));return rows}
// RAW MEAT LABEL LOCK: meat / USE DAY+DATE / actual grams / location / THAW DAY only if freezer. No recipe, meal, or number.

function emptyMacros(){return {calories:0,protein:0,carbs:0,fat:0,fiber:0}}
function addMacros(a,b,scale=1){let o={...a};for(let k of ["calories","protein","carbs","fat","fiber"])o[k]=(Number(o[k])||0)+(Number(b?.[k])||0)*scale;return o}
function roundMacros(m){let o={};for(let k of ["calories","protein","carbs","fat","fiber"])o[k]=Math.round((Number(m?.[k])||0)*10)/10;return o}
function parseIngredientAmount(text){let m=String(text||"").match(/^\s*([\d.]+)\s*(g|ml|mL|oz|lb|tbsp|tsp|cup|cups|egg|eggs|slice|slices|scoop|scoops|piece|pieces)\b/i);return m?{amount:Number(m[1]),unit:m[2].toLowerCase()}:null}
function changedIngredientAmountV102(plannedText,changeText){
 let p=parseIngredientAmount(plannedText),raw=String(changeText||"").trim();if(!p||!raw)return null;
 let m=raw.match(/^([+-])\s*(\d+(?:\.\d+)?)\s*(g|ml|mL|oz|lb|tbsp|tsp|cup|cups|egg|eggs|slice|slices|scoop|scoops|piece|pieces)\b/i);
 if(m){let u=m[3].toLowerCase();if(u!==String(p.unit).toLowerCase())return null;return {amount:Math.max(0,p.amount+(m[1]==="+"?1:-1)*Number(m[2])),unit:p.unit}}
 let a=parseIngredientAmount(raw.replace(/.*?(\d)/,"$1"));if(a&&String(a.unit).toLowerCase()===String(p.unit).toLowerCase())return {amount:Math.max(0,a.amount),unit:p.unit};
 return null
}
function actualIngredientLineV102(plannedText,changeText){
 let a=changedIngredientAmountV102(plannedText,changeText);if(!a)return plannedText;
 return String(plannedText).replace(/^\s*[\d.]+\s*(g|ml|mL|oz|lb|tbsp|tsp|cup|cups|egg|eggs|slice|slices|scoop|scoops|piece|pieces)\b/i,`${a.amount} ${a.unit}`);
}
function changedIngredientScaleV100(plannedText,changeText){
 let p=parseIngredientAmount(plannedText),a=changedIngredientAmountV102(plannedText,changeText);if(!p||!a||!(p.amount>0))return null;return a.amount/p.amount
}
function linkedInventoryIngredientMacrosV103(recipeName,idx,change){
 let r=MEAL.recipes?.[recipeName],txt=String(r?.ingredients?.[idx]||""),hit=inventoryNutritionMatch(txt),n=hit?.nutrition;
 if(!n||!["calories","protein","carbs","fat","fiber"].some(k=>n[k]!==undefined&&n[k]!==""))return null;
 let p=parseIngredientAmount(txt),a=p,sg=Number(n.servingGrams)||100;
 if(!a||!(a.amount>0)||!(sg>0))return null;
 let grams=a.amount,u=String(a.unit||"").toLowerCase();
 if(u==="oz")grams*=28.3495;else if(u==="lb")grams*=453.592;else if(u==="tbsp")grams*=15;else if(u==="tsp")grams*=5;else if(u==="cup"||u==="cups")grams*=240;else if(u==="egg"||u==="eggs"||u==="slice"||u==="slices"||u==="scoop"||u==="scoops"||u==="piece"||u==="pieces")return null;
 let m=emptyMacros();for(let k of ["calories","protein","carbs","fat","fiber"])m[k]=(Number(n[k])||0)*(grams/sg);return m
}
function ingredientMacroBase(recipeName,idx){
 let key=recipeName+"|"+idx,custom=state.nutritionFacts?.[key];if(custom)return custom;
 let r=MEAL.recipes?.[recipeName],txt=String(r?.ingredients?.[idx]||"").toLowerCase(),amt=parseIngredientAmount(r?.ingredients?.[idx]),g=amt?.amount||0,u=amt?.unit||"";
 // Built-in planning nutrition values for current week's measured ingredients. Exact package values can override these via Nutrition Lookup.
 let per100=null,each=null;
 if(/ground beef/.test(txt))per100={calories:250,protein:26,carbs:0,fat:17,fiber:0};
 else if(/ground chicken/.test(txt))per100={calories:143,protein:17.4,carbs:0,fat:8.1,fiber:0};
 else if(/chicken thigh/.test(txt))per100={calories:177,protein:24,carbs:0,fat:8,fiber:0};
 else if(/existing chicken|chicken,/.test(txt))per100={calories:165,protein:31,carbs:0,fat:3.6,fiber:0};
 else if(/dry pasta|noodles/.test(txt))per100={calories:371,protein:13,carbs:75,fat:1.5,fiber:3.2};
 else if(/broccoli/.test(txt))per100={calories:34,protein:2.8,carbs:6.6,fat:.4,fiber:2.6};
 else if(/onion/.test(txt))per100={calories:40,protein:1.1,carbs:9.3,fat:.1,fiber:1.7};
 else if(/carrot/.test(txt))per100={calories:41,protein:.9,carbs:9.6,fat:.2,fiber:2.8};
 else if(/celery/.test(txt))per100={calories:14,protein:.7,carbs:3,fat:.2,fiber:1.6};
 else if(/corn/.test(txt))per100={calories:86,protein:3.4,carbs:19,fat:1.2,fiber:2.7};
 else if(/potato/.test(txt))per100={calories:77,protein:2,carbs:17,fat:.1,fiber:2.2};
 else if(/lentil/.test(txt))per100={calories:352,protein:24.6,carbs:63.4,fat:1.1,fiber:10.7};
 else if(/ham/.test(txt))per100={calories:145,protein:21,carbs:1.5,fat:5.5,fiber:0};
 else if(/parmesan/.test(txt))per100={calories:431,protein:38,carbs:4.1,fat:29,fiber:0};
 else if(/cheddar/.test(txt))per100={calories:403,protein:25,carbs:1.3,fat:33,fiber:0};
 else if(/flour/.test(txt))per100={calories:364,protein:10.3,carbs:76.3,fat:1,fiber:2.7};
 else if(/panko/.test(txt))per100={calories:395,protein:13,carbs:72,fat:5,fiber:4.5};
 else if(/butter/.test(txt))per100={calories:717,protein:.9,carbs:.1,fat:81.1,fiber:0};
 else if(/ghee/.test(txt))per100={calories:900,protein:0,carbs:0,fat:100,fiber:0};
 else if(/heavy cream/.test(txt))per100={calories:340,protein:2.8,carbs:2.8,fat:36,fiber:0};
 else if(/fairlife milk|milk/.test(txt))per100={calories:52,protein:5.4,carbs:2.5,fat:2.1,fiber:0};
 else if(/tomato paste/.test(txt))per100={calories:82,protein:4.3,carbs:19,fat:.5,fiber:4.1};
 else if(/sun-dried/.test(txt))per100={calories:258,protein:14.1,carbs:55.8,fat:3,fiber:12.3};
 else if(/cornstarch/.test(txt))per100={calories:381,protein:.3,carbs:91.3,fat:.1,fiber:.9};
 else if(/egg/.test(txt))each={calories:72,protein:6.3,carbs:.4,fat:4.8,fiber:0};
 else if(/broth|stock|liquid aminos|worcestershire|garlic|ginger|seasoning|thyme|oregano|paprika|poultry seasoning|turmeric|curry powder|baking powder/.test(txt))per100={calories:20,protein:1,carbs:3,fat:.1,fiber:.3};
 if(each)return addMacros(emptyMacros(),each,g||1);
 if(per100&&g){let grams=g;if(u==="oz")grams*=28.3495;if(u==="lb")grams*=453.592;if(u==="tbsp")grams*=15;if(u==="tsp")grams*=5;if(u==="cup"||u==="cups")grams*=240;return addMacros(emptyMacros(),per100,grams/100)}
 return null
}
function recipeNutrition(recipeName){
 let r=MEAL.recipes?.[recipeName],key=selectedKey()+"|"+recipeName,adj=state.cookAdjustments?.[key]||{},components={main:emptyMacros(),side:emptyMacros()},unknown=[];
 (r?.ingredients||[]).forEach((txt,i)=>{let base=ingredientMacroBase(recipeName,i),change=adj.ingredients?.[i]||{},removed=/remove/i.test(String(change.amount||""))||/remove/i.test(String(change.name||""));if(!base){unknown.push(i);base=emptyMacros()}if(removed)base=emptyMacros();
   let delta={};for(let m of ["calories","protein","carbs","fat","fiber"])delta[m]=Number(change[m])||0;base=addMacros(base,delta);
   let t=String(txt).toLowerCase(),where=String(change.where||"").toLowerCase(),component=(/sauce/.test(where)||(/heavy cream|stock|broth|tomato paste|sun-dried|cornstarch/.test(t)&&/meatball/i.test(recipeName)))?"side":"main";
   components[component]=addMacros(components[component],base)
 });
 return {components:{main:roundMacros(components.main),side:roundMacros(components.side)},unknown}
}
function containerNutrition(recipeName,ci,mainG,sideG){
 let key=selectedKey()+"|"+recipeName,actual=state.cookLog[key]?.actual||state.cookDraft[key]||{},rn=recipeNutrition(recipeName),mt=Number(actual.main)||0,st=Number(actual.side)||0,m=emptyMacros();
 if(mt>0&&mainG>0)m=addMacros(m,rn.components.main,mainG/mt);
 if(st>0&&sideG>0)m=addMacros(m,rn.components.side,sideG/st);
 let c=state.cookAdjustments?.[key]?.containers?.[ci]||{};let delta={};for(let x of ["calories","protein","carbs","fat","fiber"])delta[x]=Number(c[x])||0;
 return {macros:roundMacros(addMacros(m,delta)),unknown:rn.unknown}
}
function macroLine(m){return `${Math.round(Number(m?.calories)||0)} kcal • ${Number(m?.protein||0).toFixed(1)}P • ${Number(m?.carbs||0).toFixed(1)}C • ${Number(m?.fat||0).toFixed(1)}F • ${Number(m?.fiber||0).toFixed(1)} fiber`}

function currentWeekMacroCoverage(){
 let planned=["Ham & Lentil Soup","Cheesy Cottage Pie"],out={};
 planned.forEach(rn=>{let n=recipeNutrition(rn);out[rn]={complete:n.unknown.length===0,missing:n.unknown.slice(),components:n.components}});
 let actual=(state.inventory.Containers||[]).filter(x=>String(x.id||"").startsWith("actual-")).map(x=>({name:x.name,complete:!!x.macros&&x.nutritionComplete!==false,macros:x.macros||null}));
 return {planned:out,actualContainers:actual}
}
function rawMeatLabel(meat,useDate,grams,storage){let rows=[String(meat||"MEAT").toUpperCase(),shortDayDate(useDate),`${Number(grams)||0} g`,String(storage||"FRIDGE").toUpperCase()];if(String(storage).toUpperCase()==="FREEZER")rows.push("THAW "+thawCode(useDate));return rows}
function purchasedGroceries(){let out=[];for(let store of ["Walmart","Detwiler’s"])(MEAL.grocery?.[store]||[]).forEach((item,i)=>{if(state.checks[`grocery|${store}|${i}`])out.push({store,item,i,key:`${store}|${i}`})});return out}
function purchaseDefaultLocation(item){let q=String(item).toLowerCase();if(/ground beef|ground chicken|chicken thigh|chicken breast|steak|meat|milk|carrot|celery|onion|banana|potato/.test(q))return "Fridge";if(/seasoning|pepper|powder|ginger|cinnamon|cream of tartar/.test(q))return "Seasonings";return "Pantry"}
function purchasedRawMeatPlan(){return purchasedGroceries().filter(x=>/ground beef|ground chicken|chicken thigh|chicken breast|steak|raw meat/i.test(String(x.item||""))).map(x=>{let text=String(x.item||""),gm=text.match(/(?:~\s*)?(\d+(?:\.\d+)?)\s*g\b/i),lb=text.match(/(\d+(?:\.\d+)?)\s*lb\b/i),grams=gm?Math.round(Number(gm[1])):lb?Math.round(Number(lb[1])*453.592):0;return {id:`purchase-${x.store}-${x.i}`,meat:text.replace(/\s*[—-].*$/,"").trim().toUpperCase(),grams,useDate:selectedKey(),storage:"FRIDGE"}})}
function mondayPortioningPanel(){let active=purchasedRawMeatPlan();if(!active.length)return "";let rows=active.map(x=>{let saved=state.rawPortions[x.id]||{},g=saved.grams??x.grams,loc=saved.storage||x.storage,label=rawMeatLabel(x.meat,x.useDate,g,loc);return `<div class="card soft raw-portion-card"><div class="row between"><div><b>${esc(x.meat)}</b><div class="muted">PURCHASED ${esc(shortDayDate(x.useDate))}</div></div><span class="statuspill">${esc(loc)}</span></div><div class="formgrid"><label>ACTUAL PORTION (G)<input type="number" min="1" step="1" data-raw-grams="${esc(x.id)}" value="${esc(g||"")}" placeholder="WEIGH ACTUAL"></label><label>LOCATION<select data-raw-location="${esc(x.id)}"><option ${loc==="FRIDGE"?"selected":""}>FRIDGE</option><option ${loc==="FREEZER"?"selected":""}>FREEZER</option></select></label></div><div class="label-preview"><b>MEAT LABEL</b><br>${label.map(esc).join("<br>")}</div><button class="btn primary" data-confirm-raw="${esc(x.id)}">${saved.confirmed?"CONFIRMED ✓":"CONFIRM PORTION + LOCATION"}</button></div>`}).join("");return `<section class="card monday-portioning"><h2>Raw Meat Portioning</h2><p class="muted">ONLY MEAT ACTUALLY MARKED PURCHASED APPEARS HERE. WEIGH THE ACTUAL AMOUNT; THE HUB DOES NOT INVENT A PACKAGE WEIGHT.</p>${rows}</section>`}

function prepVessels(name,r){return (r?.bowls||[]).map(x=>String(x)).map(x=>({text:x,type:/^PLATE/i.test(x)?"plate":/^LARGE BOWL/i.test(x)?"large":/^BOWL/i.test(x)?"little":/^CUTTING BOARD/i.test(x)?"board":"other"}))}
function cookEquipment(names){
 let recipeNames=names.map(cookRecipeName),recipes=recipeNames.map(n=>MEAL.recipes?.[n]).filter(Boolean),v=recipeNames.flatMap((n,i)=>prepVessels(n,MEAL.recipes?.[n])),plates=v.filter(x=>x.type==="plate").length,little=v.filter(x=>x.type==="little").length,large=v.filter(x=>x.type==="large").length,all=recipes.map(r=>r.method||"").join(" "),containers=recipeNames.reduce((n,rn)=>n+cookAssignments(rn).length,0);
 return [`1 cutting board + 1 knife`,`1 food scale`,`${plates} paper plate${plates===1?"":"s"}`,`${little} little prep bowl${little===1?"":"s"}`,`${large} larger mixing bowl${large===1?"":"s"}`,`1 set measuring cups/spoons`,/skillet/i.test(all)?`1 large skillet`:"",/pot/i.test(all)?`1 pot`:"",/oven/i.test(all)?`1 baking dish / oven-safe pan`:"",`Cooking utensils`,`${containers} meal-prep container${containers===1?"":"s"}`].filter(x=>x&&!/^0 (?:little|larger|paper)/.test(x))
}
function prefixedBowls(name,r){return (r?.bowls||[]).map(x=>{
 let str=String(x),m=str.match(/^(LARGE BOWL|BOWL|PLATE)\s*(\d+)\s*[—-]\s*([^:]+):?\s*(.*)$/i);if(m){let kind=/PLATE/i.test(m[1])?"Paper Plate":/LARGE/i.test(m[1])?"Large Bowl":"Bowl";return `${name.toUpperCase()} — ${kind} ${m[2]}: ${m[3].trim()}${m[4]?" — "+m[4].trim():""}`}
 let c=str.match(/^CUTTING BOARD\s*[—-]\s*([^:]+):?\s*(.*)$/i);if(c)return `${name.toUpperCase()} — Cutting Board: ${c[1].trim()}${c[2]?" — "+c[2].trim():""}`;
 return `${name.toUpperCase()} — ${str}`
})}
function timelineCard(i,x){return `<div class="card soft"><b>STEP ${i} • ${esc(x.meal)}</b><p><b>WHERE:</b> ${esc(x.where)}<br><b>WHAT:</b> ${esc(x.what)}<br><b>HEAT:</b> ${esc(x.heat)}<br><b>TIME:</b> ${esc(x.time)}<br><b>LOOK FOR:</b> ${esc(x.look)}</p><p class="muted"><b>WHILE THAT COOKS:</b> ${esc(x.while)}</p></div>`}
function combinedCookTimeline(names){
 const k=selectedKey(),T={
 "2026-09-28":[
 {meal:"Beef & Broccoli Garlic Noodles",where:"Pasta pot",what:"Start water for BEEF — Bowl 3: Noodles.",heat:"High",time:"Until boiling",look:"A full rolling boil",while:"Form the chicken meatballs from CHICKEN — Large Bowl 1: Meatball Mixture."},
 {meal:"Marry Me Chicken Meatballs",where:"Chicken skillet",what:"Brown the formed meatballs from CHICKEN — Large Bowl 1: Meatball Mixture in a light coating of cooking fat.",heat:"Medium",time:"About 8–12 minutes total, turning",look:"Browned outside and 165°F in the center",while:"Add BEEF — Bowl 3: Noodles to the boiling pasta water and cook to package al dente."},
 {meal:"Beef & Broccoli Garlic Noodles",where:"Pasta pot",what:"Cook BEEF — Bowl 3: Noodles; reserve 120 mL pasta water before draining.",heat:"High then steady boil",time:"Package al-dente time",look:"Tender with a slight bite",while:"Finish checking the chicken meatballs; transfer them to a clean plate when they reach 165°F."},
 {meal:"Beef & Broccoli Garlic Noodles",where:"Beef skillet",what:"Melt 14 g butter, then add BEEF — Paper Plate 1: Protein.",heat:"Medium-high",time:"6–8 minutes",look:"Beef browned with no pink remaining",while:"In the chicken skillet, start CHICKEN — Bowl 2: Sauce Base."},
 {meal:"Marry Me Chicken Meatballs",where:"Chicken skillet",what:"Cook CHICKEN — Bowl 2: Sauce Base.",heat:"Medium",time:"1–2 minutes",look:"Garlic fragrant and tomato paste slightly darkened",while:"Add BEEF — Bowl 2: Aromatics to the browned ground beef."},
 {meal:"Beef & Broccoli Garlic Noodles",where:"Beef skillet",what:"Add BEEF — Bowl 2: Aromatics.",heat:"Medium-high",time:"2 minutes",look:"Onion beginning to soften and ginger fragrant",while:"Pour CHICKEN — Large Bowl 3: Sauce Liquid into the chicken skillet."},
 {meal:"Marry Me Chicken Meatballs",where:"Chicken skillet",what:"Add CHICKEN — Large Bowl 3: Sauce Liquid and bring to a gentle simmer; do not hard-boil.",heat:"Medium-low",time:"3–5 minutes",look:"Creamy sauce lightly thickened",while:"Add the broccoli from BEEF — Cutting Board plus 30–60 mL reserved pasta water to the beef skillet."},
 {meal:"Beef & Broccoli Garlic Noodles",where:"Beef skillet",what:"Add BEEF — Cutting Board: Broccoli plus reserved pasta water; cover.",heat:"Medium",time:"3–5 minutes",look:"Broccoli hot and tender",while:"Return the cooked chicken meatballs to their sauce and keep at a gentle simmer."},
 {meal:"Beef & Broccoli Garlic Noodles",where:"Beef skillet",what:"Re-whisk and pour in BEEF — Bowl 1: Sauce.",heat:"Medium",time:"2–4 minutes",look:"Sauce glossy and thick enough to coat",while:"Keep chicken sauce warm; prepare to weigh meatballs and sauce separately before packing."},
 {meal:"Beef & Broccoli Garlic Noodles",where:"Beef skillet",what:"Add drained noodles and toss. Add reserved pasta water only as needed to keep both portions saucy.",heat:"Low",time:"1–2 minutes",look:"Noodles evenly coated and still juicy",while:"Turn off chicken heat once everything is hot."},
 {meal:"Both meals",where:"Scale station",what:"MEASURE FINISHED TOTALS BEFORE PACKING. Weigh the finished beef-noodle dish. For chicken, weigh cooked meatballs, sauce, and cooked pasta separately.",heat:"Off",time:"Before anything is portioned",look:"All required finished weights recorded",while:"Set out the four meal-prep containers and labels."}
 ],
 "2026-09-30":[
 {meal:"Ham & Lentil Soup",where:"Soup pot",what:"Melt 14 g butter. Add HAM & LENTIL SOUP — Cutting Board vegetables/garlic.",heat:"Medium",time:"6–8 minutes",look:"Vegetables beginning to soften",while:"Preheat oven to 400°F and start Chicken Cobbler chicken in the oven-safe skillet."},
 {meal:"Chicken Cobbler",where:"Oven-safe skillet",what:"Cook CHICKEN COBBLER — Paper Plate 1 chicken.",heat:"Medium-high",time:"Until the thickest piece reaches 165°F",look:"Chicken fully cooked",while:"Stir soup vegetables as needed."},
 {meal:"Ham & Lentil Soup",where:"Soup pot",what:"Add HAM & LENTIL SOUP — Bowl 1 lentils + seasonings, stir 30 seconds, then pour in the Measuring Jug stock.",heat:"Bring to boil, then steady low simmer",time:"25–35 minutes",look:"Lentils tender; soup remains brothy",while:"Remove cooked cobbler chicken to a clean surface and cook the cobbler vegetables in the same skillet."},
 {meal:"Chicken Cobbler",where:"Same oven-safe skillet",what:"Add CHICKEN COBBLER — Cutting Board vegetables and cook, then re-whisk and pour in CHICKEN COBBLER — Measuring Jug gravy. Return chicken.",heat:"Medium",time:"5–7 minutes vegetables + 3–5 minutes gravy",look:"Vegetables softening and filling coated in a saucy gravy",while:"Add 56 g melted butter + 85 g cheddar directly into CHICKEN COBBLER — Large Bowl 1 dry topping and mix only until spoonable."},
 {meal:"Chicken Cobbler",where:"Same skillet / oven",what:"Spoon topping over the hot filling and bake.",heat:"400°F",time:"18–25 minutes",look:"Topping golden/cooked through and filling bubbling",while:"When soup has 5 minutes left, add HAM & LENTIL SOUP — Paper Plate 1 ham."},
 {meal:"Ham & Lentil Soup",where:"Soup pot",what:"Stir in diced ham for the final 5 minutes. Add measured water only if needed to keep it brothy.",heat:"Low simmer",time:"5 minutes",look:"Ham hot and lentils tender",while:"Check cobbler near the end of its bake."},
 {meal:"Both meals",where:"Measurements",what:"When cooking is finished, enter each finished recipe total in MEASUREMENTS. These totals create the live suggested container weights; they are not container weights themselves.",heat:"Off",time:"Before packing",look:"Finished totals entered",while:"Set out the four containers and labels."}
 ],
 "2026-10-01":[
 {meal:"Cheesy Cottage Pie",where:"Pot + skillet",what:"Start CHEESY COTTAGE PIE potatoes in cold water. While they heat, brown the cottage-pie ground chicken.",heat:"Pot high then simmer • skillet medium-high",time:"Potatoes 12–18 minutes once boiling • ground chicken 6–8 minutes",look:"Potatoes fork-tender; ground chicken browned with no pink",while:"Start Chicken & Dumplings chicken in its wide pot."},
 {meal:"Chicken & Dumplings",where:"Wide pot",what:"Brown CHICKEN & DUMPLINGS — Paper Plate 1 chicken in 14 g butter, then add its Cutting Board vegetables.",heat:"Medium-high then medium",time:"About 6–8 minutes chicken + 5 minutes vegetables",look:"Chicken browned; vegetables beginning to soften",while:"Add cottage-pie vegetables to the browned ground-chicken skillet."},
 {meal:"Cheesy Cottage Pie",where:"Skillet",what:"Cook CHEESY COTTAGE PIE vegetables about 5 minutes, then re-whisk and add its Measuring Jug gravy.",heat:"Medium",time:"5 minutes + 3–5 minute simmer",look:"A thick, generous gravy",while:"Pour CHICKEN & DUMPLINGS — Measuring Jug liquid into its pot and bring to a gentle simmer."},
 {meal:"Chicken & Dumplings",where:"Wide pot",what:"Simmer chicken/vegetables until chicken reaches 165°F. Add 60 mL milk + 28 g melted butter directly to CHICKEN & DUMPLINGS — Bowl 1 dry mix; stir only until combined.",heat:"Medium-low",time:"Until chicken reaches 165°F",look:"Chicken cooked and gravy gently simmering",while:"Drain cottage-pie potatoes and mash with CHEESY COTTAGE PIE — Bowl 1 mash finish."},
 {meal:"Cheesy Cottage Pie",where:"Scale + baking dish",what:"Enter finished ground-chicken filling and mash totals in MEASUREMENTS, assemble the pie, then bake.",heat:"400°F",time:"15–20 minutes",look:"Hot throughout; top lightly browned",while:"Drop Chicken & Dumplings batter over its simmering filling and cover."},
 {meal:"Chicken & Dumplings",where:"Wide pot",what:"Cook dumplings covered; do not lift the lid for the first 12 minutes.",heat:"Medium-low",time:"12–15 minutes",look:"Center dumpling cooked through",while:"Cottage pie bakes hands-off."},
 {meal:"Both meals",where:"Measurements + containers",what:"Enter the final Chicken & Dumplings total. Use live suggestions only as guidance; weigh the ACTUAL amount placed into every container, record any container-specific additions, label, store, and clean the two cooking stations.",heat:"Off",time:"Finish within the 90-minute cook-session ceiling",look:"Four planned portions packed; actual weights and changes saved",while:"Cool freezer portions promptly."}
 ]};
 let rows=T[k];if(rows)return rows.map((x,i)=>timelineCard(i+1,x)).join("");
 // Fallback for future cook days: preserve recipe order and fully identify any bowl reference.
 let out=[],i=0;for(let raw of names){let rn=cookRecipeName(raw),r=MEAL.recipes?.[rn];for(let step of String(r?.method||"").split(/(?<=[.!?])\s+/).filter(Boolean)){out.push(timelineCard(++i,{meal:rn,where:/oven/i.test(step)?"OVEN":/skillet/i.test(step)?`${rn.toUpperCase()} SKILLET`:/pot/i.test(step)?`${rn.toUpperCase()} POT`:`${rn.toUpperCase()} STATION`,what:step,heat:(step.match(/\b(medium-high|medium-low|medium|low|high)\b/i)||[])[1]||"As stated",time:(step.match(/\b(?:about\s+)?\d+(?:–|-| to )?\d*\s*(?:minutes?|seconds?)\b/i)||[])[0]||"Until ready cue",look:(step.match(/until ([^.;]+)/i)||[])[1]||"Use the stated doneness cue",while:"Continue to the next hands-on step when this becomes hands-off."}))}}return out.join("")
}
function finishCooking(dayIndex,recipeIndex){
 let d=DAYS[dayIndex],day=(MEAL.days||{})[selectedKey()],name=day?.cook?.[recipeIndex],rn=Object.keys(MEAL.recipes||{}).find(x=>name?.startsWith(x)),r=MEAL.recipes[rn];name=rn||name;if(!r)return;
 let tx=`${selectedKey()}|${name}`;
 if(state.cookLog[tx]?.status==="awaitingPacking"){
  let actual={};document.querySelectorAll(`[data-cook-weight^="${recipeIndex}|"]`).forEach(el=>{let part=el.dataset.cookWeight.split("|")[1];if(el.value!=="")actual[part]=Math.max(0,Number(el.value)||0)});
  if(!Object.values(actual).some(v=>Number(v)>0)){showToast("The food is already cooked. Enter the finished weights when you are ready to pack it; nothing will be deducted again.","Awaiting weights + packing");return}
  let targets=cookAssignments(name);if(!targets.length)targets=[{date:selectedKey(),meal:"LUNCH",storage:"FRIDGE"},{date:selectedKey(),meal:"DINNER",storage:"FREEZER"}];let portions=targets.length;
  let perMain=Number.isFinite(actual.main)?actual.main/portions:null,perSide=Number.isFinite(actual.side)?actual.side/portions:null;
  if(targets.some((_,i)=>!Number.isFinite(actual[`c${i}main`])||actual[`c${i}main`]<=0)){showToast("Enter the actual MAIN scale weight for every container. Suggested weights are not saved as actual weights.","Actual container weights needed");return}
  state.inventory.Containers=(state.inventory.Containers||[]).filter(x=>!(x.created==="2026-09-28"&&x.recipe===name));
  targets.forEach((target,i)=>{let cm=actual[`c${i}main`],cs=Number.isFinite(actual[`c${i}side`])?actual[`c${i}side`]:null,grams=[`MAIN ${+cm.toFixed(1)} g`,cs!=null?`SIDE ${+cs.toFixed(1)} g`:""].filter(Boolean).join(" • ");state.inventory.Containers.push({name:`${name} • Container ${i+1}`,qty:`${target.storage} • EAT ${shortDayDate(target.date)} ${target.meal} • ${grams}`,storage:target.storage,eat:shortDayDate(target.date),meal:target.meal,labelRows:physicalLabel(target),recipe:name,created:selectedKey(),gramsMain:cm,gramsSide:cs,suggestedMain:perMain,suggestedSide:perSide,cookAdjustments:structuredClone(state.cookAdjustments?.[tx]||{}),macroAdjustments:structuredClone(state.cookAdjustments?.[tx]?.containers?.[i]||{}),macros:containerNutrition(rn,i,cm,cs).macros,nutritionComplete:containerNutrition(rn,i,cm,cs).unknown.length===0})});
  state.cookLog[tx]={...state.cookLog[tx],actual,status:"packed",packedAt:new Date().toISOString()};
  state.foodHistory=(state.foodHistory||[]).filter(x=>!((x.date||"").slice(0,10)===selectedKey()&&x.recipe===name&&String(x.type||"").startsWith("COOKED")));
  state.foodHistory.push({id:uid("food"),date:selectedKey(),type:"COOKED + PACKED",recipe:name,containers:portions});save();render();showToast("Weights saved and containers created. Inventory was not deducted a second time.","Packed");return
 }
 if(state.cookLog[tx]){showToast("This recipe is already marked cooked and packed. Inventory was not deducted again.","Already saved");return}
 let used=[],unresolved=[],inventoryBefore=JSON.stringify(state.inventory);
 (r.ingredients||[]).forEach((line,ingredientIndex)=>{
   let draft=state.cookDraft[tx]||{},input=document.querySelector(`[data-cook-ingredient="${recipeIndex}|${ingredientIndex}"]`),override=input&&input.value!==""?Number(input.value):Number(draft["ingredient"+ingredientIndex]);
   let result=consumeIngredient(line,Number.isFinite(override)&&override>0?override:null);used.push(result);if(!result.deducted)unresolved.push(`${line} — ${result.reason}`);
 });
 if(unresolved.length){state.inventory=JSON.parse(inventoryBefore);showToast("Nothing was deducted. Fix/add these Inventory items first: "+unresolved.join(" • "),"Inventory check needed");return}
 let actual={};document.querySelectorAll(`[data-cook-weight^="${recipeIndex}|"]`).forEach(el=>{let part=el.dataset.cookWeight.split("|")[1];if(el.value!=="")actual[part]=Math.max(0,Number(el.value)||0)});
 if(!Object.values(actual).some(v=>Number(v)>0)){state.cookLog[tx]={date:selectedKey(),day:d,recipe:name,used,unmatched:[],actual:{},status:"awaitingPacking",inventorySynced:true,finishedAt:new Date().toISOString()};delete state.cookDraft[tx];state.foodHistory=(state.foodHistory||[]).filter(x=>!((x.date||"").slice(0,10)===selectedKey()&&x.recipe===name&&String(x.type||"").startsWith("COOKED")));state.foodHistory.push({id:uid("food"),date:selectedKey(),type:"COOKED — AWAITING WEIGHTS/PACKING",recipe:name,containers:0});save();render();showToast("Cooking saved and Inventory updated once. Enter the finished weight when you pack; Inventory will not be deducted again.","Awaiting weights + packing");return}
 let targets=cookAssignments(name);if(!targets.length)targets=[{date:selectedKey(),meal:"LUNCH",storage:"FRIDGE"},{date:selectedKey(),meal:"DINNER",storage:"FREEZER"}];let portions=targets.length;
 let perMain=Number.isFinite(actual.main)?actual.main/portions:null,perSide=Number.isFinite(actual.side)?actual.side/portions:null;
 if(targets.some((_,i)=>!Number.isFinite(actual[`c${i}main`])||actual[`c${i}main`]<=0)){state.inventory=JSON.parse(inventoryBefore);showToast("Enter the actual MAIN scale weight for every container before finishing. Suggested weights are guidance only.","Actual container weights needed");return}
 for(let n=1;n<=portions;n++){let target=targets[n-1],i=n-1,cm=actual[`c${i}main`],cs=Number.isFinite(actual[`c${i}side`])?actual[`c${i}side`]:null,grams=[`MAIN ${+cm.toFixed(1)} g`,cs!=null?`SIDE ${+cs.toFixed(1)} g`:""].filter(Boolean).join(" • ");state.inventory.Containers.push({name:`${name} • Container ${n}`,qty:`${target.storage} • EAT ${shortDayDate(target.date)} ${target.meal} • ${grams}`,storage:target.storage,eat:shortDayDate(target.date),meal:target.meal,labelRows:physicalLabel(target),recipe:name,created:selectedKey(),gramsMain:cm,gramsSide:cs,suggestedMain:perMain,suggestedSide:perSide,cookAdjustments:structuredClone(state.cookAdjustments?.[tx]||{}),macroAdjustments:structuredClone(state.cookAdjustments?.[tx]?.containers?.[i]||{}),macros:containerNutrition(rn,i,cm,cs).macros,nutritionComplete:containerNutrition(rn,i,cm,cs).unknown.length===0})}
 state.cookLog[tx]={date:selectedKey(),day:d,recipe:name,used,unmatched:unresolved,actual,status:"packed",inventorySynced:true,finishedAt:new Date().toISOString()};delete state.cookDraft[tx];
 state.foodHistory.push({id:uid("food"),date:selectedKey(),type:"COOKED",recipe:name,containers:portions});
 save();render();
 if(unresolved.length)showToast("Cooking saved. Verify unchanged ingredients in Inventory: "+unresolved.join(" • "),"Cooking saved")
}


// Single immutable Cooking shell. All current Cooking UI renders from this base only.
function cook(){ return cookCanonicalV7(); }

const GYM_PLAN={
Monday:{title:"GLUTES & QUADS",steps:[
{name:"BARBELL HIP THRUST",rest:"3 MINUTES",inc:10,mode:"third",sets:[["45 + 25",12],["2 × 45",10],["2 × 45 + 35",8]]},
{name:"HACK SQUAT",rest:"2 MINUTES 30 SECONDS",inc:30,mode:"third",sets:[["",12],["",10],["",8]]},
{name:"SMITH REVERSE LUNGES",rest:"2 MINUTES",inc:30,mode:"third",sets:[["15",12],["25",10],["35",8]]},
{name:"LEG EXTENSIONS",rest:"2 MINUTES",inc:15,mode:"third",sets:[["115",12],["130",10],["145",8]]},

{name:"CALF RAISES",rest:"1 MINUTE 30 SECONDS",inc:15,mode:"third",sets:[["145",12],["160",10],["175",8]]},
{name:"AB CRUNCH MACHINE",rest:"1 MINUTE 30 SECONDS",inc:10,mode:"third",sets:[["60",12],["70",10],["80",8]]}]},
Wednesday:{title:"UPPER BODY",steps:[
{name:"LAT PULLDOWNS",rest:"2 MINUTES 30 SECONDS",inc:15,mode:"third",sets:[["85",12],["100",10],["115",8]]},
{name:"VERTICAL ROW MACHINE",rest:"2 MINUTES 30 SECONDS",inc:10,mode:"third",sets:[["40",12],["50",10],["60",8]]},
{name:"STRAIGHT-ARM CABLE PULLDOWNS",rest:"1 MINUTE 30 SECONDS",inc:5,mode:"all",sets:[["10",12],["10",12],["10",12]]},
{name:"SHOULDER PRESS MACHINE",rest:"2 MINUTES",inc:10,mode:"third",sets:[["35",12],["45",10],["55",8]]},
{name:"REAR-DELT FLY MACHINE",rest:"1 MINUTE 30 SECONDS",inc:10,mode:"all",sets:[["20",12],["20",12],["20",12]]},
{name:"LATERAL RAISES",rest:"1 MINUTE 30 SECONDS",inc:5,mode:"all",sets:[["5",12],["5",12],["5",12]]},
{name:"PREACHER CURL MACHINE",rest:"1 MINUTE 30 SECONDS",inc:10,mode:"all",sets:[["20",12],["20",12],["20",12]]},
{name:"ASSISTED DIPS",rest:"1 MINUTE 30 SECONDS",inc:20,mode:"all",assistance:true,sets:[["120",12],["120",10],["120",8]]},
{name:"AB CRUNCH MACHINE",rest:"1 MINUTE 30 SECONDS",inc:10,mode:"third",sets:[["60",12],["70",10],["80",8]]}]},
Friday:{title:"GLUTES & HAMSTRINGS",steps:[
{name:"BARBELL HIP THRUST",rest:"3 MINUTES",inc:10,mode:"third",sets:[["45 + 25",12],["2 × 45",10],["2 × 45 + 25",8]]},
{name:"LEG PRESS MACHINE",rest:"2 MINUTES 30 SECONDS",inc:20,mode:"third",sets:[["",12],["",10],["",8]]},
{name:"DUMBBELL-PAIR RDLS",rest:"2 MINUTES 30 SECONDS",inc:5,mode:"third",sets:[["20",12],["25",10],["30",8]]},
{name:"LYING LEG CURL MACHINE",rest:"2 MINUTES",inc:10,mode:"third",sets:[["",12],["",10],["",8]]},
{name:"SEATED ABDUCTOR MACHINE",rest:"1 MINUTE 30 SECONDS",inc:10,mode:"third",sets:[["120",12],["130",10],["140",8]]},
{name:"CALF RAISES",rest:"1 MINUTE 30 SECONDS",inc:15,mode:"third",sets:[["145",12],["160",10],["175",8]]},
{name:"AB CRUNCH MACHINE",rest:"1 MINUTE 30 SECONDS",inc:10,mode:"third",sets:[["60",12],["70",10],["80",8]]}]}};
const DAY_ACTIVITY={Monday:"GYM",Tuesday:"RUN",Wednesday:"GYM",Thursday:"RUN",Friday:"GYM",Saturday:"REST",Sunday:"REST"};
const AB_MOVES=["KNEE CRUNCHES — 8 REPS","STRAIGHT LEG LIFTS — 12 REPS","ALTERNATING KNEE RAISES — 5 EACH LEG","AROUND THE WORLDS — 8 REPS","SIDE CRUNCHES — 4 EACH SIDE","HOLD UNTIL FAILURE"];
function runScreen(){
 let d=DAYS[state.day],k=selectedKey(),r=state.run[k]||{};
 return hero("Run",d)+back("Gym")+`<section class="comment-widget"><p>LOG THE RUN YOU ACTUALLY DID. THIS SAVES TO HISTORY AND BODY PROGRESS FOR THIS DATE.</p></section><section class="card"><h2>Run Actuals</h2><div class="run-entry-grid"><label>Incline<input id="runIncline" type="number" min="0" step=".1" inputmode="decimal" value="${esc(r.incline??"")}" placeholder="Incline"></label><label>Speed<input id="runSpeed" type="number" min="0" step=".1" inputmode="decimal" value="${esc(r.speed??"")}" placeholder="Speed"></label><label>Time (minutes)<input id="runDuration" type="number" min="0" step="1" inputmode="numeric" value="${esc(r.duration??"")}" placeholder="Minutes"></label></div><div class="app-actions"><button class="btn primary" data-save-run>SAVE RUN</button><button class="btn" data-sub="body">BODY PROGRESS</button></div></section>`;
}
function dayTruthAuditV53(){return DAYS.map((d,i)=>({day:d,activity:DAY_ACTIVITY[d],hasStrength:!!GYM_PLAN[d],todayRun:(DAY_ACTIVITY[d]==="RUN")}));}
function gym(){
 if(state.sub==="run")return runScreen();if(state.sub==="body")return body();
 let d=DAYS[state.day],k=selectedKey(),plan=GYM_PLAN[d];
 if(!plan){if(DAY_ACTIVITY[d]==="RUN"){let r=state.run[k];return hero("Gym + Run",d)+`<section class="comment-widget"><p>${r?.duration?`RUN SAVED • ${r.duration} MIN • INCLINE ${r.incline} • SPEED ${r.speed}`:"RUN DAY • ENTER INCLINE, SPEED, AND TIME AFTER YOU RUN."}</p></section><div class="grid"><button class="tile" data-sub="run"><b>RUN</b><span>Incline • speed • time</span></button><button class="tile" data-sub="body"><b>BODY PROGRESS</b><span>Weight • measurements • runs</span></button></div>`}if(DAY_ACTIVITY[d]==="REST")return hero("Gym",d)+`<section class="card"><p>REST / RECOVERY DAY.</p><button class="tile" data-sub="body"><b>BODY PROGRESS</b><span>Weight • measurements • runs</span></button></section>`;return hero("Gym",d)+`<section class="card"><p>ACTIVITY PLAN NEEDS ATTENTION.</p></section>`}
 let log=state.gymLog[k]||{},targets=state.gymTargets||{},allDone=plan.steps.every(ex=>log[ex.name]?.done);
 return hero("Gym",d)+`<section class="comment-widget"><p><b>${esc(plan.title)}</b> • 3 SETS MAX • 12 REPS MAX. ACTUALS START AT 0. USE THE TOP HEART TO FILL THE WHOLE WORKOUT AS PLANNED, THEN UNCHECK ANY SET YOU CHANGED AND TYPE WHAT YOU ACTUALLY DID.</p></section><section class="card"><div class="workout-master"><button class="heartbtn ${allDone?'on':''}" data-gym-all-planned aria-label="Did entire workout as planned"><span class="theme-heart"></span></button><div style="flex:1"><b>DID ENTIRE WORKOUT AS PLANNED</b><div class="muted">FILLS ALL ACTUAL SET BOXES WITH THE PLAN. UNCHECK A SET TO EDIT IT.</div></div>${allDone?'<span class="paid-tag">WORKOUT COMPLETE</span>':''}</div>${plan.steps.map((ex,ei)=>{let z=log[ex.name]||{},tk=d+"|"+ex.name,custom=targets[tk]||ex.sets;return `<div class="exercise-card ${z.done?'completed':''}"><div class="exercise-title"><span class="theme-heart"></span><div style="flex:1"><b>${esc(ex.name)}</b><div class="muted">REST ${esc(ex.rest)}${ex.assistance?" • LOWER ASSISTANCE = PROGRESS":""}</div></div></div>${custom.map((st,i)=>{let planned=z['p'+i]===true;return `<div class="setrow"><b>SET ${i+1}</b><input class="setplan" type="checkbox" data-gym-set-planned="${ei}|${i}" ${planned?'checked':''} aria-label="Set ${i+1} as planned"><label>ACTUAL ${ex.assistance?"ASSIST":"WEIGHT"}<input data-gym-field="${esc(ex.name)}|w${i}" value="${esc(z['w'+i]??'0')}" inputmode="decimal"></label><label>REPS<input type="number" min="0" max="12" data-gym-field="${esc(ex.name)}|r${i}" value="${esc(z['r'+i]??'0')}"></label><button class="btn set-ready" data-gym-up-weight="${ei}|${i}" title="Increase actual weight"><span class="theme-heart"></span></button></div><div class="price-est">PLAN • ${esc(st[0]||"CHOOSE WEIGHT")} × ${st[1]}</div>`}).join("")}</div>`}).join("")}<button class="btn primary" data-save-gym>SAVE WORKOUT</button></section><details class="info-accordion"><summary>15-MINUTE AB CIRCUIT</summary><div>${AB_MOVES.map((x,i)=>checkbox("ab|"+k+"|"+i,x)).join("")}</div></details><details class="info-accordion"><summary>TREADMILL</summary><div><p><b>30 MIN • SPEED 3.0 • INCLINE 5–6</b></p></div></details><button class="tile" data-sub="body"><b>BODY PROGRESS</b><span>WEIGHT + MONDAY MEASUREMENTS + RUNS</span></button>`;
}
function body(){let dates=[...new Set([...Object.keys(state.weight),...Object.keys(state.measure),...Object.keys(state.run||{})])].filter(d=>validDateKey(d)&&(hasWeight(d)||hasMeasure(d)||hasRun(d))).sort().reverse().slice(0,12);return hero("Body Progress","Weight • Monday measurements • runs")+back("Gym")+`<section class="card"><h2>Progress History</h2>${dates.map(k=>{let m=state.measure[k]||{},r=state.run[k];return `<div class="taskcard"><b>${esc(k)}</b><p>${state.weight[k]!==""&&state.weight[k]!=null?`Weight: ${esc(state.weight[k])} lb`:""}${m.glutes!==""&&m.glutes!=null?` • Glutes: ${esc(m.glutes)}`:""}${m.waist!==""&&m.waist!=null?` • Waist: ${esc(m.waist)}`:""}${m.arms!==""&&m.arms!=null?` • Arms: ${esc(m.arms)}`:""}${r?.duration?`<br>Run: ${esc(r.duration)} min • incline ${esc(r.incline)} • speed ${esc(r.speed)}`:""}</p></div>`}).join("")||'<p class="muted">Save weigh-ins, Monday measurements, or runs to build progress.</p>'}</section>`}
function autopayOverrideKey(x){return `${localDateKey(x.date)}|${encodeURIComponent(x.n)}|${Number(x.baseA??x.a).toFixed(2)}`}
function autopayOverrideAmount(x){let v=state.budget.autopayOverrides?.[autopayOverrideKey(x)];return v===undefined||v===null||v===""?null:Number(v)}
function hasAutopayOverride(x){return Number.isFinite(autopayOverrideAmount(x))}
function effectiveAutopayAmount(x){let v=autopayOverrideAmount(x);return Number.isFinite(v)?Math.max(0,v):Math.max(0,Number(x.a)||0)}
function monthRows(y,m){
 let last=new Date(y,m+1,0).getDate(),rows=[];
 BILLS.forEach(([n,a,d],bi)=>{let octCard=n==="Credit Card Bill"&&y===2026&&m===9,defaultAmt=octCard?300:a,display=n;if(n==="Rent")display=`${new Date(y,m,1).toLocaleString("en",{month:"long"})} Rent`;let row={n,display,a:defaultAmt,baseA:a,d,date:new Date(y,m,Math.min(d,last)),kind:"bill",billIndex:bi,monthOnly:octCard?"OCTOBER 2026 ONLY • NORMAL MONTHS $25":null};row.a=effectiveAutopayAmount(row);rows.push(row)});
 for(let d=1;d<=last;d++)if(new Date(y,m,d).getDay()===2){let row={n:"Airlearn",a:4.99,baseA:4.99,d,date:new Date(y,m,d),kind:"bill",billIndex:"airlearn"};row.a=effectiveAutopayAmount(row);rows.push(row)}
 if(y===2026&&m===9){let row={n:"Mom Payback",a:200,baseA:200,d:13,date:new Date(2026,9,13),kind:"bill",billIndex:"mom",monthOnly:"OCTOBER 2026 ONLY"};row.a=effectiveAutopayAmount(row);rows.push(row)}
 return rows.sort((a,b)=>a.date-b.date)
}
function paydays(y,m){
 const anchor=new Date(2026,8,30,12), first=new Date(y,m,1,12), last=new Date(y,m+1,0,12), out=[];
 let d=new Date(anchor),step=7*86400000;
 while(d>first)d=new Date(d.getTime()-step);
 while(d<first)d=new Date(d.getTime()+step);
 for(;d<=last;d=new Date(d.getTime()+step))out.push(d.getDate());
 return out;
}
function nextPaydayOnOrAfter(dt){
 const anchor=new Date(2026,8,30,12),step=7*86400000;
 let n=Math.ceil((new Date(dt.getFullYear(),dt.getMonth(),dt.getDate(),12)-anchor)/step);
 return new Date(anchor.getTime()+Math.max(0,n)*step);
}
function secondTuesdayDate(y,m){let hits=[];for(let d=1;d<=14;d++)if(new Date(y,m,d).getDay()===2)hits.push(d);return new Date(y,m,hits[1]||14,12)}
function rentTargetForDue(due,now=new Date()){
 let key=autopayKey({n:"Rent",a:NORMAL_RENT,date:new Date(due)}),paid=!!state.checks[key],ev=state.budget.paymentEvents?.[key],remembered=Number(ev?.amount);
 if(paid&&Number.isFinite(remembered)&&remembered>0)return remembered;
 let afterFirst=now>new Date(due.getFullYear(),due.getMonth(),1,23,59,59);
 return (!paid&&afterFirst)?EMERGENCY_RENT:NORMAL_RENT;
}
function rentAmountForDue(due,now=new Date()){let row={n:"Rent",a:NORMAL_RENT,baseA:NORMAL_RENT,date:new Date(due)};let v=autopayOverrideAmount(row);return Number.isFinite(v)?Math.max(0,v):rentTargetForDue(due,now)}
function activeRentCycle(now=new Date()){
 let due=new Date(now.getFullYear(),now.getMonth(),1,12);
 for(let guard=0;guard<12;guard++){
   let row={n:"Rent",a:NORMAL_RENT,date:new Date(due)};
   if(!state.checks[autopayKey(row)])break;
   due=new Date(due.getFullYear(),due.getMonth()+1,1,12);
 }
 let deadline=nextPaydayOnOrAfter(now),rentMonth=new Date(due.getFullYear(),due.getMonth(),1,12);
 return {due,deadline,rentMonth,id:`${due.getFullYear()}-${due.getMonth()}`};
}
function outstandingRowsForProjection(){
 let anchor=new Date((state.budget.balanceAsOf||"2026-09-28")+"T12:00:00"),out=[];
 Object.values(state.budget.outstandingByMonth||{}).flat().forEach(o=>{
  if(!validDateKeyRaw(o.carryDate)||!validDateKeyRaw(o.originalDate))return;
  let original=new Date(o.originalDate+"T12:00:00"),fake={n:o.name,a:Number(o.amount||0),date:original};if(state.checks[autopayKey(fake)])return;
  let d=new Date(o.carryDate+"T12:00:00");if(d<=anchor){d=new Date(anchor);d.setDate(d.getDate()+1)}
  out.push({n:"Outstanding: "+o.name,a:Math.max(0,Number(o.amount||0)),d:d.getDate(),date:d,kind:"outstanding",outstanding:true,originalDate:o.originalDate,skipId:`OUT:${o.originalDate}:${o.name}`});
 });return out;
}
function skipKey(x){return x.skipId||`${x.n}|${x.d}`}
function isSkipped(em,x){return !!(em?.skip?.[skipKey(x)]||em?.skip?.[x.n+"|"+x.d]||em?.skip?.[x.n])}
function budgetEvents(y,m){
 let ev=[],rows=monthRows(y,m),em=state.budget.emergency[`${y}-${m}`]||{on:false,skip:{}};
 for(let d of paydays(y,m)){let date=new Date(y,m,d);[["job1","Job #1",JOB_INCOME.job1],["job2","Job #2",JOB_INCOME.job2],["jeremiah","Jeremiah",JOB_INCOME.jeremiah]].forEach(([source,label,amount])=>{let key=incomeSourceKey(date,source),received=!!state.checks[key];ev.push({date,label,amount:received?0:amount,kind:"income",received,incomeKey:key,incomeSource:source})});ev.push({date,label:"Weekly envelopes",amount:-WEEKLY_ENVELOPES,kind:"spend"});ev.push({date,label:"Weekly savings",amount:-WEEKLY_SAVINGS,kind:"save"})}
 let uid=`${y}-${m}`;(state.budget.unplannedByMonth?.[uid]||[]).forEach((u,i)=>{let day=Math.max(1,Math.min(new Date(y,m+1,0).getDate(),+u.day||1));ev.push({date:new Date(y,m,day),label:"Unplanned: "+u.item,amount:-Math.max(0,Number(u.amount||0)),kind:"spend",unplanned:true})});
 outstandingRowsForProjection().forEach(o=>{if(o.date.getFullYear()!==y||o.date.getMonth()!==m)return;let activeEm=state.budget.emergency[activeRentCycle().id]||{on:false,skip:{}};let skipped=(em.on&&isSkipped(em,o))||(activeEm.on&&isSkipped(activeEm,o));let amt=skipped?0:o.a;ev.push({date:o.date,label:o.n,amount:-amt,kind:"bill",outstanding:true,originalDate:o.originalDate,skipId:o.skipId,skipped})});
 // Legacy beautyByMonth records are preserved in saved data but no longer projected; Eyebrows $100 and Nails $215 are authoritative dated bills on day 8.
 let support=state.budget.supportByMonth?.[uid]||{};[["carInsurance","Jeremiah — Car Insurance"],["phone","Jeremiah — Phone"]].forEach(([key,label])=>{let x=support[key];if(x&&x.received&&!x.absorbedIntoAnchor&&validDateKeyRaw(x.date)&&Number(x.amount)>0){let d=new Date(x.date+"T12:00:00");if(d.getFullYear()===y&&d.getMonth()===m)ev.push({date:d,label,amount:Math.max(0,Number(x.amount)),kind:"income",support:key,received:true})}});
 rows.forEach((x,i)=>{let amt=x.a,paid=!!state.checks[autopayKey(x)];if(x.n==="Rent")amt=rentAmountForDue(x.date);if(em.on&&x.n!=="Rent"&&isSkipped(em,x))amt=0;ev.push({date:x.date,label:x.display||x.n,name:x.n,amount:paid?0:-amt,kind:"bill",original:amt,baseA:x.baseA??x.a,autopayId:autopayOverrideKey(x),skipped:amt===0,paid,monthOnly:x.monthOnly||null})});
 return ev.sort((a,b)=>a.date-b.date||({income:0,spend:1,save:2,bill:3}[a.kind]-{income:0,spend:1,save:2,bill:3}[b.kind]))
}
function localDateKey(dt=new Date()){let y=dt.getFullYear(),m=String(dt.getMonth()+1).padStart(2,"0"),d=String(dt.getDate()).padStart(2,"0");return `${y}-${m}-${d}`}
function autopayKey(x){return `autopay|${localDateKey(x.date)}|${encodeURIComponent(x.n)}|${Number(x.baseA??x.a).toFixed(2)}`}
function monthId(y,m){return `${y}-${String(m+1).padStart(2,"0")}`}
function monthExtra(y,m){let id=`${y}-${m}`;return (state.budget.buys[id]||[]).reduce((a,x)=>a+Math.max(0,Number(x.price||0)),0)}
function projectionOpening(y,m){
 let anchor=new Date((state.budget.balanceAsOf||"2026-09-27")+"T12:00:00"),target=new Date(y,m,1,12),bal=Number(state.budget.balance||0);
 if(target<new Date(anchor.getFullYear(),anchor.getMonth(),1,12))return null;
 let cy=anchor.getFullYear(),cm=anchor.getMonth();
 while(cy<y||cm<m){
   let sameAnchorMonth=cy===anchor.getFullYear()&&cm===anchor.getMonth();
   let ev=budgetEvents(cy,cm).filter(x=>!sameAnchorMonth||x.date>anchor);
   ev.forEach(x=>bal+=x.amount);bal-=monthExtra(cy,cm);
   cm++;if(cm>11){cm=0;cy++}
 }
 return bal
}
function cashflow(y,m){
 let anchor=new Date((state.budget.balanceAsOf||"2026-09-27")+"T12:00:00"),bal=projectionOpening(y,m);if(bal===null)return[];
 let ev=budgetEvents(y,m);
 if(y===anchor.getFullYear()&&m===anchor.getMonth())ev=ev.filter(x=>x.date>anchor);
 return ev.map(x=>{bal+=x.amount;return {...x,balance:bal}})
}
function currentRentStatus(){
 let cycle=activeRentCycle(),due=cycle.due,deadline=cycle.deadline,anchor=new Date((state.budget.balanceAsOf||"2026-09-28")+"T12:00:00"),bal=Number(state.budget.balance||0),events=[];
 let y=anchor.getFullYear(),m=anchor.getMonth(),endY=deadline.getFullYear(),endM=deadline.getMonth();
 while(y<endY||(y===endY&&m<=endM)){
   let monthEvents=budgetEvents(y,m).filter(x=>x.date>anchor&&x.date<=deadline);
   monthEvents=monthEvents.filter(x=>!(/ Rent$/.test(x.label)&&x.date.getFullYear()===due.getFullYear()&&x.date.getMonth()===due.getMonth()&&x.date.getDate()===1));
   events.push(...monthEvents);m++;if(m>11){m=0;y++}
 }
 events.sort((a,b)=>a.date-b.date||({income:0,spend:1,save:2,bill:3}[a.kind]-{income:0,spend:1,save:2,bill:3}[b.kind]));
 let em=state.budget.emergency[cycle.id]||{on:false,skip:{}},target=rentAmountForDue(cycle.due);
 // The active rent month's Emergency Mode owns sacrifice choices for the whole live-balance→second-Tuesday window, including older unpaid fixed obligations.
 if(em.on)events=events.map(e=>{let k=e.skipId||`${e.label}|${e.date.getDate()}`;return e.kind==="bill"&&(em.skip?.[k]||em.skip?.[e.label+"|"+e.date.getDate()]||em.skip?.[e.label])?{...e,amount:0,skipped:true}:e});
 let earliest=null;for(let e of events){bal+=e.amount;if(!earliest&&bal>=target)earliest={date:e.date,balance:bal,target};}
 let short=Math.max(0,target-bal);return {balance:bal,short,earliest,due,deadline,target,cycle,emergencyOn:!!em.on};
}

function rentSnapshotForMonth(y,m){
 let deadline=secondTuesdayDate(y,m),anchor=new Date((state.budget.balanceAsOf||"2026-09-28")+"T12:00:00"),bal=Number(state.budget.balance||0);
 if(deadline<anchor)return {available:null,target:rentAmountForDue(new Date(y,m,1,12)),short:null,deadline};
 let cy=anchor.getFullYear(),cm=anchor.getMonth(),events=[];
 while(cy<y||(cy===y&&cm<=m)){
  budgetEvents(cy,cm).forEach(e=>{if(e.date>anchor&&e.date<=deadline){let isThisRent=/ Rent$/.test(e.label)&&e.date.getFullYear()===y&&e.date.getMonth()===m&&e.date.getDate()===1;if(!isThisRent)events.push(e)}});
  cm++;if(cm>11){cm=0;cy++}
 }
 events.sort((a,b)=>a.date-b.date||({income:0,spend:1,save:2,bill:3}[a.kind]-{income:0,spend:1,save:2,bill:3}[b.kind]));
 events.forEach(e=>bal+=e.amount);
 let target=rentAmountForDue(new Date(y,m,1,12));
 return {available:bal,target,short:Math.max(0,target-bal),deadline};
}
function budgetEmbeddedMonthly(y,m){
 let id=`${y}-${m}`,beauty=state.budget.beautyByMonth?.[id]||{},support=state.budget.supportByMonth?.[id]||{};
 let beautyRow=(kind,label,defaultAmount)=>{let x=beauty[kind]||{amount:defaultAmount,date:"",done:false},done=!!x.done;return `<div class="budget-entry ${done?"beauty-done":""}"><label><small>${label.toUpperCase()}</small><input id="beauty-${kind}-amount" aria-label="${label} amount" type="number" min="0" step=".01" value="${Number(x.amount||defaultAmount)}"></label><label><small>DATE</small><input id="beauty-${kind}-date" aria-label="${label} date" type="date" value="${esc(x.date||"")}"></label><div class="entry-actions"><label class="checkrow"><input type="checkbox" data-beauty-done="${id}|${kind}" ${done?"checked":""}><span>DONE</span></label><button class="btn" data-save-beauty="${id}|${kind}">SAVE</button></div></div>`};
 let supportRow=(kind,label)=>{let x=support[kind]||{amount:100,date:"",received:false},received=!!x.received;return `<div class="budget-entry ${received?"beauty-done":""}"><div class="support-copy"><b>${label.toUpperCase()}</b><small>EXPECTED +$100 • ONLY COUNTS AFTER RECEIVED</small></div><label><small>DATE RECEIVED</small><input id="support-${kind}-date" aria-label="${label} date received" type="date" value="${esc(x.date||"")}"></label><div class="entry-actions"><label class="checkrow"><input type="checkbox" data-support-received="${id}|${kind}" ${received?"checked":""}><span>RECEIVED</span></label><button class="btn" data-save-support="${id}|${kind}">SAVE</button>${x.absorbedIntoAnchor?'<small class="paid-tag">ALREADY IN LIVE BALANCE • NOT ADDED AGAIN</small>':''}</div><input id="support-${kind}-amount" type="hidden" value="${Number(x.amount||100)}"></div>`};
 return `<section class="card"><h2>JEREMIAH'S BILL SUPPORT</h2><p class="muted">KEPT BESIDE THE BUDGET IT AFFECTS. PHONE + INSURANCE SUPPORT ONLY ENTER CASH FLOW AFTER YOU MARK THE MONEY RECEIVED.</p>${supportRow("carInsurance","Car Insurance +$100")}${supportRow("phone","Phone +$100")}</section>`;
}

function budget(){
 let b=state.budget,bal=Number(b.balance||0);
 const liveStrip=()=>`<section class="budget-live-strip"><div><small>LIVE BALANCE</small><b>${money(Number(state.budget.balance||0))}</b></div><span>UPDATED THROUGH<br>${esc(state.budget.balanceAsOf||"—")}</span></section>`;
 if(state.sub&&state.sub.startsWith("week:")){let [y,m,w]=state.sub.split(":").slice(1).map(Number);return liveStrip()+budgetWeek(y,m,w)}
 if(state.sub&&state.sub.startsWith("year:"))return liveStrip()+budgetYear(+state.sub.split(":")[1]);
 if(state.sub&&state.sub.startsWith("month:")){let [y,m]=state.sub.split(":").slice(1).map(Number);return liveStrip()+budgetMonth(y,m)}
 if(state.sub&&/^(buy|unplanned|emergency|weeks):/.test(state.sub)){let [kind,y,m,parent]=state.sub.split(":");return liveStrip()+budgetTool(kind,+y,+m,parent||"budget")}
 let now=new Date(),y=now.getFullYear(),m=now.getMonth(),cycle=activeRentCycle(),rs=currentRentStatus();
 return hero("Budget","Simple money hub")+`
 <section class="card soft"><div class="muted">LIVE BALANCE</div><div class="metric money">${money(bal)}</div><div class="row"><input id="liveBalance" aria-label="Live balance" type="number" step=".01" value="${bal}"><button class="btn primary" data-save-balance>UPDATE</button></div><p class="muted">AS OF ${esc(b.balanceAsOf||"—")}</p></section>
 <section class="comment-widget budget-commentary"><p>${esc(cycle.rentMonth.toLocaleString("en",{month:"long"}))} RENT • ${money(rs.target)} TARGET • ${rs.short>0?money(rs.short)+" SHORT":"COVERED IN CURRENT PROJECTION"}</p></section>
 <div class="budget-home-grid">
  <button class="tile" data-budget-tool="weeks|${y}|${m}|budget"><b>WEEK BY WEEK</b><span>CHECK INCOME + AUTOPAYS • SEE UNPLANNED SPENDING</span></button>
  <button class="tile" data-budget-year="${y}"><b>MONTHS</b><span>OPEN ANY MONTH</span></button>
  <button class="tile" data-budget-tool="buy|${y}|${m}|budget"><b>THINGS TO BUY</b><span>PLANNED PURCHASES</span></button>
  <button class="tile" data-budget-tool="unplanned|${y}|${m}|budget"><b>UNPLANNED SPENDING</b><span>UNEXPECTED PURCHASES</span></button>
  <button class="tile" data-budget-tool="emergency|${cycle.due.getFullYear()}|${cycle.due.getMonth()}|budget"><b>EMERGENCY MODE</b><span>OPTIONAL BILL-SACRIFICE PLAN</span></button>
 </div>
 
 ${allAutopaysPanel(y,m)}`;
}
function budgetTool(kind,y,m,parent="budget"){
 let id=`${y}-${m}`,monthName=new Date(y,m).toLocaleString("en",{month:"long",year:"numeric"}),backMarkup=parent==="month"?`<button class="btn back" data-budget-return="month:${y}:${m}">‹ ${esc(monthName)}</button>`:back("Budget"),em=state.budget.emergency[id]||{on:false,skip:{}},rows=monthRows(y,m),deadlineDate=secondTuesdayDate(y,m),secondTuesday=deadlineDate.getDate(),anchor=new Date((state.budget.balanceAsOf||"2026-09-28")+"T12:00:00"),deadline=new Date(y,m,secondTuesday,23,59,59),eligible=rows.filter(x=>x.n!=="Rent"&&x.date>anchor&&x.date<=deadline&&!state.checks[autopayKey(x)]);
 // Emergency sacrifice window is the live-balance anchor through this rent month's second Tuesday, including any older unpaid fixed obligations that still exist after the current live-balance anchor.
 outstandingRowsForProjection().forEach(o=>{if(o.date>deadline)return;eligible.push(o)});
 // Remove duplicates while preserving distinct occurrences such as the two Ring charges.
 let seenEligible=new Set();eligible=eligible.filter(x=>{let k=skipKey(x);if(seenEligible.has(k))return false;seenEligible.add(k);return true}).sort((a,b)=>a.date-b.date);
 if(kind==="buy"){let buys=state.budget.buys[id]||[];return hero("Things to Buy",monthName)+backMarkup+`<section class="card">${buys.map((x,i)=>`<div class="checkrow"><span style="flex:1">${esc(x.item)}</span><b>${money(x.price)}</b><button class="btn" data-del-buy="${id}|${i}">Remove</button></div>`).join("")||'<p class="muted">No planned purchases yet.</p>'}<div class="formgrid"><input id="buyItem" aria-label="Purchase item" placeholder="Item"><input id="buyPrice" aria-label="Purchase price" type="number" min="0" step=".01" placeholder="Price"></div><button class="btn primary" data-add-buy="${id}">Add Item</button><p class="muted">These purchases affect the same Budget projection; this is not the Wish List.</p></section>`}
 if(kind==="unplanned"){let arr=state.budget.unplannedByMonth[id]||[],total=arr.reduce((a,x)=>a+Math.max(0,Number(x.amount)||0),0);return hero("Unplanned Spending",monthName)+backMarkup+`<section class="card soft"><div class="budget-glance"><div class="mini-stat"><small>UNPLANNED SPENT</small><b>${money(total)}</b></div><div class="mini-stat"><small>ENTRIES</small><b>${arr.length}</b></div></div><p class="muted">Every dollar entered here is money that was not in the plan and reduces the cash available for the rest of the month. Planned beauty, bills, and Jeremiah's regular contribution/support belong in the main monthly budget instead.</p></section><section class="card"><h2>UNPLANNED PURCHASES</h2>${arr.map((u,i)=>`<div class="checkrow"><span style="flex:1"><b>${esc(u.item)}</b><small> • day ${esc(u.day)}</small></span><b>${money(u.amount)}</b><button class="btn" data-del-unplanned="${id}|${i}">REMOVE</button></div>`).join("")||'<p class="muted">Nothing unexpected has been logged this month.</p>'}<div class="formgrid"><input id="unplannedItem" placeholder="WHAT WAS IT?"><input id="unplannedAmount" type="number" min="0" step=".01" placeholder="AMOUNT"><input id="unplannedDay" type="number" min="1" max="31" placeholder="DAY"></div><button class="btn primary" data-add-unplanned="${id}">ADD UNPLANNED SPENDING</button></section>`}
 if(kind==="emergency"){let saved=eligible.filter(x=>isSkipped(em,x)).reduce((a,x)=>a+x.a,0),snap=rentSnapshotForMonth(y,m);return hero("Emergency Mode",monthName)+backMarkup+`<section class="card"><p>Normal rent: <b>${money(NORMAL_RENT)}</b> • Emergency/late rent: <b>${money(EMERGENCY_RENT)}</b> • Latest: <b>${deadlineDate.toLocaleDateString()}</b> (second Tuesday)</p>${snap.available===null?"":`<div class="budget-glance"><div class="mini-stat"><small>AVAILABLE BY DEADLINE</small><b>${money(snap.available)}</b></div><div class="mini-stat"><small>RENT TARGET</small><b>${money(snap.target)}</b></div><div class="mini-stat"><small>${snap.short>0?"STILL SHORT":"STATUS"}</small><b>${snap.short>0?money(snap.short):"COVERED"}</b></div><div class="mini-stat"><small>FREED BY SACRIFICES</small><b>${money(saved)}</b></div></div>`}<label class="checkrow"><input type="checkbox" data-emergency="${id}" ${em.on?'checked':''}><span>Turn Emergency Mode on for this rent cycle</span></label>${em.on?`<div class="metric money">${money(saved)}</div><p class="muted">Emergency Total Freed For Rent</p><p class="muted">Only currently UNPAID eligible bills after the live-balance anchor and through the second Tuesday appear here. Older carried bills stay eligible until paid. Checking one sacrifices/postpones that occurrence, making its projected outflow $0 and raising available rent money by exactly the same amount.</p>${eligible.map(x=>{let k=skipKey(x),payload=x.skipId?`${id}|${esc(k)}`:`${id}|${esc(x.n)}|${x.d}`;return `<label class="checkrow"><input type="checkbox" data-skipbill="${payload}" ${isSkipped(em,x)?'checked':''}><span>${x.date.toLocaleDateString()} • ${esc(x.n)} • ${money(typeof budgetOccurrenceAmountV125==="function"?budgetOccurrenceAmountV125(x):x.a)}</span></label>`}).join("")||'<p class="muted">No unpaid autopays are eligible in this window.</p>'}`:'<p class="muted">Turn it on to choose unpaid bills to sacrifice through the second Tuesday.</p>'}</section>`}
 let weeks=paydays(y,m).map((day,i)=>{let ws=new Date(y,m,day,12),we=new Date(ws);we.setDate(ws.getDate()+6);return {i:i+1,start:localDateKey(ws),end:localDateKey(we)}});return hero("Week-by-Week",monthName)+backMarkup+`<section class="card"><h2>PAYCHECK WEEKS</h2><p class="muted">BUDGET WEEKS RUN WEDNESDAY → TUESDAY. EACH WEEK RUNS WEDNESDAY → TUESDAY. THE WEDNESDAY PAYCHECK STARTS THE WEEK; AUTOPAYS THROUGH THE FOLLOWING TUESDAY ARE HANDLED WITH THAT PAYCHECK.</p><div class="week-button-grid">${weeks.map(w=>`<button class="tile budget-week-tile" data-week="${y}|${m}|${w.i}"><b>WEEK ${w.i}</b><span>${w.start.slice(5)} → ${w.end.slice(5)}</span></button>`).join("")}</div></section>`
}
function budgetYear(y){return hero(String(y),"Pick a month")+back("Budget")+`<div class="grid">${Array.from({length:12},(_,m)=>`<button class="tile" data-budget-month="${y}|${m}"><b>${new Date(y,m).toLocaleString("en",{month:"long"})}</b></button>`).join("")}</div>`}
function budgetMonth(y,m){
 let opening=projectionOpening(y,m),flow=cashflow(y,m),end=opening===null?null:(flow.at(-1)?.balance??opening)-monthExtra(y,m);
 let pd=paydays(y,m),weeks=pd.map((day,i)=>{let ws=new Date(y,m,day,12),we=new Date(ws);we.setDate(ws.getDate()+6);return {i:i+1,start:localDateKey(ws),end:localDateKey(we)}});
 return hero(new Date(y,m).toLocaleString("en",{month:"long",year:"numeric"}),"Choose a week or budget tool")+back(String(y))+`
 <section class="card soft"><div class="budget-glance"><div class="mini-stat"><small>START</small><b>${opening===null?"—":money(opening)}</b></div><div class="mini-stat"><small>PROJECTED END</small><b>${end===null?"—":money(end)}</b></div></div></section>
 <section class="card"><h2>WEEK BY WEEK</h2><div class="week-button-grid">${weeks.map(w=>`<button class="tile budget-week-tile" data-week="${y}|${m}|${w.i}"><b>WEEK ${w.i}</b><span>${w.start.slice(5)} → ${w.end.slice(5)}</span></button>`).join("")}</div></section>
 <div class="budget-home-grid"><button class="tile" data-budget-tool="buy|${y}|${m}|month"><b>THINGS TO BUY</b></button><button class="tile" data-budget-tool="unplanned|${y}|${m}|month"><b>UNPLANNED SPENDING</b></button><button class="tile" data-budget-tool="emergency|${y}|${m}|month"><b>EMERGENCY MODE</b></button></div>`;
}
function budgetWeek(y,m,w){
 let pd=paydays(y,m),payday=pd[w-1];if(!payday)return hero(`Week ${w}`,"No paycheck in this month")+back(new Date(y,m).toLocaleString("en",{month:"long"}));let start=new Date(y,m,payday,12);let actionEnd=new Date(start);actionEnd.setDate(start.getDate()+1);let coverageEnd=new Date(start);coverageEnd.setDate(start.getDate()+6);let end=coverageEnd;
 let startKey=localDateKey(start),endKey=localDateKey(coverageEnd),rows=[];
 for(let yy=start.getFullYear(),mm=start.getMonth(),guard=0;guard<2;guard++){budgetEvents(yy,mm).forEach(e=>{let k=localDateKey(e.date);if(k>=startKey&&k<=endKey)rows.push(e)});if(yy===end.getFullYear()&&mm===end.getMonth())break;mm++;if(mm>11){mm=0;yy++}}
 rows.sort((a,b)=>a.date-b.date);
 rows=rows.map(x=>({...x,rollover:x.date.getMonth()!==m||x.date.getFullYear()!==y}));
 let bills=rows.filter(x=>x.kind==="bill"), unplanned=rows.filter(x=>x.unplanned||/^Unplanned:/.test(x.label));
 let incomeSources=[["job1","Job #1",JOB_INCOME.job1],["job2","Job #2",JOB_INCOME.job2],["jeremiah","Jeremiah",JOB_INCOME.jeremiah]].map(([source,label,amount])=>({source,label,amount,date:new Date(start)}));
 let checkedIncome=incomeSources.filter(x=>state.checks[incomeSourceKey(x.date,x.source)]),checkedBills=bills.filter(x=>x.paid||state.checks[x.outstanding?x.skipId:autopayKey({n:x.name||(x.label||"").replace(/^Outstanding: /,""),a:Math.abs(x.original||x.amount||0),baseA:x.baseA,date:x.date})]);
 let incomeItem=x=>{let key=incomeSourceKey(x.date,x.source),checked=!!state.checks[key],ev=state.budget.paymentEvents?.[key],amt=checked&&Number.isFinite(Number(ev?.amount))?Math.round(Number(ev.amount)*100)/100:x.amount;return `<label class="checkrow budget-week-row"><input type="checkbox" data-budget-occurrence="income|${esc(key)}|${amt}" ${checked?"checked":""}><span style="flex:1"><b>${x.date.toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})} • ${esc(x.label)}</b><small class="income-source-note">SEPARATE WEEKLY INCOME</small></span><b class="autopay-amount">+${money(amt)}</b></label>`};
 let billItem=x=>{let key=x.outstanding?x.skipId:autopayKey({n:x.name||(x.label||"").replace(/^Outstanding: /,""),a:Math.abs(x.original||x.amount||0),baseA:x.baseA,date:x.date}),checked=!!state.checks[key],ev=state.budget.paymentEvents?.[key],scheduled=Math.abs(x.original||x.amount||0),amt=checked&&Number.isFinite(Number(ev?.amount))?Math.round(Number(ev.amount)*100)/100:scheduled,edit=x.outstanding?"":`<button class="tinybtn autopay-edit" data-edit-autopay="${encodeURIComponent(localDateKey(x.date))}|${encodeURIComponent(x.name||(x.label||""))}|${encodeURIComponent(String(x.baseA??scheduled))}" aria-label="Edit ${esc(x.name||x.label)} amount">EDIT</button>`;return `<label class="checkrow budget-week-row"><input type="checkbox" data-budget-occurrence="bill|${esc(key)}|${amt}" ${checked?"checked":""}><span style="flex:1"><b>${x.date.toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})} • ${esc(x.label)}</b>${x.rollover?'<small class="rollover-note">NEXT-MONTH AUTOPAY • ACCOUNT FOR IT WITH THIS PAYCHECK</small>':""}</span><b class="autopay-amount">−${money(amt)}</b>${edit}</label>`};
 
 return hero(`Week ${w}`,`${start.toLocaleDateString()} → ${coverageEnd.toLocaleDateString()} • PAYCHECK WEEK`)+back(new Date(y,m).toLocaleString("en",{month:"long"}))+`
 <section class="card soft"><p class="muted" style="margin:0">BUDGET WEEK: WEDNESDAY → TUESDAY. CHECK EACH INCOME SOURCE ONLY WHEN IT ACTUALLY HITS. AUTOPAYS KEEP THEIR REAL DUE DATES; CHECKING THEM HERE MARKS THAT SAME OCCURRENCE PAID EVERYWHERE.</p></section>
 <section class="card" style="border:2px solid var(--accent);background:var(--soft)"><b>BUDGET WEEK BUILD • THREE SOURCES ONLY</b></section><section class="card budget-income-sources"><h2>THIS WEEK’S 3 SEPARATE INCOME CHECKS</h2><p class="muted">CHECK EACH SOURCE ONLY WHEN THAT PAYMENT ACTUALLY ARRIVES. THERE IS NO COMBINED INCOME CHECK OR COMBINED INCOME CARD.</p>${incomeSources.map(incomeItem).join("")||'<p class="muted">No income scheduled this week.</p>'}</section>
 <section class="card"><h2>AUTOPAYS</h2>${bills.map(billItem).join("")||'<p class="muted">No autopays scheduled this week.</p>'}</section>
 <section class="card"><h2>UNPLANNED SPENDING</h2>${unplanned.map(x=>`<div class="checkrow budget-week-row"><span style="flex:1">${x.date.toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"})} • ${esc(x.label.replace(/^Unplanned: /,""))}</span><b>−${money(Math.abs(x.amount))}</b></div>`).join("")||'<p class="muted">No unplanned spending logged this week.</p>'}</section>
 <section class="card"><h2>EVERYTHING CHECKED OFF</h2><p class="muted">NEXT-MONTH AUTOPAYS CHECKED HERE ARE THE SAME REAL AUTOPAYS — THEY WILL ALREADY SHOW AS TAKEN CARE OF IN THAT MONTH.</p><div class="checked-summary"><b>INCOME</b>${checkedIncome.map(x=>`<p>✓ ${x.date.toLocaleDateString()} • ${esc(x.label)} • ${money(x.amount)}</p>`).join("")||'<p class="muted">Nothing checked yet.</p>'}<b>AUTOPAYS</b>${checkedBills.map(x=>`<p>✓ ${x.date.toLocaleDateString()} • ${esc(x.label)}</p>`).join("")||'<p class="muted">Nothing checked yet.</p>'}<b>UNPLANNED SPENDING</b>${unplanned.map(x=>`<p>${x.date.toLocaleDateString()} • ${esc(x.label.replace(/^Unplanned: /,""))} • ${money(Math.abs(x.amount))}</p>`).join("")||'<p class="muted">None.</p>'}</div></section>`;
}
function history(){
 if(state.sub?.startsWith("hist:"))return historyDrill();
 let cats=[["complete","Complete"],["bible","Bible"],["goals","Goals"],["school","School"],["body","Body"],["food","Food"],["gym","Gym + Run"]];
 return hero("History","Choose a history category")+`<section class="card"><div class="tiles">${cats.map(x=>`<button class="tile" data-hist="${x[0]}"><b>${x[1]}</b><span>Year → Month → Week → Day</span></button>`).join("")}</div></section>`;
}
function validDateKey(x){if(!/^\d{4}-\d{2}-\d{2}$/.test(String(x)))return false;let [y,m,d]=String(x).split("-").map(Number),dt=new Date(y,m-1,d,12);return dt.getFullYear()===y&&dt.getMonth()===m-1&&dt.getDate()===d}
function hasWeight(d){let v=state.weight?.[d];return v!==""&&v!=null&&Number.isFinite(Number(v))}
function hasMeasure(d){let m=state.measure?.[d];return !!m&&Object.values(m).some(v=>v!==""&&v!=null&&Number.isFinite(Number(v)))}
function hasStudy(d){return (typeof state.studyNotes?.[d]==="string"&&state.studyNotes[d].trim()!=="")||(typeof state.studyResources?.[d]==="string"&&state.studyResources[d].trim()!=="")}
function hasBible(d){return Array.isArray(state.bible?.[d]?.entries)&&state.bible[d].entries.some(v=>String(v||"").trim()!=="")}
function hasMacros(d){let a=state.actualFood?.[d];return !!a&&Object.values(a).some(v=>v!==""&&v!=null&&Number.isFinite(Number(v)))}
function hasRun(d){let r=state.run?.[d];return !!r&&[r.incline,r.speed,r.duration].some(v=>Number.isFinite(Number(v))&&Number(v)>0)}
function hasGym(d){let g=state.gymLog?.[d];return !!g&&Object.values(g).some(z=>z&&typeof z==="object"&&(z.done||Object.entries(z).some(([k,v])=>/^[wr]\d+$/.test(k)&&String(v??"").trim()!=="")))}
function histDates(type){
 let set=new Set();
 if(type==="bible")Object.keys(state.bible).forEach(x=>{if(hasBible(x))set.add(x)});
 if(type==="body"){Object.keys(state.weight).forEach(x=>{if(hasWeight(x))set.add(x)});Object.keys(state.measure||{}).forEach(x=>{if(hasMeasure(x))set.add(x)})}
 if(type==="food"){(state.foodHistory||[]).forEach(x=>set.add((x.date||"").slice(0,10)));Object.keys(state.actualFood||{}).forEach(x=>{if(hasMacros(x))set.add(x)})}
 if(type==="gym"){Object.keys(state.gymLog||{}).forEach(x=>{if(hasGym(x))set.add(x)});Object.keys(state.run||{}).forEach(x=>{if(hasRun(x)){let m=x.match(/\d{4}-\d{2}-\d{2}/);if(m)set.add(m[0])}})}
 if(type==="school")[...new Set([...Object.keys(state.studyNotes||{}),...Object.keys(state.studyResources||{})])].forEach(x=>{if(hasStudy(x)&&/^\d{4}-/.test(x))set.add(x)});
 if(type==="goals"){Object.keys(state.goalsByDate||{}).forEach(x=>{if(Array.isArray(state.goalsByDate[x])&&state.goalsByDate[x].length)set.add(x)});Object.keys(state.goalHistory||{}).forEach(x=>{if(Object.keys(state.goalHistory[x]||{}).length)set.add(x)})}
 if(type==="complete"){let add=x=>{let m=String(x).match(/\d{4}-\d{2}-\d{2}/);if(m)set.add(m[0])};Object.keys(state.weight).filter(hasWeight).forEach(add);Object.keys(state.measure||{}).filter(hasMeasure).forEach(add);Object.keys(state.bible).filter(hasBible).forEach(add);[...new Set([...Object.keys(state.studyNotes||{}),...Object.keys(state.studyResources||{})])].filter(hasStudy).forEach(add);(state.foodHistory||[]).map(x=>x.date).forEach(add);Object.keys(state.actualFood||{}).filter(hasMacros).forEach(add);Object.keys(state.gymLog||{}).filter(hasGym).forEach(add);Object.keys(state.run||{}).filter(hasRun).forEach(add);Object.keys(state.goalsByDate||{}).filter(x=>Array.isArray(state.goalsByDate[x])&&state.goalsByDate[x].length).forEach(add);Object.keys(state.goalHistory||{}).filter(x=>Object.values(state.goalHistory[x]||{}).some(v=>v&&v.done)).forEach(add);Object.keys(state.water||{}).filter(x=>state.water[x]).forEach(add);Object.keys(state.checks||{}).filter(x=>state.checks[x]).forEach(add);Object.keys(state.routineStatus||{}).filter(x=>Object.values(state.routineStatus[x]||{}).some(Boolean)).forEach(add);Object.keys(state.routineSnapshots||{}).filter(x=>state.routineSnapshots[x]?.tasks?.some(t=>t.done||t.customFixed||t.errandMeta||(t.subtasks||[]).some(q=>q.done))).forEach(add);Object.keys(state.routineStarts||{}).filter(x=>state.routineStarts[x]!==""&&state.routineStarts[x]!=null&&Number.isFinite(Number(state.routineStarts[x]))).forEach(add)}
 return [...set].filter(validDateKey).sort()
}
function histWeekKey(d){let dt=new Date(d+"T12:00:00"),mon=new Date(dt);mon.setDate(dt.getDate()-((dt.getDay()+6)%7));return localDateKey(mon)}
function historyDrill(){
 let parts=state.sub.split(":"),type=parts[1],level=parts[2]||"year",val=parts.slice(3).join(":"),dates=histDates(type),title=(type==="gym"?"Gym + Run":type[0].toUpperCase()+type.slice(1))+" History";
 if(level==="year"){let ys=[...new Set(dates.map(x=>x.slice(0,4)))].sort().reverse();return hero(title,"Pick a year")+back("History")+`<section class="card">${ys.map(y=>`<button class="tile" data-histnav="${type}|month|${y}"><b>${y}</b></button>`).join("")||"<p class='muted'>No dated entries yet.</p>"}</section>`}
 if(level==="month"){let y=val,ms=[...new Set(dates.filter(x=>x.startsWith(y+"-")).map(x=>x.slice(0,7)))].sort().reverse();return hero(title,y)+`<button class="back" data-histnav="${type}|year">← Years</button><section class="card">${ms.map(m=>`<button class="tile" data-histnav="${type}|week|${m}"><b>${new Date(m+"-01T12:00:00").toLocaleString("en",{month:"long",year:"numeric"})}</b></button>`).join("")}</section>`}
 if(level==="week"){let m=val,ds=dates.filter(x=>x.startsWith(m)),groups={};ds.forEach(d=>{let w=histWeekKey(d);(groups[w]??=[]).push(d)});return hero(title,new Date(m+"-01T12:00:00").toLocaleString("en",{month:"long",year:"numeric"}))+`<button class="back" data-histnav="${type}|month|${m.slice(0,4)}">← Months</button><section class="card"><h2>Pick a Monday–Sunday Week</h2>${Object.keys(groups).sort().reverse().map(w=>`<button class="tile" data-histnav="${type}|days|${m}|${w}"><b>Week of ${esc(w)}</b><span>${groups[w].length} saved day(s)</span></button>`).join("")}</section>`}
 if(level==="days"){let [m,w]=val.split("|"),ds=dates.filter(d=>d.startsWith(m)&&histWeekKey(d)===w);return hero(title,`Week of ${w}`)+`<button class="back" data-histnav="${type}|week|${m}">← Weeks</button><section class="card"><h2>Pick a Day</h2>${ds.map(d=>`<button class="tile" data-histnav="${type}|day|${d}"><b>${new Date(d+"T12:00:00").toLocaleDateString("en",{weekday:"long",month:"long",day:"numeric",year:"numeric"})}</b></button>`).join("")}</section>`}
 if(level==="day"){let d=val,m=d.slice(0,7),w=histWeekKey(d);return hero(title,new Date(d+"T12:00:00").toLocaleDateString("en",{weekday:"long",month:"long",day:"numeric",year:"numeric"}))+`<button class="back" data-histnav="${type}|days|${m}|${w}">← Days</button><section class="card">${historyDay(type,d)}</section>`}
}
function historyDay(type,d){
 if(type==="bible")return `<p>${esc((state.bible[d]?.entries||[]).filter(Boolean).join(" • ")||"Saved faith day")}</p>`;
 if(type==="body"){let m=state.measure[d]||{};return `<p>Weight: ${esc(state.weight[d]??"—")}${m.glutes!==""&&m.glutes!=null?` • Glutes: ${esc(m.glutes)}`:""}${m.waist!==""&&m.waist!=null?` • Waist: ${esc(m.waist)}`:""}${m.arms!==""&&m.arms!=null?` • Arms: ${esc(m.arms)}`:""}</p>`}
 if(type==="food"){let ev=(state.foodHistory||[]).filter(x=>(x.date||"").slice(0,10)===d).map(x=>esc((x.type||"Food")+" • "+(x.recipe||x.container||"activity"))),a=state.actualFood[d]||{},mac=Object.keys(a).some(k=>a[k]!==""&&a[k]!=null)?`Actual macros: ${esc(a.calories??"—")} kcal • ${esc(a.protein??"—")}g protein • ${esc(a.carbs??"—")}g carbs • ${esc(a.fat??"—")}g fat • ${esc(a.fiber??"—")}g fiber`:"";return `<p>${[...ev,mac].filter(Boolean).join("<br>")||"Food activity"}</p>`}
 if(type==="gym"){let g=Object.keys(state.gymLog[d]||{}),r=state.run[d];return `<p>${g.length?g.map(x=>esc(x)).join(" • "):""}${r?`<br>Run: incline ${esc(r.incline??"—")} • speed ${esc(r.speed??"—")} • ${esc(r.duration??"—")} min`:""}</p>`}
 if(type==="school"){let r=state.studyResources[d]||"",n=state.studyNotes[d]||"";return `<p>${r?`<b>Resource:</b> ${esc(r)}<br>`:""}${n?`<b>Notes:</b> ${esc(n)}`:"Study saved"}</p>`;}
 if(type==="goals"){let list=state.goalsByDate[d]||[],hist=state.goalHistory[d]||{};return `<p>${list.length?list.map((g,i)=>`${hist[i]?.done?"✓":"○"} ${esc(g.text)}${g.important?" • reminder":""}`).join("<br>"):"No goal activity saved"}</p>`}
 if(type==="complete"){let bits=[];if(state.routineStarts[d]!==""&&state.routineStarts[d]!=null&&Number.isFinite(Number(state.routineStarts[d])))bits.push("Actual Wake/Start "+fmt(Number(state.routineStarts[d])));if(state.weight[d]!==""&&state.weight[d]!=null)bits.push("Weight "+state.weight[d]+" lb");let mm=state.measure[d]||{},mv=["glutes","waist","arms"].filter(k=>mm[k]!==""&&mm[k]!=null).map(k=>k[0].toUpperCase()+k.slice(1)+" "+mm[k]);if(mv.length)bits.push("Measurements: "+mv.join(", "));if(hasStudy(d)){let sr=state.studyResources[d],sn=state.studyNotes[d];bits.push("Study"+(sr?" • Resource: "+sr:"")+(sn?" • Notes: "+sn:""))}if(hasBible(d))bits.push("Faith: "+state.bible[d].entries.filter(Boolean).join(" • "));let gg=state.gymLog[d]||{};if(hasGym(d))bits.push("Gym: "+Object.keys(gg).filter(n=>{let z=gg[n];return z?.done||Object.entries(z||{}).some(([k,v])=>/^[wr]\d+$/.test(k)&&String(v??"").trim()!=="")}).join(", "));if(hasRun(d)){let r=state.run[d];bits.push(`Run: incline ${r.incline} • speed ${r.speed} • ${r.duration} min`)}let foods=(state.foodHistory||[]).filter(x=>(x.date||"").slice(0,10)===d);if(foods.length)bits.push("Food: "+foods.map(x=>(x.type||"Food")+(x.recipe?" "+x.recipe:x.container?" "+x.container:"")).join(", "));if(hasMacros(d)){let a=state.actualFood[d];bits.push(`Macros: ${a.calories??"—"} kcal • ${a.protein??"—"}g protein • ${a.carbs??"—"}g carbs • ${a.fat??"—"}g fat • ${a.fiber??"—"}g fiber`)}let gl=state.goalsByDate[d]||[],gh=state.goalHistory[d]||{};if(gl.length)bits.push("Goals: "+gl.map((g,i)=>(gh[i]?.done?"✓ ":"○ ")+g.text).join(", "));let water=[1,2,3,4,5].filter(i=>state.water[d+"|"+i]).length;if(water)bits.push("Water "+water+"/5");let reset=Object.keys(state.checks||{}).filter(x=>x.startsWith("reset|"+d+"|")&&state.checks[x]).length;if(reset)bits.push("Sunday Reset "+reset+"/5");let daily=[];if(state.checks[`daily|${d}|vitamins`])daily.push("Vitamins");if(state.checks[`daily|${d}|creatine`])daily.push("Creatine");if(daily.length)bits.push("Daily checks: "+daily.join(" + "));let snap=state.routineSnapshots?.[d];if(snap?.tasks?.length){let done=snap.tasks.filter(t=>t.done).map(t=>t.name),changes=snap.tasks.filter(t=>t.customFixed||t.errandMeta).map(t=>t.errandMeta?`${t.name} • ${t.duration} min inserted (${fmt(t.errandMeta.enteredStart)}–${fmt(t.errandMeta.enteredEnd)} entered)`: `${t.name} ${fmt(t.customFixed.st)}–${fmt(t.customFixed.en)}`);if(done.length)bits.push("Routine: "+done.join(", "));if(changes.length)bits.push("Routine changes: "+changes.join(", "))}else{let idx=(new Date(d+"T12:00:00").getDay()+6)%7,day=DAYS[idx],rd=state.routineV2?.[day],rs=state.routineStatus?.[d]||{};if(rd?.tasks?.length){let done=rd.tasks.filter(t=>!!rs[t.id]).map(t=>t.name);if(done.length)bits.push("Routine: "+done.join(", "))}}return `<p>${bits.length?bits.map(esc).join("<br>"):"Saved daily activity"}</p>`}
 return `<p>Saved activity for ${esc(d)}.</p>`
}
function donutData(items,labelFn,valueFn){let vals=items.map(valueFn),total=vals.reduce((a,b)=>a+b,0),cols=["#e88eaa","#f2b8c8","#d9a6b4","#f5ccd7","#c9879b","#f0a9bd","#b9788d","#f7dce4"];if(total<=0)return `<p class="muted">No data to chart yet.</p>`;let at=0,parts=vals.map((v,i)=>{let a=at/total*360;at+=v;let b=at/total*360;return `${cols[i%cols.length]} ${a}deg ${b}deg`});return `<div class="donut-wrap"><div class="donut" style="background:conic-gradient(${parts.join(",")})"></div><div class="legend">${items.map((x,i)=>`<div class="legend-row"><span><i class="legend-dot" style="background:${cols[i%cols.length]}"></i>${esc(labelFn(x))}</span><b>${vals[i]===Math.floor(vals[i])?vals[i]:money(vals[i])}</b></div>`).join("")}</div></div>`}
function wish(){
 if(state.sub&&state.sub.startsWith("wish:"))return wishCat(state.sub.slice(5));
 let items=WISHCATS.map(c=>({c,n:(state.wish[c]||[]).length}));return hero("Wish List","Dream board")+`<section class="card"><h2>Categories</h2><div class="grid">${WISHCATS.map(c=>`<button class="tile" data-wish="${c}"><b>${c}</b><span>${(state.wish[c]||[]).length} saved</span></button>`).join("")}</div></section><section class="card"><h2>Wish List Mix</h2>${donutData(items,x=>x.c,x=>x.n)}</section>`
}
function wishCat(c){let arr=state.wish[c]||[],total=arr.reduce((a,x)=>a+Math.max(0,Number(x.price||0)),0);return hero(c,"Wish List")+back("Wish List")+`<section class="card">${arr.map((x,i)=>`<div class="checkrow"><input type="checkbox" data-wish-done="${c}|${i}" ${x.done?'checked':''}><span style="flex:1">${safeLink(x.link)?`<a href="${esc(safeLink(x.link))}" target="_blank" rel="noopener noreferrer">${esc(x.item)}</a>`:esc(x.item)}</span><b>${money(x.price)}</b><button class="btn" data-wish-edit="${c}|${i}">Edit</button><button class="btn" data-wish-del="${c}|${i}" aria-label="Remove wish item">×</button></div>`).join("")||'<p class="muted">Nothing here yet.</p>'}<div class="formgrid"><input id="wishItem" aria-label="Wish item" placeholder="Item"><input id="wishPrice" aria-label="Wish item price" type="number" min="0" step=".01" placeholder="Price"><input id="wishLink" aria-label="Wish item optional link" type="url" placeholder="Optional link"></div><button class="btn primary" data-wish-add="${c}">Add Item</button></section><section class="card soft"><div class="muted">${esc(c)} TOTAL</div><div class="metric money">${money(total)}</div></section>`}
function validateSelectedDayContext(){let d=DAYS[state.day],meal=(MEAL.days||{})[selectedKey()]||null;if(state.route==="today"&&state.sub==="measure"&&state.day!==0)state.sub=null;if(state.route==="today"&&state.sub==="reset"&&state.day!==6)state.sub=null;if(state.route==="food"&&state.sub==="grocery"&&state.day!==0)state.sub=null;if(state.route==="food"&&state.sub==="cook"&&!(meal?.cook?.length))state.sub=null;if(state.route==="gym"&&state.sub==="run"&&DAY_ACTIVITY[d]!=="RUN")state.sub=null;}
function render(){validateSelectedDayContext();nav();let fn={today,food,gym,budget,history,wish}[state.route]||today;let html;if(state.route==="today"&&state.sub){let subpages={routine,faith,goals,school,weigh,measure,reset};html=subpages[state.sub]?subpages[state.sub]():today()}else html=fn();document.getElementById("app").innerHTML=html+sheetMarkup()+toastMarkup()}
document.addEventListener("input",e=>{
 let nn=e.target.closest?.("[data-nutrition-note]");if(nn){let [ri,ii]=nn.dataset.nutritionNote.split("|"),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||"");state.nutritionFacts=state.nutritionFacts||{};let n=state.nutritionFacts[rn+"|"+ii]||(state.nutritionFacts[rn+"|"+ii]={});n.note=nn.value;save();return}

 let hn=e.target.closest?.("[data-haul-name],[data-haul-qty],[data-haul-upc]");if(hn){let key=hn.dataset.haulName||hn.dataset.haulQty||hn.dataset.haulUpc,h=state.mondayHaul[key]||(state.mondayHaul[key]={});if(hn.dataset.haulName!==undefined)h.name=hn.value;if(hn.dataset.haulQty!==undefined)h.qty=hn.value;if(hn.dataset.haulUpc!==undefined)h.upc=hn.value;save();return}
 let rg=e.target.closest?.("[data-raw-grams]");if(rg){let id=rg.dataset.rawGrams,x=state.rawPortions[id]||(state.rawPortions[id]={}),v=Number(rg.value);if(Number.isFinite(v)&&v>0)x.grams=v;save();let plan=MONDAY_PORTION_PLAN.find(z=>z.id===id),loc=x.storage||plan?.storage,lab=rg.closest(".raw-portion-card")?.querySelector(".label-preview");if(plan&&lab)lab.innerHTML="<b>MEAT LABEL</b><br>"+rawMeatLabel(plan.meat,plan.useDate,x.grams||plan.grams,loc).map(esc).join("<br>");return}

 let ca=e.target.closest?.("[data-cook-adjust]");if(ca){let [ri,ii,field]=ca.dataset.cookAdjust.split("|"),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||""),key=selectedKey()+"|"+rn;state.cookAdjustments=state.cookAdjustments||{};let a=state.cookAdjustments[key]||(state.cookAdjustments[key]={ingredients:{},containers:{}});a.ingredients=a.ingredients||{};a.ingredients[ii]=a.ingredients[ii]||{};a.ingredients[ii][field]=ca.value;save();return}
 let co=e.target.closest?.("[data-container-adjust]");if(co){let [ri,ci,field]=co.dataset.containerAdjust.split("|"),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||""),key=selectedKey()+"|"+rn;state.cookAdjustments=state.cookAdjustments||{};let a=state.cookAdjustments[key]||(state.cookAdjustments[key]={ingredients:{},containers:{}});a.containers=a.containers||{};a.containers[ci]=a.containers[ci]||{};a.containers[ci][field]=co.value;save();return}
 let bc=e.target.closest?.("[data-grocery-barcode]");if(bc){state.groceryBarcodes=state.groceryBarcodes||{};state.groceryBarcodes[bc.dataset.groceryBarcode]=bc.value.trim();save();return}let el=e.target.closest?.("[data-cook-weight],[data-cook-ingredient]");if(!el)return;let day=todayMeal(),raw=el.dataset.cookWeight||el.dataset.cookIngredient,parts=raw.split("|"),idx=+parts[0],part=el.dataset.cookIngredient!==undefined?"ingredient"+parts[1]:parts[1],n=day?.cook?.[idx],rn=Object.keys(MEAL.recipes||{}).find(x=>n?.startsWith(x))||n;if(!rn)return;let key=`${selectedKey()}|${rn}`,draft=state.cookDraft[key]||(state.cookDraft[key]={});if(el.value==="")delete draft[part];else {let v=Number(el.value);if(Number.isFinite(v)&&v>=0)draft[part]=v}if(!Object.keys(draft).length)delete state.cookDraft[key];save();let box=document.querySelector(`[data-portion-suggest="${idx}"]`);if(box){let count=Math.max(1,cookAssignments(rn).length),m=Number(draft.main),sd=Number(draft.side);box.innerHTML=`<b>SUGGESTED PER CONTAINER</b><br>MAIN: ${Number.isFinite(m)&&m>0?(m/count).toFixed(1)+" g":"—"}${Number.isFinite(sd)&&sd>0?` • SIDE / SAUCE: ${(sd/count).toFixed(1)} g`:""}`}});

document.addEventListener("change",async e=>{
 let hl=e.target.closest?.("[data-haul-location]");if(hl){let h=state.mondayHaul[hl.dataset.haulLocation]||(state.mondayHaul[hl.dataset.haulLocation]={});h.location=hl.value;save();return}
 let rl=e.target.closest?.("[data-raw-location]");if(rl){let id=rl.dataset.rawLocation,x=state.rawPortions[id]||(state.rawPortions[id]={});x.storage=rl.value;save();render();return}
 let hs=e.target.closest?.("[data-haul-scan]");if(hs&&hs.files?.[0]){let key=hs.dataset.haulScan;try{if(!("BarcodeDetector" in window))throw new Error("unsupported");let img=await createImageBitmap(hs.files[0]),det=new BarcodeDetector({formats:["upc_a","upc_e","ean_13","ean_8"]}),codes=await det.detect(img);if(!codes.length)throw new Error("not found");let h=state.mondayHaul[key]||(state.mondayHaul[key]={});h.upc=codes[0].rawValue;save();render();showToast("Barcode captured. Confirm the product and quantity, then add it.","Purchase");}catch(err){showToast("This browser could not read that barcode. Type the UPC or enter the product manually.","Barcode");}return}
let f=e.target.closest?.("[data-barcode-file]");if(!f||!f.files?.[0])return;let key=f.dataset.barcodeFile;try{if(!("BarcodeDetector" in window))throw new Error("unsupported");let img=await createImageBitmap(f.files[0]),det=new BarcodeDetector({formats:["upc_a","upc_e","ean_13","ean_8"]}),codes=await det.detect(img);if(!codes.length)throw new Error("not found");state.groceryBarcodes=state.groceryBarcodes||{};state.groceryBarcodes[key]=codes[0].rawValue;save();render();showToast("Barcode saved to this grocery item.","Barcode scanned")}catch(err){showToast("Camera barcode reading is not supported here or the code was not detected. You can type the UPC in the small field instead.","Barcode")}});
document.addEventListener("click",e=>{
 let direct=e.target.closest?.("[data-grocery-to-inventory],[data-add-haul],[data-confirm-raw]");
 if(direct?.hasAttribute("data-grocery-to-inventory")){state.route="food";state.sub="inventory";state.inventoryTab="Fridge";save();render();return}
 if(direct?.dataset.addHaul){let key=direct.dataset.addHaul,h=state.mondayHaul[key]||(state.mondayHaul[key]={}),src=purchasedGroceries().find(x=>x.key===key);if(!src)return;let name=(document.querySelector(`[data-haul-name="${CSS.escape(key)}"]`)?.value||h.name||src.item).trim(),qty=(document.querySelector(`[data-haul-qty="${CSS.escape(key)}"]`)?.value||h.qty||"").trim(),loc=document.querySelector(`[data-haul-location="${CSS.escape(key)}"]`)?.value||h.location||purchaseDefaultLocation(src.item),upc=(document.querySelector(`[data-haul-upc="${CSS.escape(key)}"]`)?.value||h.upc||"").trim();if(!name){showToast("Enter the product you actually brought home.","Missing product");return}let price=Number(state.groceryPrices[groceryPriceKey(src.store,src.item)]??groceryEstimate(src.store,src.item))||0,rec={name,qty,upc,haulKey:key,source:"Grocery List",store:src.store,grocerySpec:src.item,plannedBuy:groceryBuyUnit(src.item),purchasePrice:price,purchasedDate:selectedKey(),addedAt:new Date().toISOString(),notes:[`PURCHASED • ${src.store}`,`ORIGINAL GROCERY SPEC: ${src.item}`,`PLANNED BUY: ${groceryBuyUnit(src.item)}`,upc?`UPC: ${upc}`:""].filter(Boolean).join(" • ")};let existing=(state.inventory[loc]||[]).find(x=>x.haulKey===key);if(existing)Object.assign(existing,rec);else state.inventory[loc].push(rec);Object.assign(h,{name,qty,location:loc,upc,added:true,grocerySpec:src.item,plannedBuy:groceryBuyUnit(src.item),store:src.store,purchasePrice:price});save();render();showToast("Saved with grocery specifications to "+loc+".","Inventory updated");return}
 if(direct?.dataset.confirmRaw){let id=direct.dataset.confirmRaw,plan=MONDAY_PORTION_PLAN.find(x=>x.id===id);if(!plan)return;let x=state.rawPortions[id]||(state.rawPortions[id]={}),grams=Number(x.grams||plan.grams),storage=(x.storage||plan.storage).toUpperCase(),cat=storage==="FREEZER"?"Freezer":"Fridge";x.grams=grams;x.storage=storage;x.confirmed=true;x.labelRows=rawMeatLabel(plan.meat,plan.useDate,grams,storage);["Fridge","Freezer"].forEach(c=>state.inventory[c]=state.inventory[c].filter(z=>z.rawPortionId!==id));state.inventory[cat].push({name:plan.meat,qty:`${grams} g`,rawPortionId:id,useDate:plan.useDate,storage,labelRows:x.labelRows,notes:x.labelRows.join(" • ")});save();render();showToast("Portion confirmed and label ready.","Monday portioning");return}
if(e.target.matches?.("[data-sheet-close]")){uiSheet=null;render();return}let t=e.target.closest("[data-route],[data-sub],[data-day],[data-back],button,input[type=checkbox]");if(!t)return;if(t.hasAttribute("data-sheet-cancel")){uiSheet=null;render();return}if(t.hasAttribute("data-sheet-confirm")){let q=uiSheet?.action;if(!q)return;uiSheet=null;if(q.kind==="goalRemove"){let a=goalsForDate(q.key),i=+q.index;if(a[i]){a.splice(i,1);let old=state.goalHistory[q.key]||{},next={};Object.keys(old).forEach(z=>{let n=+z;if(n<i)next[n]=old[z];else if(n>i)next[n-1]=old[z]});if(Object.keys(next).length)state.goalHistory[q.key]=next;else delete state.goalHistory[q.key];if(!a.length)delete state.goalsByDate[q.key]}}else if(q.kind==="containerEat"){let x=state.inventory.Containers[+q.index];if(x){recordEatenContainer(x,q.date||selectedKey());state.inventory.Containers.splice(+q.index,1)}}else if(q.kind==="containerDiscard"){let x=state.inventory.Containers[+q.index];if(x){state.foodHistory.push({id:uid("food"),date:q.date||selectedKey(),type:"DISCARDED CONTAINER",recipe:x.recipe||x.name,container:x.name});state.inventory.Containers.splice(+q.index,1)}}else if(q.kind==="inventoryRemove"){if(state.inventory[q.cat]?.[+q.index])state.inventory[q.cat].splice(+q.index,1)}else if(q.kind==="wishRemove"){if(state.wish[q.cat]?.[+q.index])state.wish[q.cat].splice(+q.index,1)}else if(q.kind==="groceryCustomRemove"){if(state.groceryCustom?.[q.store]?.[+q.index])state.groceryCustom[q.store].splice(+q.index,1)}else if(q.kind==="buyRemove"){if(state.budget.buys?.[q.id]?.[+q.index])state.budget.buys[q.id].splice(+q.index,1)}else if(q.kind==="unplannedRemove"){if(state.budget.unplannedByMonth?.[q.id]?.[+q.index])state.budget.unplannedByMonth[q.id].splice(+q.index,1)}else if(q.kind==="routineTaskRemove"){let a=rday(q.day).tasks,x=a[+q.index];if(x&&x.id!=="careM"&&x.id!=="careN"){let st=state.routineStatus[selectedKey()]||{};delete st[x.id];(x.subtasks||[]).forEach(z=>delete st[x.id+"|"+z.id]);a.splice(+q.index,1);saveRoutineSnapshot(q.day)}}else if(q.kind==="routineSubRemove"){let x=rday(q.day).tasks[+q.index],z=x?.subtasks?.[+q.subIndex];if(z){let st=state.routineStatus[selectedKey()]||{};delete st[x.id+"|"+z.id];x.subtasks.splice(+q.subIndex,1);st[x.id]=x.subtasks.length>0&&x.subtasks.every(v=>!!st[x.id+"|"+v.id]);saveRoutineSnapshot(q.day)}}save();render();return}if(t.dataset.sheetSaveErrand){let d=t.dataset.sheetSaveErrand,a=rday(d).tasks,name=document.getElementById("errName")?.value.trim(),sm=parseClock(document.getElementById("errStart")?.value),em=parseClock(document.getElementById("errEnd")?.value);if(!name){showToast("Add an errand name.","Missing name");return}if(sm===null||em===null){showToast("Enter a valid start and end time, like 1:30 PM and 2:10 PM.","Check the times");return}if(em<=sm)em+=1440;let dur=em-sm;if(!(dur>0)){showToast("End time must be after start time.","Check the times");return}let edit=t.dataset.sheetEditIndex!==undefined?+t.dataset.sheetEditIndex:null;let after=+document.getElementById("errAfter")?.value;if(!Number.isInteger(after)||after<0||after>=a.length)after=0;if(Number.isInteger(edit)){let x=a[edit];if(!x)return;let st=state.routineStatus[selectedKey()]||{};a.splice(edit,1);if(after>edit)after--;after=Math.max(0,Math.min(after,a.length-1));x.name=name;x.duration=dur;x.errandMeta={enteredStart:sm,enteredEnd:em};x.customFixed=null;x.section=a[after]?.section||x.section||"Day";a.splice(after+1,0,x)}else{let sec=a[after]?.section||"Day";a.splice(after+1,0,{id:uid("errand"),name,duration:dur,section:sec,done:false,subtasks:[],errandMeta:{enteredStart:sm,enteredEnd:em},customFixed:null})}uiSheet=null;saveRoutineSnapshot(d);save();render();return}if(t.dataset.sheetSaveTask){let d=t.dataset.sheetSaveTask,i=+t.dataset.sheetIndex,x=rday(d).tasks[i],n=document.getElementById("taskName")?.value.trim(),dur=Number(document.getElementById("taskDuration")?.value);if(!x||!n||!Number.isFinite(dur)||dur<0){showToast("Enter a task name and a valid duration.","Check the block");return}x.name=n;x.duration=dur;uiSheet=null;saveRoutineSnapshot(d);save();render();return}
 if(t.dataset.sheetSaveSubtask){let d=t.dataset.sheetSaveSubtask,i=+t.dataset.sheetIndex,x=rday(d).tasks[i],n=document.getElementById("subtaskName")?.value.trim();if(!x||!n){showToast("Enter a subtask name.","Missing name");return}if(x.id==="careN"&&/toner|medicube|\bspf\b/i.test(n)){showToast("Toner pads and SPF are Morning Care only.","Morning Care only");return}let j=t.dataset.sheetSubIndex!==undefined?+t.dataset.sheetSubIndex:null;if(Number.isInteger(j)&&x.subtasks?.[j])x.subtasks[j].name=n;else{x.subtasks=x.subtasks||[];x.subtasks.push({id:uid("s"),name:n,done:false});let st=state.routineStatus[selectedKey()]||(state.routineStatus[selectedKey()]={});st[x.id]=false}uiSheet=null;saveRoutineSnapshot(d);save();render();return}
 if(t.dataset.sheetSaveWake){let d=t.dataset.sheetSaveWake,m=parseClock(document.getElementById("wakeTime")?.value);if(m===null){showToast("Enter a valid time, like 7:18 AM.","Check the time");return}state.routineStarts[selectedKey()]=m;uiSheet=null;saveRoutineSnapshot(d);save();render();return}
 if(t.hasAttribute("data-sheet-save-goal")){let x=goalsForDate(uiSheet.key)?.[uiSheet.index],v=document.getElementById("sheetGoalText")?.value.trim();if(x&&v){x.text=v;if(state.goalHistory[uiSheet.key]?.[uiSheet.index])state.goalHistory[uiSheet.key][uiSheet.index].text=v;uiSheet=null;save();render()}return}
 if(t.hasAttribute("data-sheet-save-wish")){let x=state.wish[uiSheet.cat]?.[uiSheet.index],n=document.getElementById("sheetWishItem")?.value.trim();if(x&&n){x.item=n;x.price=Math.max(0,Number(document.getElementById("sheetWishPrice")?.value)||0);x.link=safeLink(document.getElementById("sheetWishLink")?.value.trim()||"");uiSheet=null;save();render()}return}
 if(t.hasAttribute("data-sheet-save-inv")){let x=state.inventory[uiSheet.cat]?.[uiSheet.index],n=document.getElementById("sheetInvName")?.value.trim(),q=document.getElementById("sheetInvQty")?.value.trim();if(x&&n){x.name=n;x.qty=q;uiSheet=null;save();render()}return}
 if(t.hasAttribute("data-sheet-save-autopay")){let x=uiSheet?.row,raw=document.getElementById("sheetAutopayAmount")?.value.trim(),next=Number(raw);if(!x||raw===""||!Number.isFinite(next)||next<0){showToast("Enter a valid autopay amount.","Check amount");return}next=Math.round(next*100)/100;let key=autopayKey(x),paid=!!state.checks[key],old=paid&&Number.isFinite(Number(state.budget?.paymentEvents?.[key]?.amount))?Number(state.budget.paymentEvents[key].amount):(Number(x.a)||0);state.budget.autopayOverrides=state.budget.autopayOverrides||{};state.budget.autopayOverrides[autopayOverrideKey(x)]=next;if(paid&&Math.abs(next-old)>.0001){state.budget.balance=Math.round((Number(state.budget.balance||0)-(next-old))*100)/100;state.budget.balanceAsOf=localDateKey();state.budget.paymentEvents=state.budget.paymentEvents||{};state.budget.paymentEvents[key]={...(state.budget.paymentEvents[key]||{}),amount:next}}uiSheet=null;save();render();showToast("Autopay updated everywhere.",`${x.n} • ${money(next)}`);return}
 if(t.dataset.finishCook){let [d,i]=t.dataset.finishCook.split("|");finishCooking(+d,+i);return}
 if(t.hasAttribute("data-gym-all-planned")){let d=DAYS[state.day],plan=GYM_PLAN[d],k=selectedKey(),log=state.gymLog[k]||(state.gymLog[k]={});plan.steps.forEach(ex=>{let z=log[ex.name]||(log[ex.name]={}),custom=state.gymTargets[d+"|"+ex.name]||ex.sets;custom.forEach((st,i)=>{z["w"+i]=String(st[0]||0);z["r"+i]=String(st[1]||0);z["p"+i]=true});z.done=true});save();render();return}
 if(t.dataset.gymSetPlanned!==undefined){let d=DAYS[state.day],[ei,si]=t.dataset.gymSetPlanned.split("|").map(Number),ex=GYM_PLAN[d]?.steps[ei];if(!ex)return;let k=selectedKey(),log=state.gymLog[k]||(state.gymLog[k]={}),z=log[ex.name]||(log[ex.name]={}),custom=state.gymTargets[d+"|"+ex.name]||ex.sets;if(t.checked){z["w"+si]=String(custom[si][0]||0);z["r"+si]=String(custom[si][1]||0);z["p"+si]=true}else{z["w"+si]="0";z["r"+si]="0";z["p"+si]=false;z.done=false}z.done=custom.every((_,i)=>z["p"+i]===true||(+z["r"+i]>0));save();render();return}
 if(t.dataset.gymUpWeight!==undefined){let d=DAYS[state.day],[ei,si]=t.dataset.gymUpWeight.split("|").map(Number),ex=GYM_PLAN[d]?.steps[ei];if(!ex)return;let k=selectedKey(),log=state.gymLog[k]||(state.gymLog[k]={}),z=log[ex.name]||(log[ex.name]={}),custom=state.gymTargets[d+"|"+ex.name]||ex.sets,raw=String(z["w"+si]??custom[si][0]??"0").trim(),n=/^\d+(?:\.\d+)?$/.test(raw)?Number(raw):NaN;if(!Number.isFinite(n)){showToast("TYPE THE ACTUAL WEIGHT IN THE BOX FOR THIS SET.","MANUAL WEIGHT");return}z["w"+si]=String(ex.assistance?Math.max(0,n-ex.inc):n+ex.inc);z["p"+si]=false;z.done=false;save();render();return}
 if(t.hasAttribute("data-save-gym")){let k=selectedKey(),log=state.gymLog[k]||(state.gymLog[k]={});document.querySelectorAll("[data-gym-field]").forEach(el=>{let [name,f]=el.dataset.gymField.split("|");log[name]=log[name]||{};log[name][f]=f.startsWith("r")?String(Math.max(0,Math.min(12,+el.value||0))):(()=>{let raw=el.value.trim();if(raw==="")return "0";let n=Number(raw);return Number.isFinite(n)?String(Math.max(0,n)):raw})()});let d=DAYS[state.day],plan=GYM_PLAN[d];plan.steps.forEach(ex=>{let z=log[ex.name]||(log[ex.name]={}),sets=state.gymTargets[d+"|"+ex.name]||ex.sets;z.done=sets.every((_,i)=>z["p"+i]===true||(+z["r"+i]>0))});save();render();showToast("WORKOUT SAVED.","GYM");return}
 if(t.dataset.faithDone!==undefined){let k=selectedKey(),x=state.bible[k]||(state.bible[k]={entries:[],done:[]});x.done=x.done||[];x.done[+t.dataset.faithDone]=t.checked;save();return}
 if(t.hasAttribute("data-save-faith")){let k=t.dataset.saveFaith,entries=[],done=[];document.querySelectorAll("[data-faith-field]").forEach(el=>entries[+el.dataset.faithField]=el.value.trim());document.querySelectorAll("[data-faith-done]").forEach(el=>done[+el.dataset.faithDone]=el.checked);if(entries.some(Boolean)||done.some(Boolean)||Object.values(state.bible[k]?.psalms||{}).some(Boolean))state.bible[k]={...(state.bible[k]||{}),entries,done,psalms:{...(state.bible[k]?.psalms||{})},updated:new Date().toISOString()};else delete state.bible[k];save();render();return}
 if(t.dataset.histnav){let [type,level,...v]=t.dataset.histnav.split("|");state.sub=v.length&&v.some(x=>x!=="")?`hist:${type}:${level}:${v.join("|")}`:`hist:${type}:${level}`;save();render();appTop();return}
 
 if(t.hasAttribute("data-copy-routine")){let d=DAYS[state.day],tl=timeline(d),text=`${d.toUpperCase()} ROUTINE • ${selectedKey()}\n`+tl.map(x=>`${fmt(x.st)}–${fmt(x.en)} • ${x.t.name}${(x.t.subtasks||[]).length?"\n  "+x.t.subtasks.map(q=>"• "+q.name).join("\n  "):""}`).join("\n");if(navigator.clipboard?.writeText)navigator.clipboard.writeText(text).then(()=>showToast("Routine copied to your clipboard.","Copied")).catch(()=>showToast("Copy is unavailable in this browser.","Couldn’t copy"));else showToast("Copy is unavailable in this browser.","Couldn’t copy");return}
 if(t.dataset.weekShift){state.weekOffset=(state.weekOffset||0)+(+t.dataset.weekShift);save();render();appTop();return}
 if(t.dataset.rjump!==undefined){let d=DAYS[state.day],idx=+t.dataset.rjump,item=timeline(d).find(x=>x.i===idx);if(!item)return;rday(d).open=item.t.section;save();render();requestAnimationFrame(()=>{requestAnimationFrame(()=>{let el=document.getElementById("routine-block-"+idx);if(!el)return;el.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"});el.classList.add("routine-target");setTimeout(()=>el.classList.remove("routine-target"),1900)})});return}
  if(t.dataset.groceryHave){let [store,i]=t.dataset.groceryHave.split("|");state.checks[`groceryHave|${store}|${i}`]=t.checked;save();return}
 if(t.dataset.cookAllPlanned!==undefined){let ri=+t.dataset.cookAllPlanned,rn=cookRecipeName(todayMeal()?.cook?.[ri]||""),r=MEAL.recipes?.[rn],key=selectedKey()+"|"+rn;state.cookComponents=state.cookComponents||{};let cs=state.cookComponents[key]||(state.cookComponents[key]={});recipeComponentDefs(rn,r).forEach(c=>{cs[c.id]=cs[c.id]||{};cs[c.id].usedPlanned=!!t.checked});save();render();return}
 if(t.dataset.cookWhole!==undefined){let ri=+t.dataset.cookWhole,rn=cookRecipeName(todayMeal()?.cook?.[ri]||""),key=selectedKey()+"|"+rn;state.cookAdjustments=state.cookAdjustments||{};let a=state.cookAdjustments[key]||(state.cookAdjustments[key]={ingredients:{},containers:{}});a.wholeRecipe=t.checked;save();return}
 if(t.dataset.faithPsalm){let k=selectedKey(),x=state.bible[k]||(state.bible[k]={entries:[],done:[],psalms:{}});x.psalms=x.psalms||{};x.psalms[t.dataset.faithPsalm]=t.checked;save();render();return}
 if(t.dataset.mealDay){let target=t.dataset.mealDay,dt=new Date(target+"T12:00:00"),now=new Date(),mon=new Date(now);mon.setHours(12,0,0,0);mon.setDate(now.getDate()-((now.getDay()+6)%7));state.day=(dt.getDay()+6)%7;state.weekOffset=Math.round((dt-mon)/(7*86400000));delete state.mealPlanDay;save();render();return}
 if(t.hasAttribute("data-log-food")){let name=document.getElementById("ateName")?.value.trim(),amount=document.getElementById("ateAmount")?.value.trim(),barcode=document.getElementById("ateBarcode")?.value.trim();if(!name){showToast("Enter the food you ate.","Missing food");return}state.foodHistory.push({id:uid("food"),date:selectedKey(),type:"ATE",name,amount,barcode});save();render();return}
 if(t.dataset.eatContainer!==undefined){let i=+t.dataset.eatContainer,c=state.inventory.Containers[i];if(c){recordEatenContainer(c,selectedKey());state.inventory.Containers.splice(i,1);save();render()}return}
 if(t.dataset.foodlogDel!==undefined){let id=t.dataset.foodlogDel,removed=null;state.foodHistory=state.foodHistory.filter(x=>{let hit=String(x.id||"")===String(id);if(hit)removed=x;return !hit});if(removed?.macros)addMacrosToActual((removed.date||selectedKey()).slice(0,10),removed.macros,-1);save();render();return}
 if(t.dataset.mainRoute){setRoute(t.dataset.mainRoute,null);return} if(t.dataset.route){setRoute(t.dataset.route,t.dataset.sub||null);return} if(t.dataset.day!==undefined){state.day=+t.dataset.day;save();render();appTop();return} if(t.dataset.sub){state.sub=t.dataset.sub;save();render();appTop();return} if(t.hasAttribute("data-back")){let target=t.dataset.back;if(state.route==="budget"){if(target==="Budget")state.sub=null;else if(state.sub?.startsWith("week:")){let [y,m]=state.sub.split(":").slice(1);state.sub="month:"+y+":"+m}else if(state.sub?.startsWith("month:")){let y=state.sub.split(":")[1];state.sub="year:"+y}else state.sub=null;}else if(target==="Today"){state.route="today";state.sub=null}else if(target==="Food"){state.route="food";state.sub=null}else if(target==="Gym"){state.route="gym";state.sub=null}else if(target==="History"){state.route="history";state.sub=null}else if(target==="Wish List"){state.route="wish";state.sub=null}else state.sub=null;save();render();appTop();return}
 if(t.dataset.editAutopay){let [dk,n,b]=t.dataset.editAutopay.split("|").map(decodeURIComponent),dt=new Date(dk+"T12:00:00"),rows=monthRows(dt.getFullYear(),dt.getMonth()),row=rows.find(x=>localDateKey(x.date)===dk&&x.n===n&&Math.abs(Number(x.baseA??x.a)-Number(b))<.001);if(row){uiSheet={type:"autopayEdit",row:{...row,date:new Date(row.date)}};render()}return}
 if(t.dataset.budgetOccurrence){let rawOcc=t.dataset.budgetOccurrence,firstSep=rawOcc.indexOf("|"),lastSep=rawOcc.lastIndexOf("|"),type=rawOcc.slice(0,firstSep),key=rawOcc.slice(firstSep+1,lastSep),raw=rawOcc.slice(lastSep+1),amt=Math.max(0,Number(raw)||0),was=!!state.checks[key],now=!!t.checked;if(was!==now){state.budget.paymentEvents=state.budget.paymentEvents||{};let prior=state.budget.paymentEvents[key],effectiveAmt=(!now&&Number.isFinite(Number(prior?.amount)))?Math.max(0,Number(prior.amount)):amt;state.checks[key]=now;let delta=(type==="income"?effectiveAmt:-effectiveAmt)*(now?1:-1);state.budget.balance=Math.round((Number(state.budget.balance||0)+delta)*100)/100;state.budget.balanceAsOf=localDateKey();if(now)state.budget.paymentEvents[key]={...(prior||{}),type,checkedDate:prior?.checkedDate||localDateKey(),actualDate:prior?.actualDate||localDateKey(),amount:amt};else delete state.budget.paymentEvents[key];save();render()}return}
 if(t.dataset.check){let id=t.dataset.check,[a,b,c]=id.split("|");if(a==="water")state.water[b+"|"+c]=t.checked;else state.checks[id]=t.checked;save();render();return}
 if(t.dataset.faithPsalm!==undefined){let k=selectedKey(),n=String(t.dataset.faithPsalm);state.bible[k]=state.bible[k]||{entries:[],done:[],psalms:{}};state.bible[k].psalms=state.bible[k].psalms||{};state.bible[k].psalms[n]=!!t.checked;save();render();return}
 if(t.dataset.faithDone!==undefined){let k=selectedKey(),i=+t.dataset.faithDone;state.bible[k]=state.bible[k]||{entries:[],done:[],psalms:{}};state.bible[k].done=state.bible[k].done||[];state.bible[k].done[i]=!!t.checked;save();render();return}
 if(t.dataset.goalDone!==undefined){let k=t.dataset.goalDate||selectedKey(),i=+t.dataset.goalDone,g=goalsForDate(k)[i];if(!g)return;state.goalHistory[k]=state.goalHistory[k]||{};state.goalHistory[k][i]={text:g.text,done:t.checked,important:!!g.important};save();render();return}
 if(t.hasAttribute("data-add-goal")){let v=document.getElementById("goalText").value.trim();if(v){goalsForDate().push({text:v,important:document.getElementById("goalImportant").checked});save();render()}return}
 if(t.dataset.goalEdit!==undefined){uiSheet={type:"goalEdit",key:selectedKey(),index:+t.dataset.goalEdit};render();return}
 if(t.dataset.goalRemove!==undefined){let k=selectedKey(),i=+t.dataset.goalRemove,a=goalsForDate(k);if(!a[i])return;askConfirm("Remove Goal?",`Remove “${a[i].text}” from ${k}?`,{kind:"goalRemove",key:k,index:i},"Remove Goal");return}

 if(t.hasAttribute("data-save-macros")){let k=selectedKey(),a={};document.querySelectorAll("[data-macro]").forEach(el=>a[el.dataset.macro]=el.value===""?"":Math.max(0,+el.value||0));if(Object.values(a).some(v=>v!==""))state.actualFood[k]=a;else delete state.actualFood[k];save();render();return}
 if(t.hasAttribute("data-save-study")){let k=selectedKey(),v=document.getElementById("studyNote").value.trim(),r=document.getElementById("studyResource").value.trim();if(v)state.studyNotes[k]=v;else delete state.studyNotes[k];if(r)state.studyResources[k]=r;else delete state.studyResources[k];save();render();return}
 if(t.hasAttribute("data-save-weight")){let k=selectedKey(),v=document.getElementById("weightInput").value;if(v==="")delete state.weight[k];else state.weight[k]=Math.max(0,+v||0);save();render();return}
 if(t.hasAttribute("data-save-measure")){let k=selectedKey(),m={};document.querySelectorAll("[data-measure]").forEach(x=>m[x.dataset.measure]=x.value===""?"":Math.max(0,+x.value||0));if(Object.values(m).some(v=>v!==""))state.measure[k]=m;else delete state.measure[k];if(m.weight!=="")state.weight[k]=m.weight;save();render();return}
 if(t.hasAttribute("data-save-run")){let k=selectedKey(),els=[document.getElementById("runIncline"),document.getElementById("runSpeed"),document.getElementById("runDuration")];if(els.every(el=>el.value===""))delete state.run[k];else state.run[k]={incline:Math.max(0,+els[0].value||0),speed:Math.max(0,+els[1].value||0),duration:Math.max(0,+els[2].value||0)};save();render();return}
 if(t.hasAttribute("data-save-balance")){let raw=document.getElementById("liveBalance").value.trim();if(raw==="")return;let v=Number(raw);if(!Number.isFinite(v))return;state.budget.balance=v;state.budget.balanceAsOf=localDateKey();save();render();return}
 if(t.hasAttribute("data-clear-study")){let k=selectedKey();delete state.studyNotes[k];delete state.studyResources[k];save();render();return}
 if(t.hasAttribute("data-clear-weight")){delete state.weight[selectedKey()];save();render();return}
 if(t.hasAttribute("data-clear-measure")){delete state.measure[selectedKey()];save();render();return}
 if(t.dataset.clearFaith){delete state.bible[t.dataset.clearFaith];save();render();return}
 if(t.hasAttribute("data-clear-run")){delete state.run[selectedKey()];save();render();return}
 if(t.dataset.groceryCustomAdd){let store=t.dataset.groceryCustomAdd,item=document.querySelector(`[data-grocery-custom-item="${store}"]`)?.value.trim(),qty=document.querySelector(`[data-grocery-custom-qty="${store}"]`)?.value.trim(),price=Math.max(0,Number(document.querySelector(`[data-grocery-custom-price="${store}"]`)?.value)||0);if(item){state.groceryCustom=state.groceryCustom||{};state.groceryCustom[store]=state.groceryCustom[store]||[];state.groceryCustom[store].push({item,qty:qty||"1 STORE UNIT",price});save();render()}return}
 if(t.dataset.groceryCustomDel){let [store,i]=t.dataset.groceryCustomDel.split("|"),x=state.groceryCustom?.[store]?.[+i];if(x)askConfirm("Remove Grocery Item?",`Remove “${x.item}” from ${store}?`,{kind:"groceryCustomRemove",store,index:+i},"Remove Item");return}
 if(t.dataset.budgetTool){let [kind,y,m,parent]=t.dataset.budgetTool.split("|");state.sub=`${kind}:${y}:${m}:${parent||"budget"}`;save();render();appTop();return}
 if(t.dataset.budgetReturn){state.sub=t.dataset.budgetReturn;save();render();appTop();return}
 if(t.dataset.budgetYear){state.sub="year:"+t.dataset.budgetYear;save();render();appTop();return}
 if(t.dataset.budgetMonth){let [y,m]=t.dataset.budgetMonth.split("|");state.sub="month:"+y+":"+m;save();render();appTop();return} if(t.dataset.week){let [y,m,w]=t.dataset.week.split("|");state.sub="week:"+y+":"+m+":"+w;save();render();appTop();return}
 if(t.dataset.addBuy){let id=t.dataset.addBuy,item=document.getElementById("buyItem").value.trim(),raw=document.getElementById("buyPrice").value.trim(),price=Number(raw);if(item&&raw!==""&&Number.isFinite(price)&&price>=0){state.budget.buys[id]=state.budget.buys[id]||[];state.budget.buys[id].push({item,price});save();render()}return}
 if(t.dataset.delBuy){let [id,i]=t.dataset.delBuy.split("|"),x=state.budget.buys[id]?.[+i];if(x)askConfirm("Remove Planned Purchase?",`Remove “${x.item}” from Things to Buy?`,{kind:"buyRemove",id,index:+i},"Remove");return}
 if(t.dataset.saveBeauty){let [id,kind]=t.dataset.saveBeauty.split("|"),amount=Math.max(0,Number(document.getElementById(`beauty-${kind}-amount`)?.value)||0),date=document.getElementById(`beauty-${kind}-date`)?.value||"";if(!amount||!validDateKeyRaw(date)){showToast("Enter both the amount and the actual date.","Nails / Eyebrows + Lashes");return}let [yy,mm]=id.split("-").map(Number),d=new Date(date+"T12:00:00");if(d.getFullYear()!==yy||d.getMonth()!==mm){showToast("Use a date inside this budget month.","Check the date");return}state.budget.beautyByMonth=state.budget.beautyByMonth||{};state.budget.beautyByMonth[id]=state.budget.beautyByMonth[id]||{};let prev=state.budget.beautyByMonth[id][kind]||{};state.budget.beautyByMonth[id][kind]={amount,date,done:!!prev.done};save();render();return}
 if(t.dataset.beautyDone){let [id,kind]=t.dataset.beautyDone.split("|");state.budget.beautyByMonth=state.budget.beautyByMonth||{};state.budget.beautyByMonth[id]=state.budget.beautyByMonth[id]||{};let x=state.budget.beautyByMonth[id][kind]||{amount:0,date:""};x.done=t.checked;state.budget.beautyByMonth[id][kind]=x;save();render();return}
 if(t.dataset.supportReceived){let [id,kind]=t.dataset.supportReceived.split("|");state.budget.supportByMonth=state.budget.supportByMonth||{};state.budget.supportByMonth[id]=state.budget.supportByMonth[id]||{};let x=state.budget.supportByMonth[id][kind]||{amount:100,date:""};x.received=t.checked;if(!t.checked)x.absorbedIntoAnchor=false;state.budget.supportByMonth[id][kind]=x;save();render();return}
 if(t.dataset.saveSupport){let [id,kind]=t.dataset.saveSupport.split("|");state.budget.supportByMonth=state.budget.supportByMonth||{};state.budget.supportByMonth[id]=state.budget.supportByMonth[id]||{};let amount=Math.max(0,Number(document.getElementById(`support-${kind}-amount`)?.value||100)),date=document.getElementById(`support-${kind}-date`)?.value||"",prev=state.budget.supportByMonth[id][kind]||{};state.budget.supportByMonth[id][kind]={...prev,amount,date,received:!!prev.received,absorbedIntoAnchor:false};save();render();return}
 if(t.dataset.addUnplanned){let id=t.dataset.addUnplanned,item=document.getElementById("unplannedItem").value.trim(),amount=+document.getElementById("unplannedAmount").value||0,day=+document.getElementById("unplannedDay").value||1;if(item&&amount>0){state.budget.unplannedByMonth[id]=state.budget.unplannedByMonth[id]||[];state.budget.unplannedByMonth[id].push({item,amount,day});save();render()}return}
 if(t.dataset.delUnplanned){let [id,i]=t.dataset.delUnplanned.split("|"),x=state.budget.unplannedByMonth[id]?.[+i];if(x)askConfirm("Remove Spending Entry?",`Remove “${x.item}” from Unplanned Spending?`,{kind:"unplannedRemove",id,index:+i},"Remove");return}
 if(t.dataset.emergency){let id=t.dataset.emergency;state.budget.emergency[id]=state.budget.emergency[id]||{skip:{}};state.budget.emergency[id].on=t.checked;save();render();return}
 if(t.dataset.skipbill){let [id,n,d]=t.dataset.skipbill.split("|"),key=d?n+"|"+d:n;state.budget.emergency[id]=state.budget.emergency[id]||{on:true,skip:{}};state.budget.emergency[id].skip[key]=t.checked;save();render();return}
 if(t.dataset.hist){state.sub="hist:"+t.dataset.hist+":year";save();render();appTop();return}
 if(t.dataset.saveGroceryPrices){let store=t.dataset.saveGroceryPrices;document.querySelectorAll("[data-grocery-price]").forEach(el=>{let [st,i]=el.dataset.groceryPrice.split("|");if(st===store){let item=MEAL.grocery?.[st]?.[+i],old=st+"|"+i;if(item){let raw=el.value.trim(),key=groceryPriceKey(st,item);if(raw==="")delete state.groceryPrices[key];else {let v=Number(raw);if(Number.isFinite(v)&&v>=0)state.groceryPrices[key]=v}delete state.groceryPrices[old]}}});save();render();return}
 if(t.dataset.wish){state.sub="wish:"+t.dataset.wish;save();render();appTop();return}
 if(t.dataset.wishAdd){let c=t.dataset.wishAdd,item=document.getElementById("wishItem").value.trim();if(!item)return;state.wish[c]=state.wish[c]||[];state.wish[c].push({item,price:Math.max(0,+document.getElementById("wishPrice").value||0),link:safeLink(document.getElementById("wishLink").value),done:false});save();render();return}
 if(t.dataset.wishDone){let [c,i]=t.dataset.wishDone.split("|");state.wish[c][+i].done=t.checked;save();return}
 if(t.dataset.wishEdit){let [c,i]=t.dataset.wishEdit.split("|");uiSheet={type:"wishEdit",cat:c,index:+i};render();return}
 if(t.dataset.wishDel){let [c,i]=t.dataset.wishDel.split("|"),x=state.wish[c]?.[+i];if(x)askConfirm("Remove Wish Item?",`Remove “${x.item}” from ${c}?`,{kind:"wishRemove",cat:c,index:+i},"Remove Item");return}
 if(t.dataset.rsection){rday(DAYS[state.day]).open=t.dataset.rsection;save();render();return}
 if(t.dataset.rtaskCheck){let openSnap=captureRoutineOpenDetails(),[d,i]=t.dataset.rtaskCheck.split("|"),x=rday(d).tasks[+i],k=selectedKey(),st=state.routineStatus[k]||(state.routineStatus[k]={});st[x.id]=t.checked;saveRoutineSnapshot(d);save();render();restoreRoutineOpenDetails(openSnap);return}
 if(t.dataset.rsubCheck){let openSnap=captureRoutineOpenDetails(),[d,i,j]=t.dataset.rsubCheck.split("|"),x=rday(d).tasks[+i],q=x.subtasks[+j],k=selectedKey(),st=state.routineStatus[k]||(state.routineStatus[k]={});st[x.id+"|"+q.id]=t.checked;saveRoutineSnapshot(d);save();render();restoreRoutineOpenDetails(openSnap);return}
 if(t.dataset.rtaskEdit){let [d,i]=t.dataset.rtaskEdit.split("|");let x=rday(d).tasks[+i];if(x.id==="careM"||x.id==="careN")return;if(x.errandMeta||String(x.id||"").startsWith("errand"))uiSheet={type:"errand",day:d,index:+i};else uiSheet={type:"task",day:d,index:+i};render();return}
 if(t.dataset.rtaskDel){let [d,i]=t.dataset.rtaskDel.split("|"),x=rday(d).tasks[+i];if(x?.id==="careM"||x?.id==="careN")return;if(x)askConfirm("Remove Routine Block?",`Remove “${x.name}” from this date’s routine?`,{kind:"routineTaskRemove",day:d,index:+i},"Remove Block");return}
 if(t.dataset.rsubAdd){let [d,i]=t.dataset.rsubAdd.split("|");uiSheet={type:"subtask",day:d,index:+i};render();return}
 if(t.dataset.rsubEdit){let [d,i,j]=t.dataset.rsubEdit.split("|");uiSheet={type:"subtask",day:d,index:+i,subIndex:+j};render();return}
 if(t.dataset.rsubDel){let [d,i,j]=t.dataset.rsubDel.split("|"),x=rday(d).tasks[+i],q=x?.subtasks?.[+j];if(q)askConfirm("Remove Subtask?",`Remove “${q.name}” from ${x.name}?`,{kind:"routineSubRemove",day:d,index:+i,subIndex:+j},"Remove Subtask");return}
 if(t.dataset.wokeLate){uiSheet={type:"wake",day:t.dataset.wokeLate};render();return}
 if(t.dataset.addErrand){uiSheet={type:"errand",day:t.dataset.addErrand};render();return}
 if(t.dataset.rstart){uiSheet={type:"wake",day:t.dataset.rstart};render();return}
 if(t.dataset.invTab){state.inventoryTab=t.dataset.invTab;save();render();return}
 if(t.hasAttribute("data-inv-search")){state.inventorySearch=(document.getElementById("inventorySearch")?.value||"").trim();save();render();return}
 if(t.hasAttribute("data-inv-clear")){state.inventorySearch="";save();render();return}
 if(t.dataset.invSoon){let [c,i]=t.dataset.invSoon.split("|"),x=state.inventory[c]?.[+i];if(x){x.useSoon=!x.useSoon;save();render()}return}
 if(t.dataset.containerMove!==undefined){let i=+t.dataset.containerMove,x=state.inventory.Containers[i];if(x){x.storage="FRIDGE";x.qty=String(x.qty||"").replace("FREEZER","FRIDGE");save();render()}return}
 if(t.dataset.containerEat!==undefined){let i=+t.dataset.containerEat,x=state.inventory.Containers[i];if(x)askConfirm("Mark as Eaten?",`Log “${x.name}” as eaten and remove it from Containers?`,{kind:"containerEat",index:i,date:selectedKey()},"Yes, Eaten");return}
 if(t.dataset.containerDiscard!==undefined){let i=+t.dataset.containerDiscard,x=state.inventory.Containers[i];if(x)askConfirm("Discard Container?",`Log “${x.name}” as discarded and remove it from Containers?`,{kind:"containerDiscard",index:i,date:selectedKey()},"Discard");return}
 if(t.dataset.editInv){let [c,i]=t.dataset.editInv.split("|");uiSheet={type:"invEdit",cat:c,index:+i};render();return}
 if(t.dataset.addInv){let c=t.dataset.addInv,n=document.querySelector(`[data-inv-name="${c}"]`).value.trim(),q=document.querySelector(`[data-inv-qty="${c}"]`).value.trim();if(n){state.inventory[c].push({name:n,qty:q});save();render()}return}
 if(t.dataset.delInv){let [c,i]=t.dataset.delInv.split("|"),x=state.inventory[c]?.[+i];if(!x)return;askConfirm("Remove Inventory Item?",`Remove “${x.name}” from ${c}?`,{kind:"inventoryRemove",cat:c,index:+i},"Remove Item");return}
});
function applyThursdayRoutineV44(){
 const mark="migration|thursdayRoutineV44|2026-09-29";if(state.checks?.[mark])return;
 state.checks=state.checks||{};state.routineV2=state.routineV2||{};state.routineDates=state.routineDates||{};
 delete state.routineV2.Thursday;
 /* v56: preserve dated Thursday routine history; only the reusable Thursday template is rebuilt */
 state.checks[mark]=true;save();
}
applyThursdayRoutineV44();

function applyThursdayCareMergeV50(){
 const mark="migration|thursdayCareMergeV50|2026-09-29";
 if(state.checks?.[mark])return;
 state.checks=state.checks||{};state.routineV2=state.routineV2||{};state.routineDates=state.routineDates||{};
 delete state.routineV2.Thursday;
 /* v56: preserve dated Thursday routine history; only the reusable Thursday template is rebuilt */
 state.checks[mark]=true;save();
}
applyThursdayCareMergeV50();

const V48_SYSTEM_AUDIT={autopayEdit:"Per-occurrence amount override flows through week, month, emergency/rent projection and paid live-balance correction",loggingConnections:"Routine, care, water, faith, goals, study, body, run, gym, food, containers, cooking, grocery, inventory, budget, wish and history remain on the shared saved state"};

// ===== FULL SYSTEM RUN v75 — accumulated approved fixes =====
state.treadmill=state.treadmill&&typeof state.treadmill==="object"?state.treadmill:{};
state.budget.paymentEvents=state.budget.paymentEvents&&typeof state.budget.paymentEvents==="object"?state.budget.paymentEvents:{};
state.cookComponents=state.cookComponents&&typeof state.cookComponents==="object"?state.cookComponents:{};
state.nutritionCatalog=state.nutritionCatalog&&typeof state.nutritionCatalog==="object"?state.nutritionCatalog:{};

function applySep30InventoryTruthV75(){
 const mark="migration|fullRunV75|2026-09-30"; if(state.checks[mark])return;
 const inv=state.inventory;
 const remove=(cat,re)=>{inv[cat]=(inv[cat]||[]).filter(x=>!re.test(String(x.name||"")))};
 const upsert=(cat,name,rec)=>{let a=inv[cat]||(inv[cat]=[]),x=a.find(z=>String(z.name||"").toLowerCase()===name.toLowerCase());if(x)Object.assign(x,rec,{name});else a.push({name,...rec})};
 remove("Pantry",/Joseph.?s pita|Sourdough/i);
 remove("Seasonings",/^RESTOCK — (Nature|black pepper|cinnamon sugar|cream of tartar|garlic powder|garlic salt|ground ginger|Italian seasoning)/i);
 upsert("Fridge","La Legume celery",{qty:"665 g prepared/cut",expires:"Estimated ~Oct 7, 2026",expiryType:"ESTIMATED USE WINDOW",useSoon:true,notes:"No printed date • weighed after cutting/prep 9/30/26"});
 upsert("Fridge","Baby carrots",{qty:"1 lb",expires:"Oct 17, 2026",expiryType:"PRINTED DATE",notes:"Brand recorded from haul as Cal-Organic Farms / voice confirmation"});
 upsert("Fridge","Bananas",{qty:"2",notes:"Purchased 9/30/26 • still partly green"});
 upsert("Fridge","Rosemary-garlic loaf",{qty:"1 loaf",expires:"Oct 3, 2026",expiryType:"SELL BY",useSoon:true,notes:"Packed Sep 28, 2026 • current bread; sourdough is out"});
 upsert("Freezer","Great Value frozen cauliflower",{qty:"4 bags × ~340 g = ~1,360 g",expires:"May 11, 2028",expiryType:"BEST IF USED BY",notes:"All four bags share printed date"});
 let fc=(inv.Freezer||[]).find(x=>/Frozen chicken/i.test(x.name||""));if(fc){fc.qty="on hand — actual total weight pending";fc.notes="Substantial freezer chicken supply. Weigh actual amount before cooking; never assume 600 g or auto-buy more."}
 upsert("Pantry","Great Value Organic reduced-sodium chicken broth — existing",{qty:"907 g / ~32 oz",notes:"Already in pantry before 9/30 shopping trip • duplicate-prevention inventory"});
 upsert("Pantry","Great Value Organic reduced-sodium chicken broth — new",{qty:"32 oz",expires:"Jul 20, 2027",expiryType:"PRINTED DATE",store:"Walmart",purchasedDate:"2026-09-30",notes:"Purchased 9/30/26; second carton because existing carton was missed by grocery cross-check"});
 upsert("Pantry","Great Value Organic beef broth",{qty:"32 oz",expires:"Dec 25, 2027",expiryType:"PRINTED DATE",store:"Walmart",purchasedDate:"2026-09-30"});
 upsert("Pantry","Royal basmati rice",{qty:"20 lb",expires:"Estimated Mar 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"No printed best-by • this is Emmelli’s regular rice"});
 upsert("Pantry","Snack Factory Pretzel Crisps — Apple Spice White Crème",{qty:"113 g",expires:"Jan 23, 2027",expiryType:"PRINTED DATE"});
 upsert("Pantry","Great Value raw honey",{qty:"32 oz",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"No printed date found"});
 upsert("Pantry","Chick-fil-A Sauce — individual",{qty:"2 × 28 g = 56 g total",notes:"Use naturally with compatible sandwiches/chicken meals before opening/buying another similar sauce"});
 upsert("Seasonings","Morton Nature’s Seasons",{qty:"212 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW"});
 upsert("Seasonings","Cinnamon sugar",{qty:"122 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"Brand not confirmed; keep generic until identified"});
 upsert("Seasonings","Baking powder",{qty:"~460 g total across ~2 containers",expires:"Estimated Sep 30, 2027",expiryType:"ESTIMATED QUALITY WINDOW",notes:"Plenty on hand; includes new 230 g Great Value container"});
 upsert("Seasonings","Baking soda",{qty:"0 — OUT",notes:"Separate ingredient from baking powder; restock only when needed"});
 upsert("Seasonings","Ground cloves",{qty:"51 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"Brand not confirmed"});
 upsert("Seasonings","Italian seasoning",{qty:"27 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"Brand not confirmed"});
 upsert("Seasonings","Great Value garlic powder",{qty:"96 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW"});
 upsert("Seasonings","Garlic salt",{qty:"85 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"Brand not confirmed"});
 upsert("Seasonings","Great Value black pepper",{qty:"170 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW"});
 upsert("Seasonings","Ground ginger",{qty:"42 g",expires:"Estimated Sep 30, 2028",expiryType:"ESTIMATED QUALITY WINDOW",notes:"Brand not confirmed"});
 upsert("Seasonings","Cream of tartar",{qty:"on hand",notes:"Confirmed on hand; not a restock"});
 let eggs=(inv.Fridge||[]).find(x=>/^Eggs$/i.test(x.name||""));if(eggs)eggs.qty="6";
 let cabot=(inv.Fridge||[]).find(x=>/Cabot sliced cheddar/i.test(x.name||""));if(cabot)cabot.qty="3 slices";
 let bacon=(inv.Freezer||[]).find(x=>/Kirkland bacon/i.test(x.name||""));if(bacon)bacon.notes=[bacon.notes,"40 g cooked bacon used at breakfast 9/30; exact remaining pack weight not known"].filter(Boolean).join(" • ");
 state.checks[mark]=true; save();
}
applySep30InventoryTruthV75();

// Oct 1 inventory truth is re-applied inside the canonical cooking script after v7ApplyInventoryCorrections is defined.


// Current meal truth: no sourdough remains; future bread references cannot stay stale.
if(MEAL.days?.["2026-10-02"])MEAL.days["2026-10-02"].breakfast="Bacon + egg + cheddar on the current rosemary-garlic loaf";
if(MEAL.days?.["2026-10-04"])MEAL.days["2026-10-04"].breakfast="Protein oatmeal + ISO100 + berries + chia + Fairlife milk";

// One authoritative inventory lookup used by Grocery + Cooking + Nutrition.
function inventoryFlat(){return ["Fridge","Freezer","Pantry","Seasonings"].flatMap(cat=>(state.inventory[cat]||[]).map((x,i)=>({cat,i,...x})))}
function cleanFoodWords(v){return String(v||"").toLowerCase().replace(/\b\d+(?:\.\d+)?\s*(?:g|kg|ml|l|oz|lb|cups?|tbsp|tsp|x)\b/g," ").replace(/[^a-z]+/g," ").replace(/\b(existing|opened|remaining|dry|raw|frozen|boneless|organic|reduced sodium|large|medium|mild|total|actual|weigh|needed|as needed)\b/g," ").replace(/\s+/g," ").trim()}
function inventoryMatchesIngredient(raw){let q=cleanFoodWords(raw),tokens=q.split(" ").filter(x=>x.length>2);if(!tokens.length)return[];return inventoryFlat().filter(x=>{let n=cleanFoodWords(x.name);if(/\bchicken\b/.test(q)&&/\bchicken\b/.test(n)&&!/broth|stock/.test(q+n))return true;if(/chicken (broth|stock)|(broth|stock).*chicken/.test(q)&&/chicken (broth|stock)|(broth|stock).*chicken/.test(n))return true;if(/beef broth/.test(q)&&/beef broth/.test(n))return true;let hits=tokens.filter(t=>n.includes(t)).length;return hits>=Math.min(2,tokens.length)}).filter(x=>!/\b0\s*—\s*out\b/i.test(x.qty||""))}
function groceryCoverage(raw){let m=inventoryMatchesIngredient(raw);if(!m.length)return null;let unknown=m.some(x=>/pending|unknown|on hand/i.test(x.qty||""));return {matches:m,unknown,summary:m.slice(0,2).map(x=>`${x.name} • ${x.qty||"qty not entered"}`).join(" / ")}}

const _groceryV75=grocery;
grocery=function(){
 let g=MEAL.grocery||{},isMonday=DAYS[state.day]==="Monday";state.groceryCustom=state.groceryCustom||{};let stores=["Walmart","Detwiler’s"].filter(x=>Array.isArray(g[x]));if(!isMonday)return _groceryV75();let totals={};stores.forEach(store=>{let arr=(g[store]||[]).filter(x=>!/^NO BUY/i.test(String(x))),custom=state.groceryCustom[store]||[];totals[store]=arr.reduce((a,x,i)=>groceryCoverage(x)?a:a+Math.max(0,Number(state.groceryPrices[groceryPriceKey(store,x)]??state.groceryPrices[store+"|"+i]??groceryEstimate(store,x))||0),0)+custom.reduce((a,x)=>a+Math.max(0,Number(x.price)||0),0)});let grand=stores.reduce((a,x)=>a+totals[x],0);
 return hero("Grocery List","Monday")+back("Food")+`<section class="card grocery-total-card"><div><span class="muted">ESTIMATED SHORTAGE TOTAL</span><div class="metric money">${money(grand)}</div></div><div class="store-mini-totals">${stores.map(x=>`<span><b>${esc(x)}</b> ${money(totals[x])}</span>`).join("")}</div><p class="muted">INVENTORY IS CHECKED FIRST. ON-HAND ITEMS ARE NOT COUNTED IN THE BUY TOTAL. IF QUANTITY IS UNKNOWN, WEIGH/CHECK IT BEFORE BUYING MORE.</p></section>${stores.map(store=>{let arr=(g[store]||[]).filter(x=>!/^NO BUY/i.test(String(x))),custom=state.groceryCustom[store]||[];return `<section class="card"><div class="row between"><h2>${esc(store)}</h2><b>${money(totals[store])}</b></div>${arr.map((x,i)=>{let key=`grocery|${store}|${i}`,have=`groceryHave|${store}|${i}`,cov=groceryCoverage(x),saved=state.groceryPrices[groceryPriceKey(store,x)]??state.groceryPrices[store+"|"+i],val=saved??groceryEstimate(store,x);if(cov){state.checks[have]=true;return `<div class="grocery-row clean-grocery"><div><b>${esc(x)}</b><div class="inventory-match"><b>${cov.unknown?"ON HAND — VERIFY QUANTITY BEFORE BUYING":"COVERED BY INVENTORY — DO NOT BUY"}</b><br><small>${esc(cov.summary)}</small></div></div><span class="paid-tag">$0 TO BUY</span></div>`}return `<div class="grocery-row clean-grocery"><div style="flex:1">${checkbox(key,x)}<div class="grocery-mini-actions"><label class="already-have"><input type="checkbox" data-grocery-have="${esc(store)}|${i}" ${state.checks[have]?"checked":""}> ALREADY HAVE</label></div></div><label class="price-est">EST. PRICE<input type="number" min="0" step=".01" data-grocery-price="${esc(store)}|${i}" value="${esc(val)}"></label></div>`}).join("")}${custom.map((x,i)=>`<div class="grocery-row"><b>${esc(x.item)}</b><span>${money(x.price)}</span></div>`).join("")}</section>`}).join("")}<section class="card soft after-home"><h2>After You Get Home</h2><p class="muted">Only confirmed purchases move into Inventory. The original grocery specification follows the item so you do not re-enter it.</p><button class="btn primary" data-grocery-to-inventory>ADD CONFIRMED PURCHASES</button></section>`;
}

// Routine: preserve canonical schedule order. Morning Care stays where the seven-day routine places it.
function careCategoryName(name){let n=String(name||"").toUpperCase();if(/RETAINER/.test(n))return "Retainer";if(/ORAL CARE|WATER FLOSS|BRUSH|TONGUE|STRING FLOSS|LIP STAIN/.test(n))return "Oral Care";if(/GUA SHA/.test(n))return "Gua Sha";if(/SKINCARE|CLEANSER|TONER|SNAIL|CICA|SERUM|MOISTURIZER|SPF/.test(n))return "Skincare";if(/CLEAN EARS/.test(n))return "Clean Ears";if(/PINK CREAM|UREA/.test(n))return "Pink Cream + Urea";if(/COLLARS|REMOTES/.test(n))return "Collars + Remotes";if(/HAIR|MINOXIDIL|CASTOR|OIL ENDS|STYLE/.test(n))return "Hair Care";if(/DEODORANT|PERFUME|JEWELRY/.test(n))return "Deodorant + Perfume + Jewelry";if(/HAND|NAIL|CUTICLE/.test(n))return "Hands + Nails";if(/DISINFECT PHONE/.test(n))return "Phone";return "Body + Get Ready"}
function careCategoryMarkup(t,d,i){let groups={};(t.subtasks||[]).forEach((q,j)=>{let c=careCategoryName(q.name);(groups[c]||(groups[c]=[])).push({q,j})});let order=["Retainer","Oral Care","Gua Sha","Skincare","Clean Ears","Pink Cream + Urea","Collars + Remotes","Hair Care","Deodorant + Perfume + Jewelry","Hands + Nails","Phone","Body + Get Ready"];return order.filter(c=>groups[c]?.length).map(c=>{let a=groups[c],done=a.filter(z=>z.q.done).length;return `<details class="care-category" data-care-category="${esc(c)}"><summary><span>${esc(c)}</span><span class="category-count">${done}/${a.length}${done===a.length?" ✓":""}</span></summary><div class="subtasks">${a.map(({q,j})=>`<div class="subrow"><input type="checkbox" aria-label="${esc(q.name)} complete" data-rsub-check="${d}|${i}|${j}" ${q.done?"checked":""}><span class="sub-name">${esc(q.name)}</span><button class="tinybtn icon-action" data-rsub-edit="${d}|${i}|${j}">Edit</button></div>`).join("")}</div></details>`}).join("")}
function enhancedRoutineComment(d,tl){let complete=tl.filter(x=>x.t.done).length,total=tl.length,open=tl.filter(x=>!x.t.done),msg=`${complete}/${total} routine blocks complete`;if(open.length)msg+=` • ${total-complete} left. Next: ${open[0].t.name}.`;else msg+=" • Routine complete.";let mc=tl.find(x=>x.t.id==="careM");if(mc){let groups={};(mc.t.subtasks||[]).forEach(q=>{let c=careCategoryName(q.name);(groups[c]||(groups[c]=[])).push(q)});let missing=Object.entries(groups).filter(([c,a])=>a.some(q=>!q.done)).map(([c])=>c);if(missing.length)msg+=` Morning Care still needs: ${missing.slice(0,3).join(", ")}${missing.length>3?" + more":""}.`}if(tl.conflicts?.length)msg+=` Schedule conflict: ${tl.conflicts[0]}.`;return msg}
function captureRoutineOpenDetails(){
 const parent=[...document.querySelectorAll("details.care-parent[open][data-care-parent]")].map(x=>x.dataset.careParent);
 const cats=[...document.querySelectorAll("details.care-parent[open] details.care-category[open][data-care-category]")].map(x=>({parent:x.closest("details.care-parent")?.dataset.careParent,cat:x.dataset.careCategory}));
 return {parent,cats};
}
function restoreRoutineOpenDetails(snap){
 if(!snap)return;
 (snap.parent||[]).forEach(id=>{let el=[...document.querySelectorAll("details.care-parent[data-care-parent]")].find(x=>x.dataset.careParent===id);if(el)el.open=true});
 (snap.cats||[]).forEach(z=>{let p=[...document.querySelectorAll("details.care-parent[data-care-parent]")].find(x=>x.dataset.careParent===z.parent);if(p){p.open=true;let c=[...p.querySelectorAll("details.care-category[data-care-category]")].find(x=>x.dataset.careCategory===z.cat);if(c)c.open=true}});
}
routine=function(){
 let d=DAYS[state.day],rd=rday(d),tl=timeline(d),isToday=selectedKey()===localDateKey(),mins=isToday?new Date().getHours()*60+new Date().getMinutes():-1;let next=isToday?(tl.find(x=>!x.t.done&&x.en>=mins)||tl.find(x=>!x.t.done)):tl.find(x=>!x.t.done),now=isToday?(tl.find(x=>!x.t.done&&mins>=x.st&&mins<x.en)||next):next;let nowIndex=now?tl.indexOf(now):-1,nextItem=now?tl.slice(nowIndex+1).find(x=>!x.t.done):null;let sections=routineSectionOrder(d,[...new Set(tl.map(x=>x.t.section))]),open=sections.includes(rd.open)?rd.open:sections[0],shown=tl.filter(x=>x.t.section===open),tabs=sections.map(x=>`<button class="sectionTab ${x===open?"on":""}" data-rsection="${esc(x)}">${esc(x)}</button>`).join("");
 let cards=shown.map(x=>{const isCare=x.t.id==="careM"||x.t.id==="careN";if(isCare){let actionable=(x.t.subtasks||[]).filter(q=>!careIsHeadingV84(q.name)),cnt=actionable.filter(q=>q.done).length,total=actionable.length;return `<details class="taskcard care-parent" data-care-parent="${x.t.id}"><summary class="care-parent-summary"><span class="care-check-wrap" onclick="event.stopPropagation()"><input class="taskcheck" type="checkbox" data-rtask-check="${d}|${x.i}" ${x.t.done?"checked":""}></span><span class="care-summary-copy"><b>${esc(x.t.name)}</b><small>${fmt(x.st)}–${fmt(x.en)} • ${x.t.duration} MIN</small></span><span class="care-summary-count">${cnt}/${total}</span><span class="care-chevron"></span></summary><div class="care-dropdown-body">${careCategoryMarkup(x.t,d,x.i)}<div class="routine-maintenance"><button class="tinybtn" data-rsub-add="${d}|${x.i}">+ Care Item</button></div></div></details>`}
 let subs=x.t.subtasks||[];if(subs.length){let dc=subs.filter(q=>q.done).length;return `<details class="taskcard"><summary class="care-parent-summary"><span class="care-check-wrap" onclick="event.stopPropagation()"><input class="taskcheck" type="checkbox" data-rtask-check="${d}|${x.i}" ${x.t.done?"checked":""}></span><span class="care-summary-copy"><b>${esc(x.t.name)}</b><small>${fmt(x.st)}–${fmt(x.en)} • ${x.t.duration} MIN</small></span><span class="care-summary-count">${dc}/${subs.length}</span></summary><div class="care-dropdown-body"><div class="subtasks">${subs.map((q,j)=>`<div class="subrow"><input type="checkbox" data-rsub-check="${d}|${x.i}|${j}" ${q.done?"checked":""}><span class="sub-name">${esc(q.name)}</span><button class="tinybtn" data-rsub-edit="${d}|${x.i}|${j}">Edit</button></div>`).join("")}</div></div></details>`}
 return `<div class="taskcard"><div class="taskhead"><input class="taskcheck" type="checkbox" data-rtask-check="${d}|${x.i}" ${x.t.done?"checked":""}><div class="task-title-copy"><b>${esc(x.t.name)}</b><div class="tasktime">${fmt(x.st)}–${fmt(x.en)} • ${x.t.duration} min${x.anchor?" • FIXED TIME":""}${x.conflict?" • CONFLICT":""}</div></div><button class="tinybtn" data-rtask-edit="${d}|${x.i}">Edit</button></div></div>`}).join("");
 return hero("Routine",d)+back("Today")+`<section class="card" style="border:2px solid var(--accent);background:var(--soft)"><b>ROUTINE BUILD • SLEEP + 90-MIN COOKING</b><p style="margin:6px 0 0"><b>WEDNESDAY:</b> Wake 5:10 AM • Cooking 7:35–9:05 AM • Pack 2:15–2:20 PM • Drive to Work 2:20–3:00 PM<br><b>THURSDAY:</b> Wake 7:46 AM • Cooking 10:10–11:40 AM • Pack 2:15–2:20 PM • Drive to Work 2:20–3:00 PM</p></section><section class="card soft"><div class="nowgrid"><div class="nowbox"><span class="muted">NOW</span><b>${esc(now?now.t.name:"Routine complete")}</b></div><div class="nowbox"><span class="muted">NEXT</span><b>${esc(nextItem?.t.name||"Nothing next")}</b></div></div><div class="comment-widget routine-commentary" style="margin-top:12px"><p>${esc(enhancedRoutineComment(d,tl))}</p></div><div class="app-actions"><button class="btn" data-woke-late="${d}">I WOKE UP LATE</button><button class="btn" data-add-errand="${d}">ADD AN ERRAND</button></div></section><section class="card"><div class="row between"><h2 style="margin:0">Routine Sections</h2><button class="btn" data-copy-routine>Copy Routine</button></div><div class="wake-time-strip"><span>WAKE TIME</span><b>${fmt((d==="Wednesday"||d==="Thursday")?rd.start:(state.routineStarts[selectedKey()]??rd.start))}</b><small>DISPLAY ONLY</small></div><div class="sectionTabs">${tabs}</div>${cards||'<p class="muted">No blocks in this section.</p>'}</section>`
}

function dayReceiptStatus(){let d=DAYS[state.day],k=selectedKey(),tl=timeline(d),missing=[],done=0,total=0;const req=(ok,label)=>{total++;if(ok)done++;else missing.push(label)};tl.forEach(x=>req(!!x.t.done,`Routine → ${x.t.name}`));[1,2,3,4,5].forEach(i=>req(!!state.water[k+"|"+i],`Water bottle ${i}`));req(!!state.checks[`daily|${k}|vitamins`],"Vitamins");req(!!state.checks[`daily|${k}|creatine`],"Creatine");req(hasStudy(k),`Study → ${STUDY[d]}`);req(hasBible(k),"Bible + Faith reflection");req(hasWeight(k),"Daily weigh-in");let food=(state.foodHistory||[]).some(x=>(x.date||"").slice(0,10)===k)||hasMacros(k);req(food,"What I Actually Ate");if(DAY_ACTIVITY[d]==="GYM"){req(hasGym(k),"Gym workout actuals");let tr=state.treadmill[k]||{};req(Number(tr.duration)>0,"Treadmill actuals")}if(DAY_ACTIVITY[d]==="RUN")req(hasRun(k),"Run actuals");if(d==="Monday")req(hasMeasure(k),"Monday measurements");let cooks=(todayMeal()?.cook||[]).filter(n=>!/^\s*PAUSED\s*:/i.test(String(n||"")));cooks.forEach(n=>{let rn=cookRecipeName(n);req(!!state.cookLog[k+"|"+rn],`Cooking → ${rn}`)});return {done,total,missing,pct:total?Math.round(done/total*100):100}}
const _todayV75=today;
today=function(){let html=_todayV75(),s=dayReceiptStatus(),k=selectedKey(),open=!!state.checks[`ui|receipt|${k}`],comment=[];let tl=timeline(DAYS[state.day]),left=tl.filter(x=>!x.t.done);comment.push(left.length?`${left.length} routine block${left.length===1?"":"s"} left; next is ${left[0].t.name}.`:"Routine is complete.");if(s.missing.length)comment.push(`${s.missing.length} receipt item${s.missing.length===1?"":"s"} still need information.`);else comment.push("Your day record has everything it needs.");let goals=openGoalsThroughSelectedDay(k);if(goals.length)comment.push(`Goal: ${goals.map(g=>g.text).join(" • ")}.`);html=html.replace(/<section class="comment-widget"><p>[\s\S]*?<\/p><\/section>/,`<section class="comment-widget"><p>${esc(comment.join(" "))}</p></section>`);html+=`<section class="card day-receipt"><button class="btn primary" data-toggle-day-receipt><span><b>DAY RECEIPT • ${s.pct}% COMPLETE</b><br><small>${s.missing.length?`${s.missing.length} thing${s.missing.length===1?"":"s"} still missing`:"READY • COMPLETE DAY RECORD"}</small></span><span>${open?"▲":"▼"}</span></button>${open?`<div class="receipt-list">${s.missing.length?s.missing.map(x=>`<div class="receipt-missing">${esc(x)}</div>`).join(""):'<div class="receipt-good">Everything required for today’s receipt is filled out.</div>'}</div>`:""}</section>`;return html}

// Shared product/nutrition identity.
function inventoryNutritionMatch(raw){return inventoryMatchesIngredient(raw)[0]||null}
const RECIPE_COMPONENTS={
 "Ham & Lentil Soup":[{id:"main",label:"SOUP",ix:[0,1,2,3,4,5,6,7,8,9]}],
 "Chicken Cobbler":[{id:"main",label:"CHICKEN + GRAVY FILLING",ix:[0,1,2,3,4,5,6,7]},{id:"side",label:"COBBLER TOPPING",ix:[8,9,10,11,12,13]}],
 "Cheesy Cottage Pie":[{id:"main",label:"GROUND-CHICKEN FILLING",ix:[0,2,3,4,5,6,7,8,9,10]},{id:"side",label:"CHEESY POTATO MASH",ix:[1,10,11,12]}],
 "Chicken & Dumplings":[{id:"main",label:"CHICKEN + GRAVY",ix:[0,1,2,3,4,5,6,9]},{id:"side",label:"DUMPLINGS",ix:[6,7,8,9,10,11]}],
 "Marry Me Chicken Meatballs":[{id:"main",label:"MEATBALL MIX",ix:[0,1,2,3,4,5,7]},{id:"side",label:"SAUCE",ix:[3,4,6,8,9,10,11,12]},{id:"pasta",label:"PASTA",ix:[13]}],
 "Beef & Broccoli Garlic Noodles":[{id:"main",label:"BEEF + BROCCOLI NOODLES",ix:[0,1,2,3,4,5,6,7,8,9]}]
};
function recipeComponentDefs(rn,r){return RECIPE_COMPONENTS[rn]||[{id:"main",label:"MAIN MIX",ix:(r?.ingredients||[]).map((_,i)=>i)}]}
function ingredientAutoInfo(raw,rn,ii){let hit=inventoryNutritionMatch(raw),saved=state.nutritionFacts?.[rn+"|"+ii]||{},brand=hit?.brand||hit?.name||"Generic / not yet linked",nut=hit?.nutrition||saved;return {hit,brand,nut}}



// Component-aware nutrition engine: recipe source/mix boundaries drive macros, not UI labels alone.
function actualWeighedIngredientMacros(recipeName,idx){let r=MEAL.recipes?.[recipeName],txt=String(r?.ingredients?.[idx]||"").toLowerCase(),key=selectedKey()+"|"+recipeName,g=Number((state.cookDraft[key]||{})["ingredient"+idx]);if(!(g>0))return null;let per100=null;if(/chicken/.test(txt)&&!/broth|stock/.test(txt))per100={calories:165,protein:31,carbs:0,fat:3.6,fiber:0};else if(/ham/.test(txt))per100={calories:145,protein:21,carbs:1.5,fat:5.5,fiber:0};if(!per100)return null;return addMacros(emptyMacros(),per100,g/100)}
recipeNutrition=function(recipeName){let r=MEAL.recipes?.[recipeName],key=selectedKey()+"|"+recipeName,adj=state.cookAdjustments?.[key]||{},components={main:emptyMacros(),side:emptyMacros()},unknown=[],defs=recipeComponentDefs(recipeName,r),ixMap={};defs.forEach(c=>c.ix.forEach(i=>ixMap[i]=c.id==="main"?"main":"side"));(r?.ingredients||[]).forEach((txt,i)=>{let base=actualWeighedIngredientMacros(recipeName,i)||ingredientMacroBase(recipeName,i),change=adj.ingredients?.[i]||{},removed=/remove/i.test(String(change.amount||""))||/remove/i.test(String(change.name||""));if(!base){unknown.push(i);base=emptyMacros()}if(removed)base=emptyMacros();let delta={};for(let m of ["calories","protein","carbs","fat","fiber"])delta[m]=Number(change[m])||0;base=addMacros(base,delta);let component=ixMap[i]||"main";components[component]=addMacros(components[component],base)});return {components:{main:roundMacros(components.main),side:roundMacros(components.side)},unknown}}

// Gym treadmill actuals editable on gym days.
const _gymV75=gym;
gym=function(){let html=_gymV75();if(!GYM_PLAN[DAYS[state.day]]||state.sub)return html;let k=selectedKey(),t=state.treadmill[k]||{};let panel=`<details class="info-accordion" open><summary>TREADMILL • ACTUALS</summary><div><p class="muted">PLAN: 30 MIN • SPEED 3.0 • INCLINE 5–6. EDIT WHAT YOU ACTUALLY DID.</p><div class="treadmill-grid"><label>Incline<input id="tmIncline" type="number" min="0" step=".1" value="${esc(t.incline??"")}"></label><label>Speed<input id="tmSpeed" type="number" min="0" step=".1" value="${esc(t.speed??"")}"></label><label>Time completed (min)<input id="tmDuration" type="number" min="0" step="1" value="${esc(t.duration??"")}"></label><label>Distance (optional)<input id="tmDistance" type="number" min="0" step=".01" value="${esc(t.distance??"")}"></label></div><button class="btn primary" data-save-treadmill>SAVE TREADMILL ACTUALS</button></div></details>`;html=html.replace(/<details class="info-accordion"><summary>TREADMILL<\/summary>[\s\S]*?<\/details>/,panel);return html}

// Budget: source-separated income + information-first All Autopays + actual payment dates.
function incomeSourceKey(date,source){return `incomeSource|${localDateKey(date)}|${source}`}
function allAutopayRows(y,m){let rows=monthRows(y,m).map(x=>({...x,rollover:false})),ny=m===11?y+1:y,nm=(m+1)%12;monthRows(ny,nm).filter(x=>x.date.getDate()<=7).forEach(x=>rows.push({...x,rollover:true}));return rows.sort((a,b)=>a.date-b.date)}
function allAutopaysPanel(y,m){let open=!!state.checks[`ui|autopays|${y}-${m}`],rows=allAutopayRows(y,m);return `<section class="card information-first"><button class="tile" data-toggle-autopays="${y}|${m}"><b>ALL AUTOPAYS</b><span>Every dated autopay • rollover • paid date • edit • unresolved dates shown separately</span></button>${open?`<div style="margin-top:10px">${rows.map(x=>{let scheduledAmt=x.n==="Rent"?rentAmountForDue(x.date):effectiveAutopayAmount(x),key=autopayKey(x),paid=!!state.checks[key],ev=state.budget.paymentEvents[key]||{},amt=paid&&Number.isFinite(Number(ev.amount))?Math.round(Number(ev.amount)*100)/100:scheduledAmt;return `<div class="autopay-row-v75"><input type="checkbox" data-budget-occurrence="bill|${esc(key)}|${amt}" ${paid?"checked":""}><div class="autopay-primary"><b>${esc(x.n)}</b><span>${x.date.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})} • ${money(amt)}${x.rollover?" • ROLLOVER":""}</span>${paid?`<label class="actual-date">ACTUAL PAID / HIT DATE <input type="date" data-payment-date="${esc(key)}" value="${esc(ev.actualDate||ev.checkedDate||localDateKey())}"></label>`:""}</div><div class="autopay-actions">${paid?'<span class="paid-tag">PAID ✓</span>':''}<button class="tinybtn autopay-edit" data-edit-autopay="${encodeURIComponent(localDateKey(x.date))}|${encodeURIComponent(x.n)}|${encodeURIComponent(String(x.baseA??x.a))}">Edit</button></div></div>`}).join("")||'<p class="muted">No dated autopays in this range.</p>'}<div class="month-note"><b>UNRESOLVED / NEEDS ACTUAL DATE</b>${UNDATED_BILLS.map(([n,a])=>`<span>${esc(n)} • ${money(a)} monthly • excluded from dated cash-flow projections until a real billing date is entered/confirmed</span>`).join("")}</div></div>`:""}</section>`}
// Inventory gets shared nutrition/product lookup without becoming the page's main focus.
const _inventoryV75=inventory;
inventory=function(){let html=_inventoryV75(),q=String(state.nutritionLookupQuery||""),hits=q?inventoryFlat().filter(x=>`${x.name} ${x.qty||""}`.toLowerCase().includes(q.toLowerCase())).slice(0,12):[];let panel=`<details class="card soft"><summary><b>NUTRITION / PRODUCT LOOKUP</b></summary><p class="muted">SEARCH THE SAME LIVE INVENTORY USED BY RECIPES. LINK BRAND/GENERIC NUTRITION ONCE SO COOKING + CONTAINERS CAN REUSE IT.</p><div class="row"><input id="nutritionInventorySearch" placeholder="Search product, brand, generic food" value="${esc(q)}"><button class="btn" data-search-nutrition-inventory>SEARCH</button></div><div class="nutrition-lookup-results">${hits.map(x=>`<div class="nutrition-hit"><b>${esc(x.name)}</b><br><small>${esc(x.cat)} • ${esc(x.qty||"quantity not entered")}</small><br><button class="tinybtn" data-open-inventory-nutrition="${x.cat}|${x.i}">Nutrition</button>${state.checks[`nutritionOpen|${x.cat}|${x.i}`]?`<div class="macro-edit">${["calories","protein","carbs","fat","fiber"].map(m=>`<label>${m.toUpperCase()}<input type="number" min="0" step=".1" data-inventory-nutrition="${x.cat}|${x.i}|${m}" value="${esc(x.nutrition?.[m]??"")}" placeholder="per saved serving"></label>`).join("")}<label>Serving grams<input type="number" min="0" step=".1" data-inventory-nutrition="${x.cat}|${x.i}|servingGrams" value="${esc(x.nutrition?.servingGrams??"")}"></label></div>`:""}</div>`).join("")}</div></details>`;return html.replace(back("Food"),back("Food")+panel)}

// Secondary event layer for new synchronized controls.
document.addEventListener("click",e=>{let t=e.target.closest?.("button,input[type=checkbox]");if(!t)return;
 if(t.hasAttribute("data-toggle-day-receipt")){let k=`ui|receipt|${selectedKey()}`;state.checks[k]=!state.checks[k];save();render();return}
 if(t.dataset.rsubCheck){let [d,i]=t.dataset.rsubCheck.split("|"),x=rday(d).tasks[+i];if(x?.id==="careM"){let st=state.routineStatus[selectedKey()]||(state.routineStatus[selectedKey()]={});st[x.id]=(x.subtasks||[]).some(q=>!careIsHeadingV84(q.name))&&(x.subtasks||[]).filter(q=>!careIsHeadingV84(q.name)).every(q=>!!st[x.id+"|"+q.id]);saveRoutineSnapshot(d);save();render()}return}
 if(t.hasAttribute("data-save-treadmill")){let k=selectedKey(),vals={incline:Math.max(0,Number(document.getElementById("tmIncline")?.value)||0),speed:Math.max(0,Number(document.getElementById("tmSpeed")?.value)||0),duration:Math.max(0,Number(document.getElementById("tmDuration")?.value)||0),distance:Math.max(0,Number(document.getElementById("tmDistance")?.value)||0)};if(Object.values(vals).every(v=>v===0))delete state.treadmill[k];else state.treadmill[k]=vals;save();render();showToast("Treadmill actuals saved.","Gym");return}
 if(t.dataset.cookComponentPlanned!==undefined){let [ri,cid]=t.dataset.cookComponentPlanned.split("|"),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||""),key=selectedKey()+"|"+rn;state.cookComponents[key]=state.cookComponents[key]||{};state.cookComponents[key][cid]=state.cookComponents[key][cid]||{};state.cookComponents[key][cid].usedPlanned=!!t.checked;save();let card=t.closest(".component-card"),count=card?.querySelector(".category-count");if(count)count.textContent=t.checked?"USED AS PLANNED ✓":"CHECK / EDIT";return}
 if(t.dataset.toggleAutopays){let [y,m]=t.dataset.toggleAutopays.split("|"),k=`ui|autopays|${y}-${m}`;state.checks[k]=!state.checks[k];save();render();return}
 
 if(t.hasAttribute("data-search-nutrition-inventory")){state.nutritionLookupQuery=(document.getElementById("nutritionInventorySearch")?.value||"").trim();save();render();return}
 if(t.dataset.openInventoryNutrition){let [c,i]=t.dataset.openInventoryNutrition.split("|"),k=`nutritionOpen|${c}|${i}`;state.checks[k]=!state.checks[k];save();render();return}
});
document.addEventListener("change",e=>{let el=e.target;
 if(el.dataset.cookComponentTotal!==undefined){let [ri,cid]=el.dataset.cookComponentTotal.split("|"),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||""),key=selectedKey()+"|"+rn,v=el.value===""?"":Math.max(0,Number(el.value)||0);state.cookComponents[key]=state.cookComponents[key]||{};state.cookComponents[key][cid]=state.cookComponents[key][cid]||{};state.cookComponents[key][cid].total=v;let d=state.cookDraft[key]||(state.cookDraft[key]={});if(cid==="main"){if(v==="")delete d.main;else d.main=v}else{if(v==="")delete d.side;else d.side=v}save();let box=document.querySelector(`[data-portion-suggest="${ri}"]`);if(box){let count=Math.max(1,cookAssignments(rn).length),m=Number(d.main),sd=Number(d.side);box.innerHTML=`<b>MAKE ${count} ${esc(rn.toUpperCase())} CONTAINER${count===1?"":"S"}</b><br><span class="muted">LIVE SUGGESTED WEIGHT PER CONTAINER</span><br>MAIN: ${Number.isFinite(m)&&m>0?(m/count).toFixed(1)+" g":"—"}${Number.isFinite(sd)&&sd>0?` • SIDE: ${(sd/count).toFixed(1)} g`:""}`}return}
 if(el.dataset.paymentDate){let key=el.dataset.paymentDate;if(validDateKeyRaw(el.value)){state.budget.paymentEvents[key]=state.budget.paymentEvents[key]||{};state.budget.paymentEvents[key].actualDate=el.value;save()}return}
 if(el.dataset.inventoryNutrition){let [c,i,f]=el.dataset.inventoryNutrition.split("|"),x=state.inventory[c]?.[+i];if(x){x.nutrition=x.nutrition||{};x.nutrition[f]=el.value===""?"":Math.max(0,Number(el.value)||0);save()}return}
});

// The MON–SUN strip uses native horizontal scrolling. Week changes are explicit via the previous/next controls so a finger-scroll cannot accidentally change the selected week.

// ===== v82 COMPONENT / CONTAINER ACCURACY LAYER =====
state.finishedComponents=state.finishedComponents&&typeof state.finishedComponents==="object"?state.finishedComponents:{};
state.containerDrafts=state.containerDrafts&&typeof state.containerDrafts==="object"?state.containerDrafts:{};
function componentStateKey(rn,cid){return selectedKey()+"|"+rn+"|"+cid}
function componentTotalsFor(rn){let r=MEAL.recipes?.[rn],key=selectedKey()+"|"+rn,cs=state.cookComponents[key]||{},out={};recipeComponentDefs(rn,r).forEach(c=>{let v=Number(cs[c.id]?.total);out[c.id]=Number.isFinite(v)&&v>0?v:null});return out}
function componentNutritionV82(rn){let r=MEAL.recipes?.[rn],key=selectedKey()+"|"+rn,adj=state.cookAdjustments?.[key]||{},defs=recipeComponentDefs(rn,r),out={},unknown=[];defs.forEach(c=>out[c.id]=emptyMacros());(r?.ingredients||[]).forEach((txt,i)=>{let comp=defs.find(c=>c.ix.includes(i))||defs[0],change=adj.ingredients?.[i]||{},removed=/remove/i.test(String(change.amount||""))||/remove/i.test(String(change.name||""));if(removed)return;let manual={},hasManual=false;for(let m of ["calories","protein","carbs","fat","fiber"]){if(change[m]!==undefined&&change[m]!==""){manual[m]=Number(change[m])||0;hasManual=true}}let base=hasManual?manual:(actualWeighedIngredientMacros(rn,i)||linkedInventoryIngredientMacrosV103(rn,i,change)||ingredientMacroBase(rn,i));if(base&&!hasManual&&String(change.amount||"").trim()){let sc=changedIngredientScaleV100(txt,change.amount);if(sc!=null)base=addMacros(emptyMacros(),base,sc)}if(!base){unknown.push({component:comp.id,index:i,name:txt});base=emptyMacros()}out[comp.id]=addMacros(out[comp.id],base)});Object.keys(out).forEach(k=>out[k]=roundMacros(out[k]));return {components:out,unknown}}
recipeNutrition=componentNutritionV82;
function componentMacroPerGram(rn,cid){let n=componentNutritionV82(rn),total=componentTotalsFor(rn)[cid],m=n.components[cid]||emptyMacros();if(!(total>0))return null;let out={};for(let k of ["calories","protein","carbs","fat","fiber"])out[k]=(Number(m[k])||0)/total;return out}
function macrosForComponentGrams(rn,cid,g){let pg=componentMacroPerGram(rn,cid);if(!pg||!(Number(g)>0))return emptyMacros();return roundMacros(addMacros(emptyMacros(),pg,Number(g)))}
function v82PortionSummary(rn){let r=MEAL.recipes?.[rn],defs=recipeComponentDefs(rn,r),totals=componentTotalsFor(rn),count=Math.max(1,cookAssignments(rn).length);return `<div class="portion-count-banner"><b>MAKE ${count} ${esc(rn.toUpperCase())} CONTAINER${count===1?"":"S"}</b><span>Suggestions only — actual container weights are entered when you build each container.</span></div><div class="suggested-portions">${defs.map(c=>`<div><b>${esc(c.label)}</b> • TARGET ~${totals[c.id]?esc((totals[c.id]/count).toFixed(1))+" g":"enter cooked weight"} EACH</div>`).join("")}</div>`}
function snapshotFinishedComponents(rn){let r=MEAL.recipes?.[rn],n=componentNutritionV82(rn),totals=componentTotalsFor(rn),key=selectedKey()+"|"+rn;recipeComponentDefs(rn,r).forEach(c=>{let grams=totals[c.id];if(!(grams>0))return;state.finishedComponents[componentStateKey(rn,c.id)]={date:selectedKey(),recipe:rn,id:c.id,label:c.label,cookedWeight:grams,totalMacros:n.components[c.id],macrosPerGram:componentMacroPerGram(rn,c.id),nutritionComplete:!n.unknown.some(x=>x.component===c.id),missingNutrition:n.unknown.filter(x=>x.component===c.id).map(x=>x.name),ingredients:c.ix.map(i=>({planned:r.ingredients[i],actual:structuredClone(state.cookAdjustments?.[key]?.ingredients?.[i]||{})})),savedAt:new Date().toISOString()}})}
function containerMacrosV82(rn,ci,weights){let r=MEAL.recipes?.[rn],m=emptyMacros(),missing=[];recipeComponentDefs(rn,r).forEach(c=>{let g=Number(weights[c.id])||0,rec=state.finishedComponents[componentStateKey(rn,c.id)];if(g>0&&rec?.macrosPerGram)m=addMacros(m,rec.macrosPerGram,g);if(g>0&&(!rec||rec.nutritionComplete===false))missing.push(c.label)});let ca=state.cookAdjustments?.[selectedKey()+"|"+rn]?.containers?.[ci]||{};let delta={};for(let k of ["calories","protein","carbs","fat","fiber"])delta[k]=Number(ca[k])||0;return {macros:roundMacros(addMacros(m,delta)),missing}}
const _finishCookingV82=finishCooking;
finishCooking=function(dayIndex,recipeIndex){let rn=cookRecipeName(todayMeal()?.cook?.[recipeIndex]||"");snapshotFinishedComponents(rn);return _finishCookingV82(dayIndex,recipeIndex)};
// Obsolete Cooking renderer wrapper removed during canonical cleanup.




/* v86 actual component additions */
state.componentExtras=state.componentExtras&&typeof state.componentExtras==="object"?state.componentExtras:{};
function componentExtrasV86(rn,cid){let k=selectedKey()+"|"+rn+"|"+cid;return state.componentExtras[k]||(state.componentExtras[k]=[])}
function extraMacrosV86(x){let g=Number(x.grams)||0,n=x.nutrition||{},sg=Number(n.servingGrams)||100,m=emptyMacros();if(!(g>0)||!(sg>0))return m;for(let k of ["calories","protein","carbs","fat","fiber"])m[k]=(Number(n[k])||0)*(g/sg);return m}
const _componentNutritionV86=componentNutritionV82;
componentNutritionV82=function(rn){let z=_componentNutritionV86(rn),r=MEAL.recipes?.[rn];recipeComponentDefs(rn,r).forEach(c=>{componentExtrasV86(rn,c.id).forEach(x=>{if(!x.name||!(Number(x.grams)>0))return;let has=["calories","protein","carbs","fat","fiber"].some(k=>x.nutrition?.[k]!==undefined&&x.nutrition?.[k]!=="");if(!has)z.unknown.push({component:c.id,name:x.name});else z.components[c.id]=roundMacros(addMacros(z.components[c.id]||emptyMacros(),extraMacrosV86(x)))})});return z};
const _cookComponentPanelV86=cookComponentPanel;
cookComponentPanel=function(rn,ri,r,adj){let html=_cookComponentPanelV86(rn,ri,r,adj);let compact=`<details class="ingredient-edit"><summary>+ ADD INGREDIENT TO A COMPONENT</summary><div class="ingredient-edit-body"><p class="muted">Only use this when you actually added something that was not in the planned recipe. Pick its component so its macros and inventory usage go to the right place.</p>${recipeComponentDefs(rn,r).map(c=>`<details class="component-card"><summary>${esc(c.label)} ADDITIONS</summary><div class="component-body"><button class="tinybtn" data-v86-comp-add="${ri}|${esc(c.id)}">+ ADD INGREDIENT</button>${componentExtrasV86(rn,c.id).map((x,ei)=>`<div class="inventory-match"><label>INGREDIENT<input data-v86-comp-extra="${ri}|${esc(c.id)}|${ei}|name" value="${esc(x.name||"")}" placeholder="Ingredient / product"></label><label>ACTUAL GRAMS USED<input type="number" min="0" step=".1" data-v86-comp-extra="${ri}|${esc(c.id)}|${ei}|grams" value="${esc(x.grams??"")}"></label><label>SOURCE<select data-v86-comp-source="${ri}|${esc(c.id)}|${ei}"><option value="">Generic / manual nutrition</option>${inventoryFlat().map(z=>`<option value="${esc(z.cat)}|${z.i}" ${x.source===z.cat+"|"+z.i?"selected":""}>${esc(z.name)} — ${esc(z.cat)}</option>`).join("")}</select></label><button class="tinybtn" data-v90-lookup-comp="${ri}|${esc(c.id)}|${ei}">LOOK UP NUTRITION</button><div class="macro-edit">${["calories","protein","carbs","fat","fiber"].map(k=>`<label>${k.toUpperCase()} / SERVING<input type="number" min="0" step=".1" data-v86-comp-extra="${ri}|${esc(c.id)}|${ei}|${k}" value="${esc(x.nutrition?.[k]??"")}"></label>`).join("")}<label>SERVING G<input type="number" min="0" step=".1" data-v86-comp-extra="${ri}|${esc(c.id)}|${ei}|servingGrams" value="${esc(x.nutrition?.servingGrams??100)}"></label></div><button class="tinybtn" data-v86-comp-remove="${ri}|${esc(c.id)}|${ei}">Remove</button></div>`).join("")}</div></details>`).join("")}</div></details>`;return html+compact};

document.addEventListener("input",e=>{let t=e.target;if(t.dataset.v86CompExtra){let [ri,cid,ei,f]=t.dataset.v86CompExtra.split("|"),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||""),x=componentExtrasV86(rn,cid)[+ei];if(!x)return;if(f==="name"||f==="grams")x[f]=t.value;else{x.nutrition=x.nutrition||{};x.nutrition[f]=t.value}save()}});
document.addEventListener("change",e=>{let t=e.target;if(t.dataset.v86CompSource){let [ri,cid,ei]=t.dataset.v86CompSource.split("|"),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||""),x=componentExtrasV86(rn,cid)[+ei];if(!x)return;x.source=t.value;if(t.value){let [cat,ix]=t.value.split("|"),z=state.inventory?.[cat]?.[+ix];if(z){x.name=z.name;x.nutrition=structuredClone(z.nutrition||{});if(x.nutrition.servingGrams==null)x.nutrition.servingGrams=100}}save();render()}});
document.addEventListener("click",e=>{let t=e.target.closest?.("button");if(!t)return;if(t.dataset.v86CompAdd){let [ri,cid]=t.dataset.v86CompAdd.split("|"),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||"");componentExtrasV86(rn,cid).push({name:"",grams:"",nutrition:{servingGrams:100},source:""});save();render();return}if(t.dataset.v86CompRemove){let [ri,cid,ei]=t.dataset.v86CompRemove.split("|"),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||"");componentExtrasV86(rn,cid).splice(+ei,1);save();render();return}});


async function nutritionLookupV90(query){let q=String(query||"").trim();if(!q)return null;try{let data;if(/^\d{8,14}$/.test(q)){let res=await fetch(`https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(q)}.json`);data=await res.json();if(data?.product){let p=data.product,n=p.nutriments||{};return {name:p.product_name||p.generic_name||q,nutrition:{calories:Number(n["energy-kcal_100g"])||0,protein:Number(n.proteins_100g)||0,carbs:Number(n.carbohydrates_100g)||0,fat:Number(n.fat_100g)||0,fiber:Number(n.fiber_100g)||0,servingGrams:100},source:"Open Food Facts • barcode"}}}else{let res=await fetch(`https://world.openfoodfacts.org/cgi/search.pl?search_terms=${encodeURIComponent(q)}&search_simple=1&action=process&json=1&page_size=5`);data=await res.json();let p=(data?.products||[]).find(p=>p?.nutriments&&p.product_name);if(p){let n=p.nutriments||{};return {name:p.product_name,nutrition:{calories:Number(n["energy-kcal_100g"])||0,protein:Number(n.proteins_100g)||0,carbs:Number(n.carbohydrates_100g)||0,fat:Number(n.fat_100g)||0,fiber:Number(n.fiber_100g)||0,servingGrams:100},source:"Open Food Facts • text search"}}}}catch(e){}return null}
document.addEventListener("click",async e=>{let t=e.target.closest?.("button");if(!t)return;if(t.dataset.v90LookupComp){let [ri,cid,ei]=t.dataset.v90LookupComp.split("|"),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||""),x=componentExtrasV86(rn,cid)[+ei];if(!x)return;let z=await nutritionLookupV90(x.name);if(!z){showToast("No nutrition result found. Try a barcode/product name or enter generic nutrition manually.","Nutrition lookup");return}x.name=z.name;x.nutrition=z.nutrition;x.lookupSource=z.source;save();render();showToast("Nutrition linked to this component ingredient.",z.name);return}if(t.dataset.v90LookupContainer){let [key,i,ei]=t.dataset.v90LookupContainer.split("|"),x=containerDraftV84(key,+i).extras[+ei];if(!x)return;let z=await nutritionLookupV90(x.name);if(!z){showToast("No nutrition result found. Try a barcode/product name or enter generic nutrition manually.","Nutrition lookup");return}x.name=z.name;x.nutrition=z.nutrition;x.lookupSource=z.source;save();render();showToast("Nutrition linked to this container-only ingredient.",z.name);return}});

document.addEventListener("click",async e=>{let t=e.target.closest?.("button");if(!t?.dataset.v109LookupPlanned)return;let [ri,ii]=t.dataset.v109LookupPlanned.split("|"),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||""),r=MEAL.recipes?.[rn],raw=r?.ingredients?.[+ii]||"",note=state.nutritionFacts?.[rn+"|"+ii]?.note||ingredientNameOnly(raw),z=await nutritionLookupV90(note);if(!z){showToast("No nutrition result found. Try a product name/barcode or enter label nutrition manually.","Nutrition lookup");return}state.nutritionFacts=state.nutritionFacts||{};state.nutritionFacts[rn+"|"+ii]={...z.nutrition,note:z.name,lookupSource:z.source};save();render();showToast("Nutrition linked to this planned ingredient.",z.name)});

/* v84 convergence patch — authoritative routine order + actionable care fractions + generic finished-component containers */
const SUNDAY_SELF_CARE_V88=[
"PT #1 • SOAK RETAINER + BRUSH","PT #1 • WHITENING STRIPS","PT #1 • BRUSH DOGS' TEETH","PT #1 • CLEAN DOGS' EARS","PT #1 • REMOVE WHITENING STRIPS","PT #1 • BRUSH WITH BAKING SODA & HYDROGEN PEROXIDE","PT #1 • RETAINER",
"PT #2 • APPLY AMLA HAIR OIL MASK","PT #2 • CLAY FACE MASK","PT #2 • LIP STAIN","PT #2 • RINSE",
"PT #3 • JUST FOR MEN","PT #3 • RINSE","PT #3 • SHOWER & SHAVE EVERYTHING / INCLUDING FACE","PT #3 • TRIM BANGS","PT #3 • WASH WATER BOTTLE"];
const _rdayV84=rday;
rday=function(d){
  let rd=_rdayV84(d), a=rd.tasks||[];
  // Remove legacy duplicate care/shower blocks; careM is the single Morning Care block.
  let m=a.find(x=>x.id==="careM"), n=a.find(x=>x.id==="careN");
  a=a.filter(x=>x===m||x===n||!/^(MORNING CARE \/ SHOWER & GET READY|SHOWER & GET READY)$/i.test(String(x.name||"")));
  if(m){m.name="Morning Care";m.duration=50;m.section=sectionFor(d,m.name)}
  if(d==="Sunday"){let sr=a.find(x=>/^SUNDAY RESET$/i.test(String(x.name||"")));if(sr){sr.name="SUNDAY SELF-CARE RESET";sr.duration=130;sr.section="Afternoon Routine";sr.subtasks=Array.isArray(sr.subtasks)?sr.subtasks:[];let existing=new Set(sr.subtasks.map(q=>String(q.name||"").toUpperCase()));SUNDAY_SELF_CARE_V88.forEach((name,i)=>{if(!existing.has(name.toUpperCase()))sr.subtasks.push({id:"sunself"+i,name,done:false})})}}
  if(n){n.duration=30;n.section="Night Routine";a=a.filter(x=>x!==n);a.push(n)}
  
  rd.tasks=a; return rd;
};
function careIsHeadingV84(name){return /^(ORAL CARE|SKINCARE|HAIR|HAND \/ NAIL CARE)$/i.test(String(name||"").trim())}

/* V13 AUTHORITATIVE ROUTINE ENGINE — one canonical order, independent of legacy wrapper order. */
const _legacyRdayBeforeV13=rday;
function routineRawNameV13(raw){
  return String(raw||"").replace(/\s*[—-]\s*(?:\d+\s*(?:hr|hour)s?(?:\s*\d+\s*min)?|\d+\s*min).*$/i,"").trim();
}
function routineKeyV13(v){return String(v||"").toUpperCase().replace(/[^A-Z0-9]+/g," ").replace(/\s+/g," ").trim()}
function routineIdV13(d,i,name){return `canon|${d}|${i}|${routineKeyV13(name).slice(0,24)}`}
rday=function(d){
  // Read legacy state only to preserve completion, care subtasks, and user-added errands.
  let legacy=_legacyRdayBeforeV13(d), old=Array.isArray(legacy?.tasks)?legacy.tasks:[], k=selectedKey();
  let status=state.routineStatus?.[k]||{}, used=new Set(), tasks=[];
  const take=(pred)=>{for(let i=0;i<old.length;i++){if(!used.has(i)&&pred(old[i])){used.add(i);return old[i]}}return null};
  const match=(name)=>{let key=routineKeyV13(name);return take(x=>{let q=routineKeyV13(x.name);return q===key||q.startsWith(key+" ")||key.startsWith(q+" ")})};
  (ROUTINE[d]||[]).forEach((raw,i)=>{
    let name=routineRawNameV13(raw), key=routineKeyV13(name), t;
    if(/SHOWER GET READY|MORNING CARE SHOWER GET READY/.test(key)){
      t=take(x=>x.id==="careM")||{id:"careM",subtasks:careItems(d,"morning").map((name,j)=>({id:"m"+j,name,done:false}))};
      t.name="Morning Care / Shower & Get Ready"; t.duration=50;
    }else{
      t=match(name)||{id:routineIdV13(d,i,name),name,subtasks:[]};
      t.name=name;
      let dur=parseDuration(raw); t.duration=dur>0?dur:30;
    }
    t.section=sectionFor(d,t.name);
    t.done=!!status[t.id];
    (t.subtasks||[]).forEach(q=>q.done=!!status[t.id+"|"+q.id]);
    tasks.push(t);
  });
  // Keep only genuine user-created custom blocks; obsolete template duplicates cannot re-enter the schedule.
  old.forEach((t,i)=>{if(!used.has(i)&&(String(t.id||"").startsWith("errand")||t.errandMeta||t.customFixed)){t.done=!!status[t.id];tasks.push(t)}});
  let night=take(x=>x.id==="careN")||{id:"careN",name:"Night Care",duration:30,section:"Night Routine",subtasks:careItems(d,"night").map((name,j)=>({id:"n"+j,name,done:false}))};
  night.name="Night Care"; night.duration=30; night.section="Night Routine"; night.done=!!status[night.id];
  (night.subtasks||[]).forEach(q=>q.done=!!status[night.id+"|"+q.id]); tasks.push(night);
  let rd={...legacy,start:routineStart(d),tasks};
  // Authoritative wake times cannot be overridden by stale saved state on Wed/Thu.
  if(d==="Wednesday"||d==="Thursday")delete state.routineStarts[k];
  state.routineDates=state.routineDates||{}; state.routineDates[k]={day:d,...cloneRoutineDay(rd)};
  return rd;
};

careCategoryMarkup=function(t,d,i){let groups={};(t.subtasks||[]).forEach((q,j)=>{if(careIsHeadingV84(q.name))return;let c=careCategoryName(q.name);(groups[c]||(groups[c]=[])).push({q,j})});let order=["Retainer","Oral Care","Gua Sha","Skincare","Clean Ears","Pink Cream + Urea","Collars + Remotes","Hair Care","Deodorant + Perfume + Jewelry","Hands + Nails","Phone","Body + Get Ready"];return order.filter(c=>groups[c]?.length).map(c=>{let a=groups[c],done=a.filter(z=>z.q.done).length;return `<details class="care-category" data-care-category="${esc(c)}"><summary><span>${esc(c)}</span><span class="category-count">${done}/${a.length}${done===a.length?" ✓":""}</span></summary><div class="subtasks">${a.map(({q,j})=>`<div class="subrow"><input type="checkbox" aria-label="${esc(q.name)} complete" data-rsub-check="${d}|${i}|${j}" ${q.done?"checked":""}><span class="sub-name">${esc(q.name)}</span><button class="tinybtn icon-action" data-rsub-edit="${d}|${i}|${j}">Edit</button></div>`).join("")}</div></details>`}).join("")};

// Container builder is deliberately compact: one collapsed card per suggested container.
function finishedCookForDateV84(){return Object.entries(state.finishedCook||{}).filter(([k,v])=>v?.date===selectedKey())}
function containerDraftV84(key,i){state.containerDrafts=state.containerDrafts||{};state.containerDrafts[key]=state.containerDrafts[key]||[];return state.containerDrafts[key][i]||(state.containerDrafts[key][i]={components:{},extras:[]})}
function containerMacroV84(key,rec,i){let d=containerDraftV84(key,i),m=emptyMacros(),missing=[];(rec.components||[]).forEach(c=>{let g=Number(d.components?.[c.id])||0,fc=state.finishedComponents?.[componentStateKey(rec.recipe,c.id)];if(g>0&&fc?.macrosPerGram)m=addMacros(m,fc.macrosPerGram,g);else if(g>0)missing.push(c.label)});(d.extras||[]).forEach(x=>{let g=Number(x.grams)||0,n=x.nutrition||{},sg=Number(n.servingGrams)||100,scale=sg>0?g/sg:0;if(g>0)for(let k of ["calories","protein","carbs","fat","fiber"])m[k]=(Number(m[k])||0)+(Number(n[k])||0)*scale});return {macros:roundMacros(m),missing}}
function containersBuilderV84(){let rows=finishedCookForDateV84();if(!rows.length)return `<section class="card soft"><h2>Finished Meal Containers</h2><p class="muted">Finish a Cooking recipe first. Its saved components will appear here without re-entering the recipe.</p></section>`;return `<section class="card"><h2>Finished Meal Containers</h2><p class="muted">These are the SAME saved container drafts/records used by Cooking → Portion + Label + Store. Editing here updates that same container; it does not create a second copy. Suggested targets are guidance only; ACTUAL grams determine macros.</p>${rows.map(([key,rec])=>{let assigns=cookAssignments(rec.recipe)||[],count=rec.containerCount||assigns.length;let recon=(rec.components||[]).map(c=>{let assigned=Array.from({length:count},(_,i)=>Number(containerDraftV84(key,i).components?.[c.id])||0).reduce((a,b)=>a+b,0),left=Number(c.cookedWeight||0)-assigned;return `<div><b>${esc(c.label)}</b> • ${assigned.toFixed(1)} / ${Number(c.cookedWeight||0).toFixed(1)} g assigned • ${Math.abs(left)<0.11?"RECONCILED ✓":left>0?left.toFixed(1)+" g remaining":Math.abs(left).toFixed(1)+" g over-assigned"}</div>`}).join("");return `<details class="info-accordion"><summary>${esc(rec.recipe)} • ${count} CONTAINER${count===1?"":"S"}</summary><div><div class="suggested-portions"><b>COMPONENT RECONCILIATION</b>${recon}</div>${Array.from({length:count},(_,i)=>{let d=containerDraftV84(key,i),cm=containerMacroV84(key,rec,i),label=assigns[i]?`${shortDayDate(assigns[i].date)} • ${assigns[i].meal}`:`${rec.recipe} • Container ${i+1}`;return `<details class="component-card"><summary><span>CONTAINER ${i+1} OF ${count}</span><span class="category-count">${esc(label)}</span></summary><div class="component-body"><div class="label-preview"><b>SUGGESTED LABEL</b><br>${esc(label)}</div>${(rec.components||[]).map(c=>`<label>${esc(c.label)} — ACTUAL G <small class="muted">suggested ~${c.suggestedGrams?Number(c.suggestedGrams).toFixed(1):"—"} g</small><input type="number" min="0" step="1" data-v84-component="${esc(key)}|${i}|${esc(c.id)}" value="${esc(d.components?.[c.id]??"")}" placeholder="Scale weight"></label>`).join("")}<details class="ingredient-edit"><summary>ADD SOMETHING TO THIS CONTAINER</summary><div class="ingredient-edit-body"><p class="muted">Use a saved inventory/product nutrition record or enter a generic item. This affects this container only.</p><button class="tinybtn" data-v84-extra-add="${esc(key)}|${i}">+ ADD ITEM</button>${(d.extras||[]).map((x,ei)=>`<div class="inventory-match"><label>ITEM<input data-v84-extra="${esc(key)}|${i}|${ei}|name" value="${esc(x.name||"")}" placeholder="Food / product"></label><label>GRAMS<input type="number" min="0" step=".1" data-v84-extra="${esc(key)}|${i}|${ei}|grams" value="${esc(x.grams??"")}"></label><label>SOURCE<select data-v108-container-source="${esc(key)}|${i}|${ei}"><option value="">Generic / not from Inventory</option>${inventoryFlat().map(z=>`<option value="${esc(z.cat)}|${z.i}" ${x.source===z.cat+"|"+z.i?"selected":""}>${esc(z.name)} — ${esc(z.cat)}</option>`).join("")}</select></label><button class="tinybtn" data-v90-lookup-container="${esc(key)}|${i}|${ei}">LOOK UP NUTRITION</button><div class="macro-edit">${["calories","protein","carbs","fat","fiber"].map(k=>`<label>${k.toUpperCase()} / SERVING<input type="number" min="0" step=".1" data-v84-extra="${esc(key)}|${i}|${ei}|${k}" value="${esc(x.nutrition?.[k]??"")}"></label>`).join("")}<label>SERVING G<input type="number" min="0" step=".1" data-v84-extra="${esc(key)}|${i}|${ei}|servingGrams" value="${esc(x.nutrition?.servingGrams??100)}"></label></div><button class="tinybtn" data-v84-extra-remove="${esc(key)}|${i}|${ei}">Remove</button></div>`).join("")}</div></details><div class="macro-preview"><b>ACTUAL CONTAINER MACROS</b><br>${macroLine(cm.macros)}${cm.missing.length?`<br><small class="muted">Incomplete nutrition: ${esc(cm.missing.join(", "))}</small>`:""}</div><button class="btn primary" data-v84-container-save="${esc(key)}|${i}">SAVE CONTAINER ${i+1}</button></div></details>`}).join("")}</div></details>`}).join("")}</section>`}
const _inventoryV84=inventory;
inventory=function(){let html=_inventoryV84();if((state.inventoryTab||"Fridge")==="Containers")html=html.replace(/<section class="card monday-haul">/,containersBuilderV84()+`<section class="card monday-haul">`);return html}

document.addEventListener("input",e=>{let t=e.target;if(t.dataset.v84Component){let [key,i,cid]=t.dataset.v84Component.split("|");let d=containerDraftV84(key,+i);d.components[cid]=t.value;save();return}if(t.dataset.v84Extra){let [key,i,ei,f]=t.dataset.v84Extra.split("|"),d=containerDraftV84(key,+i),x=d.extras[+ei];if(!x)return;if(f==="name"||f==="grams")x[f]=t.value;else{x.nutrition=x.nutrition||{};x.nutrition[f]=t.value}save();return}});
document.addEventListener("click",e=>{let t=e.target.closest?.("button");if(!t)return;if(t.dataset.v84ExtraAdd){let [key,i]=t.dataset.v84ExtraAdd.split("|"),d=containerDraftV84(key,+i);d.extras.push({name:"",grams:"",nutrition:{servingGrams:100}});save();render();return}if(t.dataset.v84ExtraRemove){let [key,i,ei]=t.dataset.v84ExtraRemove.split("|"),d=containerDraftV84(key,+i);d.extras.splice(+ei,1);save();render();return}if(t.dataset.v84ContainerSave){let [key,i]=t.dataset.v84ContainerSave.split("|"),rec=state.finishedCook?.[key],d=containerDraftV84(key,+i);if(!rec)return;let cm=containerMacroV84(key,rec,+i);if(cm.missing.length){showToast("Link complete nutrition before saving exact macros.","Nutrition incomplete");return}let used=(rec.components||[]).some(c=>Number(d.components?.[c.id])>0);if(!used){showToast("Enter the actual component grams you put in this container.","Container weight needed");return}d.saved=true;d.macros=cm.macros;d.savedAt=new Date().toISOString();let assigns=cookAssignments(rec.recipe)||[],target=assigns[+i]||{date:selectedKey(),meal:"MEAL",storage:"FRIDGE"},id=`finished|${key}|${i}`;state.inventory.Containers=state.inventory.Containers||[];let record={id,name:`${rec.recipe} • Container ${+i+1}`,qty:`${target.storage||"FRIDGE"} • EAT ${shortDayDate(target.date||selectedKey())} ${target.meal||"MEAL"}`,storage:target.storage||"FRIDGE",eat:shortDayDate(target.date||selectedKey()),meal:target.meal||"MEAL",labelRows:physicalLabel(target),recipe:rec.recipe,created:selectedKey(),components:structuredClone(d.components||{}),extras:structuredClone(d.extras||[]),macros:structuredClone(cm.macros),nutritionComplete:true,sourceCookKey:key,containerIndex:+i};let at=state.inventory.Containers.findIndex(x=>x.id===id);if(at>=0)state.inventory.Containers[at]=record;else state.inventory.Containers.push(record);state.foodHistory=state.foodHistory||[];state.foodHistory=state.foodHistory.filter(x=>x.id!==id);state.foodHistory.push({id,date:selectedKey(),type:"COOKED + CONTAINER SAVED",recipe:rec.recipe,container:+i+1,macros:structuredClone(cm.macros)});save();render();showToast("Container saved to Containers with actual component weights and macros.",`Container ${+i+1}`);return}});

// Generic finish must live inside app scope. It never requires legacy MAIN/SIDE fields.
function consumeInventorySourceV108(source,grams,label){
 let [cat,ix]=String(source||"").split("|"),item=state.inventory?.[cat]?.[+ix];if(!item)return {ingredient:label,deducted:false,reason:"selected Inventory source no longer exists"};
 let q=parseQty(item.qty);if(!q||unitKind(q.u)!=="mass")return {ingredient:label,deducted:false,reason:"selected Inventory quantity is not stored as a measurable mass"};
 let need=Number(grams)||0,have=toBaseAmount(q.n,q.u);if(!(need>0))return {ingredient:label,deducted:false,reason:"actual grams are missing"};if(have+1e-8<need)return {ingredient:label,deducted:false,reason:`only ${q.n} ${q.u} remains in selected Inventory item`};
 let left=have-need,newN=fromBaseAmount(left,q.u);item.qty=left<=1e-8?"0":`${+newN.toFixed(2)} ${q.u}`;appendUsage(item,`used ${+need.toFixed(2)} g for ${label}`);return {ingredient:label,deducted:true,updated:true,used:[{item:item.name,category:cat,usedBase:need}]}
}
document.addEventListener("change",e=>{let t=e.target;if(!t.dataset.v108ContainerSource)return;let [key,i,ei]=t.dataset.v108ContainerSource.split("|"),x=containerDraftV84(key,+i).extras[+ei];if(!x)return;x.source=t.value;if(t.value){let [cat,ix]=t.value.split("|"),z=state.inventory?.[cat]?.[+ix];if(z){x.name=z.name;x.nutrition=structuredClone(z.nutrition||{});if(x.nutrition.servingGrams==null)x.nutrition.servingGrams=100}}save();render()});
function syncRecipeInventoryV85(rn,r){let tx=selectedKey()+"|"+rn;if(state.cookLog?.[tx]?.inventorySynced)return {ok:true,used:state.cookLog[tx].used||[],already:true};let before=JSON.stringify(state.inventory),used=[],bad=[],adj=state.cookAdjustments?.[tx]||{};(r.ingredients||[]).forEach((line,i)=>{let a=adj.ingredients?.[i]||{},removed=/remove/i.test(String(a.amount||""))||/remove/i.test(String(a.name||""));if(removed)return;let actualLine=actualIngredientLineV102(line,a.amount),override=null;let draft=Number(state.cookDraft?.[tx]?.["ingredient"+i]);if(draft>0)override=draft;let z=consumeIngredient(actualLine,override);used.push(z);if(!z.deducted)bad.push(`${line} — ${z.reason}`)});recipeComponentDefs(rn,r).forEach(c=>componentExtrasV86(rn,c.id).forEach(x=>{if(!x.name||!(Number(x.grams)>0)||!x.source)return;let z=consumeInventorySourceV108(x.source,Number(x.grams),x.name);used.push(z);if(!z.deducted)bad.push(`${x.name} — ${z.reason}`)}));(state.containerDrafts?.[tx]||[]).forEach((d,ci)=>(d?.extras||[]).forEach(x=>{if(!x.name||!(Number(x.grams)>0)||!x.source)return;let z=consumeInventorySourceV108(x.source,Number(x.grams),`${x.name} • Container ${ci+1}`);used.push(z);if(!z.deducted)bad.push(`${x.name} • Container ${ci+1} — ${z.reason}`)}));if(bad.length){state.inventory=JSON.parse(before);return {ok:false,bad}}return {ok:true,used,before}}
finishCooking=function(dayIndex,recipeIndex){const rn=cookRecipeName(todayMeal()?.cook?.[recipeIndex]||""),r=MEAL.recipes?.[rn];if(!r){showToast("Recipe not found.","Cooking");return}const key=selectedKey()+"|"+rn;const defs0=recipeComponentDefs(rn,r),cs0=state.cookComponents?.[key]||{},adj0=state.cookAdjustments?.[key]?.ingredients||{};let unconfirmed=defs0.filter(c=>!cs0[c.id]?.usedPlanned&&!c.ix.some(i=>{let a=adj0[i]||{};return Object.values(a).some(v=>String(v??"").trim()!=="")})&&!componentExtrasV86(rn,c.id).some(x=>x.name&&Number(x.grams)>0));if(unconfirmed.length){showToast("Confirm MADE AS INSTRUCTED or record the actual changes for: "+unconfirmed.map(c=>c.label).join(", ")+".","Confirm actual recipe");return}if(state.finishedCook?.[key]){showToast("This cooked batch is already saved. Inventory will not be deducted again.","Already saved");return}const defs=recipeComponentDefs(rn,r),totals=componentTotalsFor(rn),assigns=cookAssignments(rn)||[],n=componentNutritionV82(rn),missingWeight=defs.filter(c=>!(Number(totals[c.id])>0));if(missingWeight.length){showToast("Enter the actual cooked weight for: "+missingWeight.map(x=>x.label).join(", ")+".","Cooked weights needed");return}if(n.unknown.length){showToast("Nutrition is incomplete for "+n.unknown.map(x=>x.name).join(", ")+". Link nutrition before finalizing exact macros.","Nutrition incomplete");return}let inv=syncRecipeInventoryV85(rn,r);if(!inv.ok){showToast("Nothing was deducted. Fix/add these Inventory items first: "+inv.bad.join(" • "),"Inventory check needed");return}snapshotFinishedComponents(rn);state.containerDrafts[key]=state.containerDrafts[key]||[];while(state.containerDrafts[key].length<assigns.length)state.containerDrafts[key].push({components:{},extras:[]});state.finishedCook=state.finishedCook||{};state.finishedCook[key]={recipe:rn,date:selectedKey(),containerCount:assigns.length,components:defs.map(c=>({id:c.id,label:c.label,cookedWeight:totals[c.id],suggestedGrams:Number(totals[c.id])/Math.max(1,assigns.length),totalMacros:n.components[c.id],nutritionComplete:true})),savedAt:new Date().toISOString()};state.cookLog=state.cookLog||{};state.cookLog[key]={date:selectedKey(),day:DAYS[dayIndex],recipe:rn,used:inv.used,inventorySynced:true,status:"cooked-awaiting-containers",finishedAt:new Date().toISOString()};save();showToast(`Saved ${rn}. Make ${assigns.length} container${assigns.length===1?"":"s"}; enter actual component grams in Inventory → Containers.`,"Cooking saved");render()};



// ===== v96 COMPONENT-SPLIT MACRO ALLOCATIONS =====
// Some recipe ingredient lines are totals shared across components. Allocate their macros exactly as the prep instructions split them.
const COMPONENT_ALLOC_V96={
 "Marry Me Chicken Meatballs":{
   0:{main:1},1:{main:1},2:{main:1},3:{main:.5,side:.5},4:{main:.5,side:.5},5:{main:1},6:{side:1},7:{main:1},
   8:{side:1},9:{side:1},10:{side:1},11:{side:1},12:{side:1},13:{pasta:1}
 },
 "Cheesy Cottage Pie":{
   0:{main:1},1:{side:1},2:{main:1},3:{main:1},4:{main:1},5:{main:1},6:{main:1},7:{main:1},8:{main:1},9:{main:1},
   10:{main:14/42,side:28/42},11:{side:1},12:{side:1}
 },
 "Chicken & Dumplings":{
   0:{main:1},1:{main:1},2:{main:1},3:{main:1},4:{main:1},5:{main:1},6:{main:120/180,side:60/180},
   7:{side:1},8:{side:1},9:{main:14/42,side:28/42},10:{side:1},11:{side:1}
 }
};
const _componentNutritionV96=componentNutritionV82;
componentNutritionV82=function(rn){
  let alloc=COMPONENT_ALLOC_V96[rn];if(!alloc)return _componentNutritionV96(rn);
  let r=MEAL.recipes?.[rn],key=selectedKey()+"|"+rn,adj=state.cookAdjustments?.[key]||{},defs=recipeComponentDefs(rn,r),out={},unknown=[];
  defs.forEach(c=>out[c.id]=emptyMacros());
  (r?.ingredients||[]).forEach((txt,i)=>{
    let change=adj.ingredients?.[i]||{},removed=/remove/i.test(String(change.amount||""))||/remove/i.test(String(change.name||""));if(removed)return;
    let manual={},hasManual=false;for(let m of ["calories","protein","carbs","fat","fiber"]){if(change[m]!==undefined&&change[m]!==""){manual[m]=Number(change[m])||0;hasManual=true}}
    let base=hasManual?manual:(actualWeighedIngredientMacros(rn,i)||linkedInventoryIngredientMacrosV103(rn,i,change)||ingredientMacroBase(rn,i));
    if(base&&!hasManual&&String(change.amount||"").trim()){
      let sc=changedIngredientScaleV100(txt,change.amount);if(sc!=null)base=addMacros(emptyMacros(),base,sc);
    }
    let parts=alloc[i]||{main:1};
    if(!base){Object.keys(parts).forEach(cid=>unknown.push({component:cid,index:i,name:txt}));return}
    Object.entries(parts).forEach(([cid,f])=>{out[cid]=addMacros(out[cid]||emptyMacros(),base,Number(f)||0)});
  });
  // Preserve actual added ingredients from v86.
  defs.forEach(c=>componentExtrasV86(rn,c.id).forEach(x=>{
    if(!x.name||!(Number(x.grams)>0))return;
    let has=["calories","protein","carbs","fat","fiber"].some(k=>x.nutrition?.[k]!==undefined&&x.nutrition?.[k]!=="");
    if(!has)unknown.push({component:c.id,name:x.name});else out[c.id]=addMacros(out[c.id]||emptyMacros(),extraMacrosV86(x));
  }));
  Object.keys(out).forEach(k=>out[k]=roundMacros(out[k]));return {components:out,unknown};
};
recipeNutrition=componentNutritionV82;

// ===== v92 PORTION + LABEL RESTORED INSIDE COOKING =====
// Step 6 is the scale/label handoff. It uses generic named components and never falls back to MAIN/SIDE.
function liveContainerMacroV92(rn,ci,weights){
  let r=MEAL.recipes?.[rn], n=componentNutritionV82(rn), totals=componentTotalsFor(rn), m=emptyMacros(), missing=[];
  recipeComponentDefs(rn,r).forEach(c=>{
    let g=Number(weights?.[c.id])||0, total=Number(totals[c.id])||0, cm=n.components[c.id]||emptyMacros();
    if(g>0 && total>0) m=addMacros(m,cm,g/total);
    if(g>0 && n.unknown.some(x=>x.component===c.id)) missing.push(c.label);
  });
  let d=containerDraftV84(selectedKey()+"|"+rn,ci);
  (d.extras||[]).forEach(x=>{
    let grams=Number(x.grams)||0, sg=Number(x.nutrition?.servingGrams)||100;
    let has=["calories","protein","carbs","fat","fiber"].some(k=>x.nutrition?.[k]!==undefined&&x.nutrition?.[k]!=="");
    if(grams>0&&!has) missing.push(x.name||"container addition");
    if(grams>0&&has&&sg>0){
      let q=emptyMacros();["calories","protein","carbs","fat","fiber"].forEach(k=>q[k]=(Number(x.nutrition?.[k])||0)*(grams/sg));
      m=addMacros(m,q);
    }
  });
  return {macros:roundMacros(m),missing:[...new Set(missing)]};
}

// Obsolete Cooking renderer wrapper removed during canonical cleanup.

document.addEventListener("input",e=>{
  let t=e.target;if(!t.dataset.v92Portion)return;
  let [key,i,cid]=t.dataset.v92Portion.split("|"),d=containerDraftV84(key,+i);d.components[cid]=t.value;save();
});
document.addEventListener("change",e=>{
  let t=e.target;if(!t.dataset.v92ContainerListed)return;
  let [key,i]=t.dataset.v92ContainerListed.split("|"),d=containerDraftV84(key,+i);d.madeAsListed=!!t.checked;save();
});
document.addEventListener("click",e=>{
  let t=e.target.closest?.("button");if(!t?.dataset.v92AddLabel)return;
  let [key,i]=t.dataset.v92AddLabel.split("|"),rec=state.finishedCook?.[key],rn=key.split("|").slice(1).join("|"),r=MEAL.recipes?.[rn];
  // Before Step 7, build a temporary component record from current measured totals so macros can be verified now.
  let defs=recipeComponentDefs(rn,r),totals=componentTotalsFor(rn),nut=componentNutritionV82(rn),d=containerDraftV84(key,+i);
  let missingWeight=defs.filter(c=>!(Number(totals[c.id])>0));if(missingWeight.length){showToast("Enter the cooked total for "+missingWeight.map(c=>c.label).join(", ")+" first.","Measurements needed");return}
  if(nut.unknown.length){showToast("Nutrition is incomplete for "+nut.unknown.map(x=>x.name).join(", ")+". Link nutrition before saving exact container macros.","Nutrition incomplete");return}
  let hasActual=defs.some(c=>Number(d.components?.[c.id])>0);if(!hasActual){showToast("Enter the ACTUAL component grams you put in this container.","Actual portion needed");return}
  let cm=liveContainerMacroV92(rn,+i,d.components||{});if(cm.missing.length){showToast("Complete nutrition before saving this container.","Nutrition incomplete");return}
  let targets=cookAssignments(rn)||[],target=targets[+i]||{date:selectedKey(),meal:"MEAL",storage:"FRIDGE"},id=`finished|${key}|${i}`;
  state.inventory.Containers=state.inventory.Containers||[];
  let record={id,name:`${rn} • Container ${+i+1}`,qty:`${target.storage||"FRIDGE"} • EAT ${shortDayDate(target.date||selectedKey())} ${target.meal||"MEAL"}`,storage:target.storage||"FRIDGE",eat:shortDayDate(target.date||selectedKey()),meal:target.meal||"MEAL",labelRows:physicalLabel(target),recipe:rn,created:selectedKey(),components:structuredClone(d.components||{}),extras:structuredClone(d.extras||[]),madeAsListed:!!d.madeAsListed,macros:structuredClone(cm.macros),nutritionComplete:true,sourceCookKey:key,containerIndex:+i,pendingCookSync:!rec};
  let at=state.inventory.Containers.findIndex(x=>x.id===id);if(at>=0)state.inventory.Containers[at]=record;else state.inventory.Containers.push(record);
  state.foodHistory=state.foodHistory||[];state.foodHistory=state.foodHistory.filter(x=>x.id!==id);state.foodHistory.push({id,date:selectedKey(),type:"CONTAINER PORTIONED + LABELED",recipe:rn,container:+i+1,macros:structuredClone(cm.macros),pendingCookSync:!rec});
  d.saved=true;d.macros=cm.macros;d.savedAt=new Date().toISOString();save();render();showToast("Container label + actual portions saved. Step 7 will sync the cooked batch to Inventory once.","Container saved");
});


// v93 finalization reconciliation: Step 7 refreshes every Step-6-saved container from finalized component snapshots.
const _finishCookingV93=finishCooking;
finishCooking=function(dayIndex,recipeIndex){
  let rn=cookRecipeName(todayMeal()?.cook?.[recipeIndex]||""), key=selectedKey()+"|"+rn;
  _finishCookingV93(dayIndex,recipeIndex);
  let rec=state.finishedCook?.[key]; if(!rec)return;
  let drafts=state.containerDrafts?.[key]||[], assigns=cookAssignments(rn)||[];
  drafts.forEach((d,i)=>{
    if(!d?.saved)return;
    let cm=containerMacroV84(key,rec,i);
    if(cm.missing.length)return;
    d.macros=structuredClone(cm.macros);d.savedAt=new Date().toISOString();
    let id=`finished|${key}|${i}`,at=(state.inventory.Containers||[]).findIndex(x=>x.id===id);
    if(at>=0){
      let x=state.inventory.Containers[at],target=assigns[i]||{date:selectedKey(),meal:"MEAL",storage:"FRIDGE"};
      Object.assign(x,{components:structuredClone(d.components||{}),extras:structuredClone(d.extras||[]),madeAsListed:!!d.madeAsListed,macros:structuredClone(cm.macros),nutritionComplete:true,pendingCookSync:false,labelRows:physicalLabel(target)});
    }
    let h=(state.foodHistory||[]).find(x=>x.id===id);if(h){h.macros=structuredClone(cm.macros);h.pendingCookSync=false;h.type="COOKED + CONTAINER SAVED"}
  });
  save();render();
};


// v109 clean Cooking placement: confirmations/changes live with prep; weighing lives only in Step 5.
// Obsolete Cooking renderer wrapper removed during canonical cleanup.


// v114 — semantic SVG icons, polished Wish List, and always-visible Budget live-balance feedback.
const UI_PATHS_V114={
 add:'<path d="M12 5v14M5 12h14"/>',save:'<path d="M5 4h12l2 2v14H5z"/><path d="M8 4v6h8V4M8 20v-6h8v6"/>',edit:'<path d="M4 20l4-1 10-10-3-3L5 16z"/><path d="M13 8l3 3"/>',trash:'<path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13M10 11v5M14 11v5"/>',search:'<circle cx="11" cy="11" r="6"/><path d="M16 16l4 4"/>',copy:'<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M5 16H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',back:'<path d="M15 18l-6-6 6-6"/>',next:'<path d="M9 18l6-6-6-6"/>',cart:'<circle cx="9" cy="20" r="1"/><circle cx="18" cy="20" r="1"/><path d="M3 4h2l2.5 11h10l2-7H7"/>',box:'<path d="M4 7l8-4 8 4-8 4zM4 7v10l8 4 8-4V7M12 11v10"/>',calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/>',check:'<path d="M5 12l4 4L19 6"/>',book:'<path d="M4 5a4 4 0 0 1 4-1l4 2v14l-4-2a4 4 0 0 0-4 1zM20 5a4 4 0 0 0-4-1l-4 2v14l4-2a4 4 0 0 1 4 1z"/>',heart:'<path d="M12 20S4 15 4 9a4 4 0 0 1 7-3 4 4 0 0 1 7 3c0 6-6 11-6 11z"/>',star:'<path d="M12 3l2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',ruler:'<path d="M5 19L19 5l2 2L7 21zM12 10l2 2M9 13l2 2M15 7l2 2"/>',scale:'<path d="M5 20h14l1-11H4z"/><path d="M8 9a4 4 0 0 1 8 0M12 9l2-2"/>',sparkle:'<path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5zM19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',tag:'<path d="M3 12V5h7l11 11-5 5z"/><circle cx="7.5" cy="8.5" r="1"/>',lookup:'<circle cx="10" cy="10" r="5"/><path d="M14 14l5 5M10 7v6M7 10h6"/>',money:'<circle cx="12" cy="12" r="9"/><path d="M15 8.5c-.7-.7-1.7-1-3-1-1.7 0-3 .8-3 2s1.1 1.8 3 2.2c1.9.4 3 1 3 2.3 0 1.2-1.3 2-3 2-1.4 0-2.6-.4-3.4-1.2M12 5v14"/>',food:'<path d="M7 3v8M4 3v5c0 2 6 2 6 0V3M7 11v10M15 3v18M15 3c4 2 4 8 0 9"/>',gym:'<path d="M3 9v6M7 7v10M17 7v10M21 9v6M7 12h10"/>',history:'<circle cx="12" cy="12" r="9"/><path d="M12 7v6l4 2"/>',shirt:'<path d="M8 4l4 2 4-2 4 3-3 4-2-1v10H9V10l-2 1-3-4z"/>',shoe:'<path d="M4 14c4 0 5-4 6-7l3 5 6 2c2 .7 2 4-1 4H6c-2 0-3-1-2-4z"/>',gem:'<path d="M5 8l3-4h8l3 4-7 12zM5 8h14M8 4l4 4 4-4"/>',dog:'<path d="M6 9V5l3 2h6l3-2v4M7 10c0 6 2 9 5 9s5-3 5-9M9 12h.01M15 12h.01M11 15h2"/>',home:'<path d="M4 11l8-7 8 7v9H5z"/><path d="M9 20v-6h6v6"/>',car:'<path d="M5 16h14l-1-6-2-3H8l-2 3zM7 16v3M17 16v3M7 12h10"/><circle cx="8" cy="16" r="1"/><circle cx="16" cy="16" r="1"/>',person:'<circle cx="12" cy="8" r="3"/><path d="M5 20c1-5 3-7 7-7s6 2 7 7"/>',shield:'<path d="M12 3l7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6z"/><path d="M9 12l2 2 4-4"/>',clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v6l4 2"/>'
};
function uiIconV114(n){let p=UI_PATHS_V114[n]||UI_PATHS_V114.sparkle;return `<svg class="ui-icon" viewBox="0 0 24 24" aria-hidden="true">${p}</svg>`}
function actionIconV114(el){let d=el.dataset||{},txt=(el.textContent||"").trim().toLowerCase();
 if(el.classList.contains('weekshift'))return d.weekShift==='-1'?'back':'next';
 if(d.wish){return ({Clothes:'shirt',Shoes:'shoe',Jewelry:'gem',Dogs:'dog',Jeremiah:'person',Home:'home',Miscellaneous:'sparkle',Car:'car'})[d.wish]||'heart'}
 if(d.back!==undefined||el.classList.contains('back'))return 'back'; if(d.wishDel!==undefined||d.goalRemove!==undefined||d.inventoryRemove!==undefined||/remove|delete|discard/.test(txt))return 'trash';
 if(d.wishEdit!==undefined||d.editAutopay!==undefined||d.goalEdit!==undefined||/\bedit\b|change/.test(txt))return 'edit';
 if(d.rsubAdd!==undefined||d.gymUpWeight!==undefined)return 'add'; if(d.saveBalance!==undefined)return 'save'; if(d.invClear!==undefined||d.delInv!==undefined)return 'trash'; if(d.invSoon!==undefined)return 'tag'; if(d.eatContainer!==undefined)return 'food'; if(d.wokeLate!==undefined)return 'clock';
 if(d.wishAdd!==undefined||/\badd\b|new item|log item/.test(txt))return 'add'; if(/save|finish cooking|sync inventory|confirm/.test(txt))return 'save';
 if(/nutrition|lookup|barcode|search/.test(txt))return 'lookup'; if(/copy/.test(txt))return 'copy'; if(/grocery|shop/.test(txt))return 'cart'; if(/inventory|container|portion|label/.test(txt))return 'box';
 if(/^week \d+/i.test(txt)||/^(january|february|march|april|may|june|july|august|september|october|november|december)$/i.test(txt)||/^20\d{2}$/.test(txt))return 'calendar';
 if(/routine/.test(txt))return 'check'; if(/bible|faith|study|school/.test(txt))return 'book'; if(/goal/.test(txt))return 'star'; if(/measure/.test(txt))return 'ruler'; if(/weigh/.test(txt))return 'scale'; if(/reset|self-care/.test(txt))return 'sparkle'; if(/months?|calendar/.test(txt))return 'calendar'; if(/unplanned spending|unexpected purchase|budget|autopay|money|buy/.test(txt))return 'money'; if(/emergency mode|sacrifice/.test(txt))return 'shield'; if(/complete/.test(txt))return 'check'; if(/body/.test(txt))return 'scale'; if(/gym|run|workout/.test(txt))return 'gym'; if(/food|meal|eat|cook/.test(txt))return 'food'; if(/history/.test(txt))return 'history'; return null;
}
function decorateHubV114(root=document){
 root.querySelectorAll('.weekshift').forEach(el=>{if(!el.querySelector('.ui-icon'))el.innerHTML=uiIconV114(el.dataset.weekShift==='-1'?'back':'next')});
 root.querySelectorAll('button.btn,button.tinybtn,button.sectionTab,button.tile').forEach(el=>{if(el.closest('.nav')||el.classList.contains('daybtn')||el.querySelector(':scope > .ui-icon')||el.querySelector(':scope > .ico'))return;let n=actionIconV114(el);if(!n)return;let d=el.dataset||{};if(d.delInv!==undefined||d.rsubAdd!==undefined||d.gymUpWeight!==undefined){if(!el.getAttribute('aria-label'))el.setAttribute('aria-label',d.delInv!==undefined?'Remove inventory item':d.gymUpWeight!==undefined?'Increase actual weight':'Add routine subtask');el.innerHTML=uiIconV114(n);el.classList.add('icon-only-v117')}else{if(d.invSoon!==undefined)el.textContent='ASAP';if(n==='back')el.textContent=(el.textContent||'').replace(/^\s*[‹←]+\s*/, '');el.insertAdjacentHTML('afterbegin',uiIconV114(n))}if(n==='trash')el.classList.add('action-remove');else if(n==='edit')el.classList.add('action-edit');else if(n==='add')el.classList.add('action-add');else if(n==='save')el.classList.add('action-save');else if(n==='lookup')el.classList.add('action-lookup');else if(n==='copy')el.classList.add('action-copy');else if(n==='back')el.classList.add('action-back')});
 root.querySelectorAll('[data-wish-done]').forEach(cb=>{let row=cb.closest('.checkrow');if(row)row.classList.add('wish-item-row')});
 root.querySelectorAll('.paid-tag').forEach(el=>{el.textContent='PAID';el.insertAdjacentHTML('afterbegin',uiIconV114('check'))});
}
const _wishCatV114=wishCat;
wishCat=function(c){let html=_wishCatV114(c);html=html.replace(/<div class="checkrow"><input type="checkbox" data-wish-done/g,'<div class="checkrow wish-item-row"><input type="checkbox" data-wish-done');html=html.replace(/<span style="flex:1">/g,'<span class="wish-name">').replace(/<b>\$(.*?)<\/b><button class="btn" data-wish-edit/g,'<b class="wish-price">$$$1</b><span class="wish-actions"><button class="btn" data-wish-edit').replace(/<button class="btn" data-wish-del="([^"]+)" aria-label="Remove wish item">×<\/button><\/div>/g,'<button class="btn" data-wish-del="$1" aria-label="Remove wish item">Remove</button></span></div>');return html.replace('<section class="card">','<section class="card wish-add-card">')}
const _renderV114=render;
render=function(){_renderV114();decorateHubV114(document)};

applyPreparedContainerTruthSep29();
applyPreparedContainerMacrosSep29();
render();

/* V119 semantic button normalization */
(function(){
 const labels=[
  [/wishlist|wish list/i,'heart'],
  [/budget|money|balance|payment|paid|bill|income|spending/i,'wallet'],
  [/grocery|shop|shopping/i,'cart'],
  [/inventory|pantry|fridge|freezer/i,'box'],
  [/cook|cooking|recipe|meal/i,'food'],
  [/nutrition|lookup|barcode/i,'search'],
  [/save|update|apply|confirm|finish/i,'check'],
  [/add|new|\+/i,'plus'],
  [/remove|delete|discard/i,'trash'],
  [/edit|change/i,'edit'],
  [/history|year|month|week|calendar/i,'calendar'],
  [/gym|workout|weight/i,'dumbbell'],
  [/routine|care|reset/i,'sparkle'],
  [/back/i,'back']
 ];
 function existingIcon(b){return !!b.querySelector('svg,.icon,.nav-icon,[data-ui-icon]')||b.classList.contains('tile')||b.matches('.bottom-nav button,.weekbar button,.daybar button,[data-day]')||!!b.querySelector('input[type="checkbox"],input[type="radio"]')}
 function iconSvg(kind){
   if(typeof window.uiIconV118==='function') return window.uiIconV118(kind);
   const paths={
    heart:'<path d="M12 20s-7-4.35-9.2-8.1C.8 8.5 2.5 5 6.1 5c2 0 3.1 1.1 3.9 2.2C10.8 6.1 11.9 5 13.9 5c3.6 0 5.3 3.5 3.3 6.9C19 15.65 12 20 12 20Z"/>',
    wallet:'<path d="M3 7.5h15v10H3z"/><path d="M5 7.5V5h11v2.5M14 11h5v4h-5z"/>',
    cart:'<path d="M3 4h2l2 10h9l2-7H6"/><circle cx="9" cy="18" r="1"/><circle cx="16" cy="18" r="1"/>',
    box:'<path d="M4 7l8-4 8 4-8 4zM4 7v10l8 4 8-4V7M12 11v10"/>',
    food:'<path d="M7 3v8M4 3v5c0 2 6 2 6 0V3M7 11v10M15 3v18M15 3c4 2 4 8 0 10"/>',
    search:'<circle cx="10" cy="10" r="6"/><path d="m14.5 14.5 5 5"/>',
    check:'<path d="m5 12 4 4 10-10"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    trash:'<path d="M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13"/>',
    edit:'<path d="m4 17-.5 3.5L7 20l11-11-3-3zM13.5 7.5l3 3"/>',
    calendar:'<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16"/>',
    dumbbell:'<path d="M3 9v6M6 7v10M18 7v10M21 9v6M6 12h12"/>',
    sparkle:'<path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5zM19 15l.7 2.3L22 18l-2.3.7L19 21l-.7-2.3L16 18l2.3-.7z"/>',
    back:'<path d="m14 6-6 6 6 6"/>'
   };
   let body=paths[kind]||paths.sparkle;
   return '<svg data-ui-icon="'+kind+'" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+body+'</svg>';
 }
 function normalize(){
   document.querySelectorAll('button,.btn,.action-btn,.smallbtn,.mini-btn').forEach(b=>{
     if(existingIcon(b)) return;
     const aria=(b.getAttribute('aria-label')||'').trim();
     const txt=(b.textContent||'').trim();
     const action=(b.getAttribute('data-action')||'')+' '+Array.from(b.attributes).filter(a=>a.name.startsWith('data-')).map(a=>a.name+' '+a.value).join(' ');
     const semantic=(aria+' '+action).trim();
     const safeText=/^(add|new|save|update|apply|confirm|finish|remove|delete|discard|edit|change|back|budget|wish list|wishlist|grocery|inventory|cook|cooking|recipe|nutrition lookup|history|gym|workout|routine|reset|previous week|next week)(\b|$)/i.test(txt)?txt:'';
     const hay=(semantic+' '+safeText).trim();
     if(!hay) return;
     for(const [re,kind] of labels){
       if(re.test(hay)){
         b.insertAdjacentHTML('afterbegin',iconSvg(kind));
         break;
       }
     }
   });
 }
 let queued=false;
 const mo=new MutationObserver(()=>{if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;normalize()})});
 function start(){normalize();if(!window.__emmelliIconObserverV124){window.__emmelliIconObserverV124=true;mo.observe(document.body,{subtree:true,childList:true})}}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();


// ===== v115 EXACT COMPONENT → WEIGH → CONTAINER WORKFLOW =====
// One source of truth: planned/actual ingredients -> named cooked component -> actual cooked grams -> actual container grams.
// Inventory is consumed only by Step 7. Saving/editing a container never consumes the recipe ingredients again.
function simpleCompKey(rn){return selectedKey()+"|"+rn}
function simpleCompState(rn,r){
  state.simpleCookComponents=state.simpleCookComponents||{};
  let key=simpleCompKey(rn), defs=recipeComponentDefs(rn,r);
  let box=state.simpleCookComponents[key]||(state.simpleCookComponents[key]={});
  defs.forEach(comp=>{
    let c=box[comp.id]||(box[comp.id]={label:comp.label,ingredients:[],extras:[],cooked:false,total:""});
    c.label=comp.label;
    if(!c.ingredients.length){c.ingredients=comp.ix.filter(i=>r.ingredients?.[i]!=null).map(i=>({recipeIndex:i,name:r.ingredients[i],grams:"",removed:false}));}
  });
  return box;
}
function simpleComponentCard(rn,ri,r,comp,count){
  let box=simpleCompState(rn,r),c=box[comp.id];
  let suggested=Number(c.total)>0?(Number(c.total)/count).toFixed(1):null;
  return `<details class="component-card simple-component"><summary><span>${esc(comp.label)}</span><span class="category-count">${c.cooked&&Number(c.total)>0?'SAVED ✓':'OPEN'}</span></summary><div class="component-body">
    <div class="simple-section-title">INGREDIENTS</div>
    <div class="simple-ingredient-list">${c.ingredients.map((x,ii)=>`<div class="simple-ing-row ${x.removed?'is-removed':''}"><div class="simple-ing-name">${esc(x.name)}</div><label>GRAMS<input type="number" min="0" step=".1" data-simple-ing-grams="${ri}|${esc(comp.id)}|${ii}" value="${esc(x.grams??'')}" placeholder="g"></label><button class="tinybtn" data-simple-ing-remove="${ri}|${esc(comp.id)}|${ii}">${x.removed?'RESTORE':'REMOVE'}</button></div>`).join('')}</div>
    <button class="tinybtn" data-simple-ing-add="${ri}|${esc(comp.id)}">+ ADD INGREDIENT</button>
    ${(c.extras||[]).map((x,ei)=>`<div class="simple-ing-row"><label class="wide">ADDED INGREDIENT<input data-simple-extra="${ri}|${esc(comp.id)}|${ei}|name" value="${esc(x.name||'')}" placeholder="Ingredient / product"></label><label>GRAMS<input type="number" min="0" step=".1" data-simple-extra="${ri}|${esc(comp.id)}|${ei}|grams" value="${esc(x.grams??'')}" placeholder="g"></label><button class="tinybtn" data-simple-extra-remove="${ri}|${esc(comp.id)}|${ei}">REMOVE</button></div>`).join('')}
    <div class="simple-cooked-box"><label class="checkrow"><input type="checkbox" data-simple-cooked="${ri}|${esc(comp.id)}" ${c.cooked?'checked':''}><span><b>COOKED AS INSTRUCTED</b></span></label>
    <label><b>TOTAL COOKED WEIGHT (G)</b><input type="number" min="0" step=".1" data-simple-total="${ri}|${esc(comp.id)}" value="${esc(c.total??'')}" placeholder="Put the whole cooked component on the scale"></label>
    <div class="portion-count-banner"><b>${count} CONTAINERS</b><span>${suggested?`SUGGESTED: ${suggested} g ${esc(comp.label)} PER CONTAINER`:'Enter cooked weight to calculate suggestion'}</span></div></div>
    <div class="simple-save-status">${c.cooked&&Number(c.total)>0?'<b>COMPONENT SAVED ✓</b><br><span class="muted">Available in Portion + Label + Store.</span>':'Check cooked as instructed + enter cooked weight to save this component.'}</div>
  </div></details>`;
}
function simplePrepUI(){
 let names=(todayMeal()?.cook||[]).map(cookRecipeName);
 return names.map((rn,ri)=>{let r=MEAL.recipes?.[rn],defs=recipeComponentDefs(rn,r),count=Math.max(1,(cookAssignments(rn)||[]).length);simpleCompState(rn,r);return `<div class="card soft"><h3>${esc(rn)}</h3><p class="muted">Open a component. Edit/remove ingredient grams only if needed, or add an ingredient. Then enter that component's cooked weight.</p>${defs.map(c=>simpleComponentCard(rn,ri,r,c,count)).join('')}</div>`}).join('');
}
function simpleMeasureUI(){
 let names=(todayMeal()?.cook||[]).map(cookRecipeName);
 return names.map((rn,ri)=>{let r=MEAL.recipes?.[rn],defs=recipeComponentDefs(rn,r),box=simpleCompState(rn,r),count=Math.max(1,(cookAssignments(rn)||[]).length);return `<div class="card soft"><h3>${esc(rn)} — COOKED COMPONENTS</h3>${defs.map(c=>{let s=box[c.id],v=Number(s.total)||0;return `<div class="simple-measure-row"><b>${esc(c.label)}</b><span>${v?v.toFixed(1)+' g cooked':'not weighed yet'}</span><span>${v?'→ suggested '+(v/count).toFixed(1)+' g × '+count+' containers':''}</span><span>${s.cooked&&v?'SAVED ✓':''}</span></div>`}).join('')}</div>`}).join('');
}
function simplePortionUI(){
 let names=(todayMeal()?.cook||[]).map(cookRecipeName);
 return names.map((rn,ri)=>{let r=MEAL.recipes?.[rn],defs=recipeComponentDefs(rn,r),box=simpleCompState(rn,r),targets=cookAssignments(rn)||[],count=Math.max(1,targets.length),key=selectedKey()+"|"+rn;let saved=defs.filter(c=>box[c.id]?.cooked&&Number(box[c.id]?.total)>0);return `<div class="card soft"><div class="portion-count-banner"><b>${count} CONTAINERS</b><span>${esc(rn)}</span></div><p class="muted">Choose a saved component, then enter the ACTUAL grams your scale says are in that container. Those actual grams lock in the container macros.</p>${Array.from({length:count},(_,ci)=>{let d=containerDraftV84(key,ci),target=targets[ci]||{date:selectedKey(),meal:'MEAL'};return `<details class="container-edit"><summary>CONTAINER ${ci+1} OF ${count} • ${esc(shortDayDate(target.date||selectedKey()))} ${esc(target.meal||'MEAL')}</summary><div class="ingredient-edit-body"><div class="simple-container-components">${saved.length?saved.map(c=>{let s=box[c.id],sug=(Number(s.total)/count).toFixed(1);return `<div class="simple-container-row"><label class="checkrow"><input type="checkbox" data-simple-container-use="${esc(key)}|${ci}|${esc(c.id)}" ${d.components?.[c.id]!==undefined?'checked':''}><span><b>${esc(c.label)}</b><br><small>suggested ${sug} g</small></span></label><label>ACTUAL G<input type="number" min="0" step=".1" data-v92-portion="${esc(key)}|${ci}|${esc(c.id)}" value="${esc(d.components?.[c.id]??'')}" placeholder="scale weight"></label></div>`}).join(''):'<div class="sheet-note">Finish and save a cooked component first.</div>'}</div><details class="ingredient-edit"><summary>+ ADD SOMETHING ONLY TO THIS CONTAINER</summary><div class="ingredient-edit-body"><button class="tinybtn" data-v84-extra-add="${esc(key)}|${ci}">+ ADD ITEM</button>${(d.extras||[]).map((x,ei)=>`<div class="inventory-match"><label>ITEM<input data-v84-extra="${esc(key)}|${ci}|${ei}|name" value="${esc(x.name||'')}" placeholder="Inventory, brand, or generic food"></label><label>ACTUAL GRAMS<input type="number" min="0" step=".1" data-v84-extra="${esc(key)}|${ci}|${ei}|grams" value="${esc(x.grams??'')}"></label><label>SOURCE<select data-v108-container-source="${esc(key)}|${ci}|${ei}"><option value="">Generic / nutrition lookup</option>${inventoryFlat().map(z=>`<option value="${esc(z.cat)}|${z.i}" ${x.source===z.cat+'|'+z.i?'selected':''}>${esc(z.name)} — ${esc(z.cat)}</option>`).join('')}</select></label><button class="tinybtn" data-v90-lookup-container="${esc(key)}|${ci}|${ei}">NUTRITION LOOKUP</button><button class="tinybtn" data-v84-extra-remove="${esc(key)}|${ci}|${ei}">REMOVE</button></div>`).join('')}</div></details><div class="macro-preview"><b>CONTAINER MACROS</b><br>Calculated from the actual grams entered for the saved components + any container-only additions.</div><button class="btn primary" data-v92-add-label="${esc(key)}|${ci}">SAVE TO INVENTORY → CONTAINERS</button></div></details>`}).join('')}</div>`}).join('');
}
// Obsolete Cooking renderer wrapper removed during canonical cleanup.

function simpleCtx(ri,cid){let rn=cookRecipeName(todayMeal()?.cook?.[+ri]||''),r=MEAL.recipes?.[rn],box=simpleCompState(rn,r);return {rn,r,box,c:box[cid]}}
document.addEventListener('input',e=>{let t=e.target,ds=t.dataset;if(ds.simpleIngGrams!==undefined){let [ri,cid,ii]=ds.simpleIngGrams.split('|'),x=simpleCtx(ri,cid);x.c.ingredients[+ii].grams=t.value;save()}if(ds.simpleExtra!==undefined){let [ri,cid,ei,f]=ds.simpleExtra.split('|'),x=simpleCtx(ri,cid);x.c.extras[+ei][f]=t.value;save()}if(ds.simpleTotal!==undefined){let [ri,cid]=ds.simpleTotal.split('|'),x=simpleCtx(ri,cid);x.c.total=t.value;state.cookComponents=state.cookComponents||{};let k=simpleCompKey(x.rn);state.cookComponents[k]=state.cookComponents[k]||{};state.cookComponents[k][cid]=state.cookComponents[k][cid]||{};state.cookComponents[k][cid].total=t.value;save();render()}});
document.addEventListener('change',e=>{let t=e.target;if(t.dataset.simpleCooked!==undefined){let [ri,cid]=t.dataset.simpleCooked.split('|'),x=simpleCtx(ri,cid);x.c.cooked=!!t.checked;state.cookComponents=state.cookComponents||{};let k=simpleCompKey(x.rn);state.cookComponents[k]=state.cookComponents[k]||{};state.cookComponents[k][cid]=state.cookComponents[k][cid]||{};state.cookComponents[k][cid].usedPlanned=!!t.checked;save();render()}if(t.dataset.simpleContainerUse!==undefined){let [key,ci,cid]=t.dataset.simpleContainerUse.split('|'),d=containerDraftV84(key,+ci);if(t.checked&&d.components[cid]===undefined)d.components[cid]='';if(!t.checked)delete d.components[cid];save();render()}});
document.addEventListener('click',e=>{let t=e.target.closest?.('button');if(!t)return;if(t.dataset.simpleIngRemove!==undefined){let [ri,cid,ii]=t.dataset.simpleIngRemove.split('|'),x=simpleCtx(ri,cid);x.c.ingredients[+ii].removed=!x.c.ingredients[+ii].removed;save();render()}if(t.dataset.simpleIngAdd!==undefined){let [ri,cid]=t.dataset.simpleIngAdd.split('|'),x=simpleCtx(ri,cid);x.c.extras=x.c.extras||[];x.c.extras.push({name:'',grams:''});save();render()}if(t.dataset.simpleExtraRemove!==undefined){let [ri,cid,ei]=t.dataset.simpleExtraRemove.split('|'),x=simpleCtx(ri,cid);x.c.extras.splice(+ei,1);save();render()}});
window.__EMMELLI_COOK_BUILD='SIMPLE-COMPONENT-FIRST-2026-10-01';


// ===== FINAL PREP VESSEL CHECKLIST — meal-scoped, not cooking completion =====
// Prep bowls / paper plates are setup checks only. They are deliberately separate from
// component cooked/save state so checking a vessel never means the food was cooked.
function prepVesselChecklistFinal(){
  const names=(todayMeal()?.cook||[]).map(cookRecipeName);
  return names.map((rn,ri)=>{
    const r=MEAL.recipes?.[rn];
    const rows=prefixedBowls(rn,r);
    return `<div class="card soft prep-vessel-meal"><h3>${esc(rn)} — BOWLS / PLATES</h3><p class="muted">SETUP CHECKLIST ONLY — these checks do not mark a component cooked.</p>${rows.map((row,vi)=>{
      const m=String(row).match(/^(.+? — )(Paper Plate|Large Bowl|Bowl)\s+(\d+):(.*)$/i);
      let label=row;
      if(m){ label=`${m[1]}${m[2]} ${m[3]}:${m[4]}`; }
      const key=`prepVessel|${selectedKey()}|${rn}|${vi}`;
      return `<label class="checkrow prep-vessel-row"><input type="checkbox" data-prep-vessel-check="${esc(key)}" ${state.checks?.[key]?'checked':''}><span><b>${esc(label)}</b></span></label>`;
    }).join('')}</div>`;
  }).join('');
}
// Obsolete Cooking renderer wrapper removed during canonical cleanup.

document.addEventListener('change',e=>{let t=e.target;if(t.dataset.prepVesselCheck!==undefined){state.checks=state.checks||{};state.checks[t.dataset.prepVesselCheck]=!!t.checked;save();}});
window.__EMMELLI_PREP_BUILD='MEAL-SCOPED-VESSEL-CHECKS-2026-10-01';


// ===== FINAL COMPONENT PIPELINE V2 — AUTHORITATIVE LAST RENDERER =====
// Step 3 = prep vessels only. Step 4 = one combined chronological cook timeline.
// Step 5 = component truth + ingredient use + cooked weight + save component.
// Step 6 = labels/containers assembled from saved components. Inventory is committed once at component save/final sync, never again for component grams in containers.
function cpv2Key(rn){return selectedKey()+"|"+rn}
function cpv2Box(rn,r){
  state.cpv2=state.cpv2||{}; const key=cpv2Key(rn), defs=recipeComponentDefs(rn,r); const box=state.cpv2[key]||(state.cpv2[key]={components:{},containers:{}});
  box.components=box.components||{}; box.containers=box.containers||{};
  defs.forEach(comp=>{let c=box.components[comp.id]||(box.components[comp.id]={label:comp.label,ingredients:[],cookedWeight:"",usedAll:false,saved:false}); c.label=comp.label;
    if(!c.ingredients.length)c.ingredients=comp.ix.filter(i=>r.ingredients?.[i]!=null).map(i=>({name:r.ingredients[i],grams:"",removed:false,source:"planned",when:"before",inventoryCommitted:false}));
  }); return box;
}
function cpv2Count(rn){return Math.max(1,(cookAssignments(rn)||[]).length)}
function cpv2Prep(){return prepVesselChecklistFinal()}
function cpv2Timeline(){
 const names=(todayMeal()?.cook||[]).map(cookRecipeName), rows=[];
 names.forEach(rn=>{let r=MEAL.recipes?.[rn]; (r?.timeline||r?.cook||[]).forEach(x=>rows.push({rn,x}))});
 if(!rows.length){return `<div class="sheet-note">Follow the combined cooking instructions below in the order shown. Bowl names tell you what to grab; the steps are one shared timeline, not separate meal sections.</div>`}
 return `<div class="card soft"><h3>COOK BOTH MEALS — ONE TIMELINE</h3><p class="muted">Work straight down this list. Bowl names identify contents so you do not have to remember numbers.</p>${rows.map((z,i)=>`<div class="cook-line"><b>STEP ${i+1}</b><br>${esc(typeof z.x==='string'?z.x:(z.x.what||z.x.step||JSON.stringify(z.x)))}</div>`).join('')}</div>`;
}
function cpv2IngredientRow(rn,ri,cid,ii,x){
 return `<div class="simple-ing-row ${x.removed?'is-removed':''}"><div class="simple-ing-name"><b>${esc(x.name)}</b></div><label>GRAMS<input type="number" min="0" step=".1" data-cpv2-ing="${ri}|${esc(cid)}|${ii}|grams" value="${esc(x.grams??'')}" placeholder="g used"></label><label>SOURCE<select data-cpv2-ing="${ri}|${esc(cid)}|${ii}|source"><option value="planned" ${x.source==='planned'?'selected':''}>Planned / recipe</option><option value="inventory" ${x.source==='inventory'?'selected':''}>Inventory</option><option value="generic" ${x.source==='generic'?'selected':''}>Generic</option><option value="lookup" ${x.source==='lookup'?'selected':''}>Nutrition lookup</option></select></label><label>WHEN<select data-cpv2-ing="${ri}|${esc(cid)}|${ii}|when"><option value="before" ${x.when==='before'?'selected':''}>Before cooking</option><option value="during" ${x.when==='during'?'selected':''}>While cooking</option><option value="after" ${x.when==='after'?'selected':''}>After cooking</option></select></label><button class="tinybtn" data-cpv2-remove="${ri}|${esc(cid)}|${ii}">${x.removed?'RESTORE':'REMOVE'}</button></div>`
}
function cpv2Measure(){
 const names=(todayMeal()?.cook||[]).map(cookRecipeName);
 return names.map((rn,ri)=>{const r=MEAL.recipes?.[rn],box=cpv2Box(rn,r),defs=recipeComponentDefs(rn,r),count=cpv2Count(rn);
  return `<div class="card soft"><h3>${esc(rn)} — COMPONENTS</h3><p class="muted">Open one component. Confirm/edit exactly what went into it, then enter the whole cooked weight. Saving the component locks its ingredient basis and makes it available to Containers.</p>${defs.map(comp=>{let c=box.components[comp.id],wt=Number(c.cookedWeight)||0,sug=wt?wt/count:0;return `<details class="component-card"><summary><span>${esc(comp.label)}</span><span class="category-count">${c.saved?'SAVED ✓':'OPEN'}</span></summary><div class="component-body"><label class="checkrow"><input type="checkbox" data-cpv2-all="${ri}|${esc(comp.id)}" ${c.usedAll?'checked':''}><span><b>USED INGREDIENTS AS LISTED</b></span></label><div class="simple-ingredient-list">${c.ingredients.map((x,ii)=>cpv2IngredientRow(rn,ri,comp.id,ii,x)).join('')}</div><button class="tinybtn" data-cpv2-add="${ri}|${esc(comp.id)}">+ ADD INGREDIENT</button><div class="simple-cooked-box"><label><b>TOTAL COOKED WEIGHT — ${esc(comp.label)} (G)</b><input type="number" min="0" step=".1" data-cpv2-weight="${ri}|${esc(comp.id)}" value="${esc(c.cookedWeight??'')}" placeholder="whole cooked component"></label><div class="portion-count-banner"><b>${count} CONTAINERS</b><span>${wt?`SUGGESTED PER CONTAINER: ${sug.toFixed(1)} g`:'Enter cooked weight to calculate suggestion'}</span></div><p class="muted">Suggestion only. If some mix is lost while portioning, do not subtract a special amount here. Containers use the actual grams that make it into each one.</p><button class="btn primary" data-cpv2-save="${ri}|${esc(comp.id)}">${c.saved?'COMPONENT SAVED ✓':'SAVE COMPONENT'}</button></div></div></details>`}).join('')}</div>`
 }).join('')
}
function cpv2Label(target,rn){let d=target?.date||selectedKey(), meal=(target?.meal||'MEAL').toUpperCase(); let dt=new Date(d+'T12:00:00'); let day=dt.toLocaleDateString('en-US',{weekday:'short'}).toUpperCase(), date=dt.toLocaleDateString('en-US',{month:'numeric',day:'numeric',year:'numeric'}); return `${day} ${date} • ${meal} • ${rn}`}
function cpv2Portion(){
 const names=(todayMeal()?.cook||[]).map(cookRecipeName);
 return names.map((rn,ri)=>{const r=MEAL.recipes?.[rn],box=cpv2Box(rn,r),defs=recipeComponentDefs(rn,r),saved=defs.filter(d=>box.components[d.id]?.saved),targets=cookAssignments(rn)||[],count=cpv2Count(rn);
  return `<div class="card soft"><div class="portion-count-banner"><b>${count} CONTAINERS</b><span>${esc(rn)}</span></div><p class="muted">Add the suggested label, then add saved components and enter the ACTUAL grams in that container. Actual grams lock the macros. Saved component ingredients are not deducted again here.</p>${Array.from({length:count},(_,ci)=>{let target=targets[ci]||{date:selectedKey(),meal:'MEAL'}, c=box.containers[ci]||(box.containers[ci]={label:'',parts:{},extras:[],saved:false}); let suggested=cpv2Label(target,rn);return `<details class="container-edit"><summary>CONTAINER ${ci+1} OF ${count}${c.saved?' • SAVED ✓':''}</summary><div class="ingredient-edit-body"><div class="label-preview"><b>SUGGESTED LABEL</b><br>${esc(suggested)}</div><button class="tinybtn" data-cpv2-label="${ri}|${ci}" data-label-text="${esc(suggested)}">ADD LABEL</button>${c.label?`<div class="inventory-match"><b>LABEL ADDED</b><br>${esc(c.label)}</div>`:''}<div class="simple-section-title">ADD SAVED COMPONENTS</div>${saved.length?saved.map(comp=>{let cc=box.components[comp.id],sug=(Number(cc.cookedWeight)||0)/count;return `<div class="simple-container-row"><div><b>${esc(comp.label)}</b><br><small>suggested ${sug.toFixed(1)} g</small></div><label>ACTUAL G<input type="number" min="0" step=".1" data-cpv2-part="${ri}|${ci}|${esc(comp.id)}" value="${esc(c.parts?.[comp.id]??'')}" placeholder="scale weight"></label></div>`}).join(''):'<div class="sheet-note">Save a component in Measurements first.</div>'}<div class="simple-section-title">CONTAINER-ONLY ADDITIONS</div><button class="tinybtn" data-cpv2-extra-add="${ri}|${ci}">+ INVENTORY / GENERIC / NUTRITION LOOKUP</button>${(c.extras||[]).map((x,ei)=>`<div class="simple-ing-row"><label class="wide">ITEM<input data-cpv2-extra="${ri}|${ci}|${ei}|name" value="${esc(x.name||'')}"></label><label>GRAMS<input type="number" min="0" step=".1" data-cpv2-extra="${ri}|${ci}|${ei}|grams" value="${esc(x.grams??'')}"></label><label>SOURCE<select data-cpv2-extra="${ri}|${ci}|${ei}|source"><option value="inventory" ${x.source==='inventory'?'selected':''}>Inventory</option><option value="generic" ${x.source==='generic'?'selected':''}>Generic</option><option value="lookup" ${x.source==='lookup'?'selected':''}>Nutrition lookup</option></select></label><button class="tinybtn" data-cpv2-extra-remove="${ri}|${ci}|${ei}">REMOVE</button></div>`).join('')}<div class="macro-preview"><b>CONTAINER MACROS</b><br>Locked from actual grams of saved components + container-only additions.</div><button class="btn primary" data-cpv2-container-save="${ri}|${ci}">SAVE CONTAINER → INVENTORY</button></div></details>`}).join('')}</div>`
 }).join('')
}
// Obsolete Cooking renderer wrapper removed during canonical cleanup.

function cpv2Ctx(ri,cid){let rn=cookRecipeName(todayMeal()?.cook?.[+ri]||''),r=MEAL.recipes?.[rn],box=cpv2Box(rn,r);return {rn,r,box,c:box.components[cid]}}
document.addEventListener('input',e=>{let d=e.target.dataset;if(d.cpv2Ing!==undefined){let [ri,cid,ii,f]=d.cpv2Ing.split('|'),x=cpv2Ctx(ri,cid);x.c.ingredients[+ii][f]=e.target.value;x.c.saved=false;save()}if(d.cpv2Weight!==undefined){let [ri,cid]=d.cpv2Weight.split('|'),x=cpv2Ctx(ri,cid);x.c.cookedWeight=e.target.value;x.c.saved=false;save();let count=cpv2Count(x.rn),wt=Number(e.target.value)||0,box=e.target.closest('.simple-cooked-box')?.querySelector('.portion-count-banner span');if(box)box.textContent=wt?`SUGGESTED PER CONTAINER: ${(wt/count).toFixed(1)} g`:'Enter cooked weight to calculate'}if(d.cpv2Part!==undefined){let [ri,ci,cid]=d.cpv2Part.split('|'),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||''),r=MEAL.recipes?.[rn],b=cpv2Box(rn,r),c=b.containers[+ci]||(b.containers[+ci]={label:'',parts:{},extras:[],saved:false});c.parts=c.parts||{};c.parts[cid]=e.target.value;c.saved=false;save()}if(d.cpv2Extra!==undefined){let [ri,ci,ei,f]=d.cpv2Extra.split('|'),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||''),r=MEAL.recipes?.[rn],b=cpv2Box(rn,r),c=b.containers[+ci];c.extras[+ei][f]=e.target.value;c.saved=false;save()}});
document.addEventListener('change',e=>{let d=e.target.dataset;if(d.cpv2All!==undefined){let [ri,cid]=d.cpv2All.split('|'),x=cpv2Ctx(ri,cid);x.c.usedAll=!!e.target.checked;x.c.saved=false;save()}if(d.cpv2Ing!==undefined){let [ri,cid,ii,f]=d.cpv2Ing.split('|'),x=cpv2Ctx(ri,cid);x.c.ingredients[+ii][f]=e.target.value;x.c.saved=false;save()}});
document.addEventListener('click',e=>{let t=e.target.closest?.('button');if(!t)return;let d=t.dataset;
 if(d.cpv2Remove!==undefined){let [ri,cid,ii]=d.cpv2Remove.split('|'),x=cpv2Ctx(ri,cid);x.c.ingredients[+ii].removed=!x.c.ingredients[+ii].removed;x.c.saved=false;save();render()}
 if(d.cpv2Add!==undefined){let [ri,cid]=d.cpv2Add.split('|'),x=cpv2Ctx(ri,cid);x.c.ingredients.push({name:'NEW INGREDIENT',grams:'',removed:false,source:'inventory',when:'before',inventoryCommitted:false});x.c.saved=false;save();render()}
 if(d.cpv2Save!==undefined){let [ri,cid]=d.cpv2Save.split('|'),x=cpv2Ctx(ri,cid);if(!(Number(x.c.cookedWeight)>0)){showToast('Enter the total cooked weight first.','Component not saved');return}x.c.saved=true;x.c.savedAt=new Date().toISOString();x.c.ingredients.forEach(z=>{if(!z.removed&&z.source==='inventory')z.inventoryCommitted=true});save();render();showToast(x.c.label+' saved.','Component ready')}
 if(d.cpv2Label!==undefined){let [ri,ci]=d.cpv2Label.split('|'),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||''),r=MEAL.recipes?.[rn],b=cpv2Box(rn,r),c=b.containers[+ci]||(b.containers[+ci]={label:'',parts:{},extras:[],saved:false});c.label=d.labelText||'';save();render()}
 if(d.cpv2ExtraAdd!==undefined){let [ri,ci]=d.cpv2ExtraAdd.split('|'),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||''),r=MEAL.recipes?.[rn],b=cpv2Box(rn,r),c=b.containers[+ci]||(b.containers[+ci]={label:'',parts:{},extras:[],saved:false});c.extras=c.extras||[];c.extras.push({name:'',grams:'',source:'inventory',inventoryCommitted:false});save();render()}
 if(d.cpv2ExtraRemove!==undefined){let [ri,ci,ei]=d.cpv2ExtraRemove.split('|'),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||''),r=MEAL.recipes?.[rn],b=cpv2Box(rn,r),c=b.containers[+ci];c.extras.splice(+ei,1);save();render()}
 if(d.cpv2ContainerSave!==undefined){let [ri,ci]=d.cpv2ContainerSave.split('|'),rn=cookRecipeName(todayMeal()?.cook?.[+ri]||''),r=MEAL.recipes?.[rn],b=cpv2Box(rn,r),c=b.containers[+ci];if(!c.label){showToast('Add the suggested label first.','Label needed');return}c.saved=true;c.savedAt=new Date().toISOString();(c.extras||[]).forEach(z=>{if(z.source==='inventory')z.inventoryCommitted=true});save();render();showToast('Container saved to Containers.','Saved')}
});
window.__EMMELLI_COOK_BUILD='COMPONENT-PIPELINE-V2-2026-10-01';

// ===== OBSOLETE COOKING RENDERERS REMOVED — AUTHORITATIVE V7 ONLY =====

// ===== FINAL AUTHORITATIVE EMERGENCY MODE V130 =====
// One rent-cycle checklist from the live-balance anchor through the SECOND TUESDAY
// of the month after the rent month. Skipping an occurrence changes projections only;
// it never marks the autopay paid or deletes its recurrence. Occurrence edits use the
// same autopay override source used everywhere else in Budget.
function secondTuesdayAfterRentV130(due){
  let y=due.getFullYear(),m=due.getMonth()+1;
  if(m>11){m=0;y++}
  return secondTuesdayDate(y,m);
}
function emergencyCycleV130(y,m){
  let due=new Date(y,m,1,12),deadline=secondTuesdayAfterRentV130(due);
  return {due,deadline,id:`${y}-${m}`,target:rentAmountForDue(due)};
}
function emergencyRowsV130(y,m){
  let c=emergencyCycleV130(y,m),anchor=new Date((state.budget.balanceAsOf||localDateKey())+"T12:00:00"),rows=[];
  let cy=anchor.getFullYear(),cm=anchor.getMonth();
  while(cy<c.deadline.getFullYear()||(cy===c.deadline.getFullYear()&&cm<=c.deadline.getMonth())){
    monthRows(cy,cm).forEach(x=>{
      if(x.n==="Rent"||x.date<=anchor||x.date>c.deadline)return;
      let key=autopayKey(x); if(state.checks[key])return;
      rows.push({...x,key});
    });
    cm++;if(cm>11){cm=0;cy++}
  }
  return rows.sort((a,b)=>a.date-b.date);
}
function emergencyIncomeEventsV130(start,end){
  let out=[],cy=start.getFullYear(),cm=start.getMonth();
  while(cy<end.getFullYear()||(cy===end.getFullYear()&&cm<=end.getMonth())){
    paydays(cy,cm).forEach(day=>{
      let date=new Date(cy,cm,day,12); if(date<=start||date>end)return;
      [["job1","Job #1",JOB_INCOME.job1],["job2","Job #2",JOB_INCOME.job2],["jeremiah","Jeremiah",JOB_INCOME.jeremiah]].forEach(([source,label,amount])=>{
        let key=incomeSourceKey(date,source); if(!state.checks[key])out.push({date,label,amount,kind:"income"});
      });
      out.push({date,label:"Weekly envelopes",amount:-WEEKLY_ENVELOPES,kind:"envelope"});
    });
    cm++;if(cm>11){cm=0;cy++}
  }
  return out;
}
function emergencyBillEventsV130(start,end,em,excludeRentDue=null){
  let out=[],cy=start.getFullYear(),cm=start.getMonth();
  while(cy<end.getFullYear()||(cy===end.getFullYear()&&cm<=end.getMonth())){
    monthRows(cy,cm).forEach(x=>{
      if(x.date<=start||x.date>end)return;
      if(x.n==="Rent")return; // rent is applied once at the chosen Tuesday
      let key=autopayKey(x); if(state.checks[key])return;
      let skipped=!!em?.skip?.[skipKey(x)],amt=skipped?0:effectiveAutopayAmount(x);
      out.push({date:x.date,label:x.n,amount:-amt,kind:"bill",skipped,row:x});
    });
    cm++;if(cm>11){cm=0;cy++}
  }
  return out;
}
function projectEmergencyToV130(y,m,end,includeRentAt=null){
  let c=emergencyCycleV130(y,m),em=state.budget.emergency[c.id]||{on:false,skip:{}},anchor=new Date((state.budget.balanceAsOf||localDateKey())+"T12:00:00"),bal=Number(state.budget.balance||0);
  let ev=[...emergencyIncomeEventsV130(anchor,end),...emergencyBillEventsV130(anchor,end,em,c.due)].sort((a,b)=>a.date-b.date||((a.kind==="income")?-1:1));
  ev.forEach(x=>bal+=x.amount);
  if(includeRentAt&&includeRentAt<=end)bal-=c.target;
  return Math.round(bal*100)/100;
}
function tuesdaysV130(start,end){let out=[],d=new Date(start);d.setHours(12,0,0,0);d.setDate(d.getDate()+((2-d.getDay()+7)%7));for(;d<=end;d.setDate(d.getDate()+7))out.push(new Date(d));return out}
function emergencyProjectionV130(y,m){
  let c=emergencyCycleV130(y,m),anchor=new Date((state.budget.balanceAsOf||localDateKey())+"T12:00:00"),candidates=tuesdaysV130(anchor,c.deadline),earliest=null,before=null;
  for(let t of candidates){let b=projectEmergencyToV130(y,m,t,null);if(b>=c.target){earliest=t;before=b;break}}
  let chosen=earliest||c.deadline,atChosen=before??projectEmergencyToV130(y,m,chosen,null),afterRent=Math.round((atChosen-c.target)*100)/100;
  let horizon=new Date(c.deadline.getFullYear(),c.deadline.getMonth()+1,0,12); // end of deadline month; includes Oct 22 card for Sep rent
  let afterUpcoming=projectEmergencyToV130(y,m,horizon,chosen);
  return {c,earliest,chosen,atChosen,afterRent,afterUpcoming,horizon};
}
// Correct the shared active-cycle deadline everywhere that consumes it.
activeRentCycle=function(now=new Date()){
  let due=new Date(now.getFullYear(),now.getMonth(),1,12);
  for(let guard=0;guard<12;guard++){
    let row={n:"Rent",a:NORMAL_RENT,baseA:NORMAL_RENT,date:new Date(due)};
    if(!state.checks[autopayKey(row)])break;
    due=new Date(due.getFullYear(),due.getMonth()+1,1,12);
  }
  return {due,deadline:secondTuesdayAfterRentV130(due),rentMonth:new Date(due),id:`${due.getFullYear()}-${due.getMonth()}`};
};
const _budgetToolBeforeEmergencyV130=budgetTool;
budgetTool=function(kind,y,m,parent="budget"){
  if(kind!=="emergency")return _budgetToolBeforeEmergencyV130(kind,y,m,parent);
  let c=emergencyCycleV130(y,m),em=state.budget.emergency[c.id]||(state.budget.emergency[c.id]={on:false,skip:{}}),rows=emergencyRowsV130(y,m),p=emergencyProjectionV130(y,m),monthName=c.due.toLocaleString("en",{month:"long",year:"numeric"}),backMarkup=parent==="month"?`<button class="btn back" data-budget-return="month:${y}:${m}">‹ ${esc(monthName)}</button>`:back("Budget");
  let freed=rows.filter(x=>em.skip?.[skipKey(x)]).reduce((s,x)=>s+effectiveAutopayAmount(x),0);
  let earliest=p.earliest?p.earliest.toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric"}):"NOT COVERED BY DEADLINE";
  return hero("Emergency Mode",`${monthName} rent • live projection`)+backMarkup+`
  <section class="card information-first"><h2>RENT PROJECTION</h2>
   <div class="budget-glance">
    <div class="mini-stat"><small>EARLIEST TUESDAY</small><b>${earliest}</b></div>
    <div class="mini-stat"><small>RENT TARGET</small><b>${money(c.target)}</b></div>
    <div class="mini-stat"><small>AFTER RENT</small><b>${money(p.afterRent)}</b></div>
    <div class="mini-stat"><small>AFTER UPCOMING OBLIGATIONS</small><b>${money(p.afterUpcoming)}</b></div>
   </div>
   <p class="muted">Latest allowed: <b>${c.deadline.toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric",year:"numeric"})}</b> — the second Tuesday of the month after this rent. “After upcoming obligations” projects through ${p.horizon.toLocaleDateString("en-US",{month:"long",day:"numeric"})}, so later obligations in that month such as Mom Payback and the October $300 Credit Card occurrence are included when scheduled.</p>
   <label class="checkrow"><input type="checkbox" data-emergency="${c.id}" ${em.on?'checked':''}><span><b>USE EMERGENCY MODE FOR THIS RENT CYCLE</b><small>Skip choices change this occurrence's projection only. They do not mark it paid or delete the recurring autopay.</small></span></label>
  </section>
  <section class="card"><div class="section-head"><div><h2>EMERGENCY AUTOPAYS</h2><p>LIVE BALANCE DATE → RENT DEADLINE • CROSSES MONTHS</p></div><b>${money(freed)} FREED</b></div>
   ${em.on?(rows.map(x=>{let sk=skipKey(x),checked=!!em.skip?.[sk],amt=effectiveAutopayAmount(x);return `<div class="autopay-row-v75"><input type="checkbox" data-skipbill-v130="${encodeURIComponent(c.id)}|${encodeURIComponent(sk)}" ${checked?'checked':''}><div class="autopay-primary"><b>${esc(x.n)}</b><span>${x.date.toLocaleDateString("en-US",{weekday:"short",month:"short",day:"numeric",year:"numeric"})} • ${money(amt)}</span><small>${checked?'SKIPPED FOR THIS RENT PROJECTION • NOT MARKED PAID':'INCLUDED IN PROJECTION'}</small></div><div class="autopay-actions"><button class="tinybtn autopay-edit" data-edit-autopay="${encodeURIComponent(localDateKey(x.date))}|${encodeURIComponent(x.n)}|${encodeURIComponent(String(x.baseA??x.a))}">EDIT</button></div></div>`}).join("")||'<p class="muted">No unpaid autopays fall between the live-balance date and this rent deadline.</p>'):'<p class="muted">Turn Emergency Mode on to choose which unpaid occurrences to skip for this rent projection.</p>'}
  </section>`;
};
document.addEventListener("change",e=>{let el=e.target;if(!el.dataset.skipbillV130)return;let [id,key]=el.dataset.skipbillV130.split("|").map(decodeURIComponent);state.budget.emergency[id]=state.budget.emergency[id]||{on:true,skip:{}};state.budget.emergency[id].on=true;state.budget.emergency[id].skip[key]=!!el.checked;save();render();});


// ===== FINAL AUTHORITATIVE RENT + PAYCHECK-WEEK EMERGENCY MODE V131 =====
// RENT: one calendar-month obligation beginning on the 1st.
// EMERGENCY: only extends that month's payment window through the second Tuesday of the NEXT month.
// AUTOPAYS: remain on their real due dates and are displayed in Wednesday→Tuesday paycheck weeks.
function rentMonthCycleV131(y,m){
  const due=new Date(y,m,1,12), deadline=secondTuesdayAfterRentV130(due);
  return {due,deadline,id:`${y}-${m}`,normal:NORMAL_RENT,emergency:EMERGENCY_RENT};
}
function paycheckWeekV131(date){
  let d=new Date(date); d.setHours(12,0,0,0);
  let back=(d.getDay()-3+7)%7; // Wednesday = 3
  let start=new Date(d); start.setDate(d.getDate()-back);
  let end=new Date(start); end.setDate(start.getDate()+6);
  return {start,end,key:localDateKey(start)};
}
function emergencyTargetV131(c,em){
  // Emergency Mode is specifically the late/emergency way of paying THIS calendar month's rent.
  if(em?.on)return c.emergency;
  let row={n:'Rent',a:NORMAL_RENT,baseA:NORMAL_RENT,date:new Date(c.due)};
  let ov=autopayOverrideAmount(row);
  return Number.isFinite(ov)?Math.max(0,ov):NORMAL_RENT;
}
function emergencyProjectionV131(y,m){
  const c=rentMonthCycleV131(y,m), em=state.budget.emergency[c.id]||{on:false,skip:{}}, target=emergencyTargetV131(c,em);
  const anchor=new Date((state.budget.balanceAsOf||localDateKey())+'T12:00:00');
  const candidates=tuesdaysV130(anchor,c.deadline); let earliest=null,before=null;
  const project=(end,rentAt=null)=>{
    let bal=Number(state.budget.balance||0);
    let ev=[...emergencyIncomeEventsV130(anchor,end),...emergencyBillEventsV130(anchor,end,em,c.due)].sort((a,b)=>a.date-b.date||((a.kind==='income')?-1:1));
    ev.forEach(x=>bal+=x.amount); if(rentAt&&rentAt<=end)bal-=target; return Math.round(bal*100)/100;
  };
  for(const t of candidates){let b=project(t);if(b>=target){earliest=t;before=b;break}}
  const chosen=earliest||c.deadline, atChosen=before??project(chosen), afterRent=Math.round((atChosen-target)*100)/100;
  const horizon=new Date(c.deadline.getFullYear(),c.deadline.getMonth()+1,0,12);
  return {c,em,target,anchor,earliest,chosen,atChosen,afterRent,afterUpcoming:project(horizon,chosen),horizon};
}
function emergencyRowsV131(y,m,cutoff){
  const p=emergencyProjectionV131(y,m), end=cutoff||p.chosen, rows=[];
  let cy=p.anchor.getFullYear(),cm=p.anchor.getMonth();
  while(cy<end.getFullYear()||(cy===end.getFullYear()&&cm<=end.getMonth())){
    monthRows(cy,cm).forEach(x=>{
      if(x.n==='Rent'||x.date<=p.anchor||x.date>end)return;
      const key=autopayKey(x); if(state.checks[key])return;
      rows.push({...x,key,week:paycheckWeekV131(x.date)});
    });
    cm++;if(cm>11){cm=0;cy++}
  }
  return rows.sort((a,b)=>a.date-b.date);
}
function emergencyRowsGroupedV131(rows,c,em){
  const groups=[];
  rows.forEach(x=>{let g=groups.find(z=>z.key===x.week.key);if(!g){g={...x.week,rows:[]};groups.push(g)}g.rows.push(x)});
  return groups.map(g=>`<div class="emergency-payweek"><div class="section-head"><div><h3>PAYCHECK WEEK</h3><p>${g.start.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'})} → ${g.end.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'})} • WEDNESDAY → TUESDAY</p></div></div>${g.rows.map(x=>{let sk=skipKey(x),checked=!!em.skip?.[sk],amt=effectiveAutopayAmount(x);return `<div class="autopay-row-v75"><input type="checkbox" data-skipbill-v131="${encodeURIComponent(c.id)}|${encodeURIComponent(sk)}" ${checked?'checked':''}><div class="autopay-primary"><b>${esc(x.n)}</b><span>${x.date.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'})} • ${money(amt)}</span><small>${checked?'SKIP THIS OCCURRENCE FOR THIS RENT PROJECTION':'INCLUDED IN THIS RENT PROJECTION'}</small></div><div class="autopay-actions"><button class="tinybtn autopay-edit" data-edit-autopay="${encodeURIComponent(localDateKey(x.date))}|${encodeURIComponent(x.n)}|${encodeURIComponent(String(x.baseA??x.a))}">EDIT</button></div></div>`}).join('')}</div>`).join('');
}
const _budgetToolBeforeEmergencyV131=budgetTool;
budgetTool=function(kind,y,m,parent='budget'){
  if(kind!=='emergency')return _budgetToolBeforeEmergencyV131(kind,y,m,parent);
  const p=emergencyProjectionV131(y,m),c=p.c,em=p.em,rows=emergencyRowsV131(y,m,p.chosen),monthName=c.due.toLocaleString('en',{month:'long',year:'numeric'}),backMarkup=parent==='month'?`<button class="btn back" data-budget-return="month:${y}:${m}">‹ ${esc(monthName)}</button>`:back('Budget');
  const freed=rows.filter(x=>em.skip?.[skipKey(x)]).reduce((s,x)=>s+effectiveAutopayAmount(x),0);
  const earliest=p.earliest?p.earliest.toLocaleDateString('en-US',{weekday:'long',month:'short',day:'numeric'}):'NOT COVERED BY DEADLINE';
  return hero('Emergency Mode',`${monthName} rent • calendar-month rent + paycheck-week autopays`)+backMarkup+`
  <section class="card information-first"><h2>${esc(monthName.toUpperCase())} RENT</h2>
   <p class="muted"><b>RENT CYCLE:</b> ${c.due.toLocaleString('en-US',{month:'long'})} 1 → ${new Date(y,m+1,0,12).toLocaleDateString('en-US',{month:'long',day:'numeric'})}. Emergency Mode does not move the rent into the next month; it only extends when this month's rent may be paid.</p>
   <div class="budget-glance"><div class="mini-stat"><small>EARLIEST TUESDAY</small><b>${earliest}</b></div><div class="mini-stat"><small>${em.on?'EMERGENCY RENT':'RENT'}</small><b>${money(p.target)}</b></div><div class="mini-stat"><small>LEFT AFTER RENT</small><b>${money(p.afterRent)}</b></div><div class="mini-stat"><small>AFTER UPCOMING OBLIGATIONS</small><b>${money(p.afterUpcoming)}</b></div></div>
   <p class="muted">Latest emergency payment date for this ${esc(monthName)} rent: <b>${c.deadline.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'})}</b>. Projection after upcoming obligations continues through ${p.horizon.toLocaleDateString('en-US',{month:'long',day:'numeric'})}, so scheduled items such as Mom Payback and the October-only $300 Credit Card payment are included when their actual dates fall there.</p>
   <label class="checkrow"><input type="checkbox" data-emergency="${c.id}" ${em.on?'checked':''}><span><b>USE EMERGENCY MODE FOR ${esc(monthName.toUpperCase())} RENT</b><small>${money(NORMAL_RENT)} normal • ${money(EMERGENCY_RENT)} emergency/late. This changes this rent projection only.</small></span></label>
  </section>
  <section class="card"><div class="section-head"><div><h2>EMERGENCY AUTOPAYS</h2><p>LIVE-BALANCE DATE → ${p.chosen.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'})} • GROUPED BY PAYCHECK WEEK</p></div><b>${money(freed)} FREED</b></div>
   <p class="muted">Autopay weeks stay <b>Wednesday → Tuesday</b> even when this list crosses into another calendar month. Checking a box means <b>skip only that occurrence for this emergency rent projection</b>. EDIT changes that same occurrence everywhere in Budget.</p>
   ${em.on?(emergencyRowsGroupedV131(rows,c,em)||'<p class="muted">No unpaid autopays fall before the projected rent Tuesday.</p>'):'<p class="muted">Turn Emergency Mode on to choose unpaid autopay occurrences to skip.</p>'}
  </section>`;
};
document.addEventListener('change',e=>{let el=e.target;if(!el.dataset.skipbillV131)return;let [id,key]=el.dataset.skipbillV131.split('|').map(decodeURIComponent);state.budget.emergency[id]=state.budget.emergency[id]||{on:true,skip:{}};state.budget.emergency[id].on=true;state.budget.emergency[id].skip[key]=!!el.checked;save();render();});
window.__EMMELLI_EMERGENCY_BUILD='RENT-CALENDAR-AUTOPAY-WED-TUE-V131-2026-10-01';


// ===== AUTHORITATIVE COOKING COORDINATOR V7 — OCTOBER 1 LIVE-COOK HANDOFF =====
window.__EMMELLI_COOKING_LABEL_BUILD='DINNER-SLASH-STORAGE-2026-10-01';
// One active UI path: GET OUT → PREP → READY → COOK TOGETHER → COMPONENT ACTUALS → PORTION/STORE → AUDIT.
function v7Ensure(){
 state.cookV7=state.cookV7&&typeof state.cookV7==='object'?state.cookV7:{};
 state.cookV7.sessions=state.cookV7.sessions&&typeof state.cookV7.sessions==='object'?state.cookV7.sessions:{};
 state.foodPreferences=state.foodPreferences&&typeof state.foodPreferences==='object'?state.foodPreferences:{};
 state.inventoryLifecycle=state.inventoryLifecycle&&typeof state.inventoryLifecycle==='object'?state.inventoryLifecycle:{};
 if(state.foodPreferences.avoidGroundChicken===undefined)state.foodPreferences.avoidGroundChicken=true;
 return state.cookV7;
}
function v7DateLabel(k){let d=new Date(k+'T12:00:00');return d.toLocaleDateString('en-US',{weekday:'short'}).toUpperCase().slice(0,3)+' '+String(d.getMonth()+1).padStart(2,'0')+'/'+String(d.getDate()).padStart(2,'0')+'/'+String(d.getFullYear()).slice(-2)}
function v7RecipeSource(rn){let r=MEAL.recipes?.[rn];return r?.source||''}
function v7RecipeCards(names){return `<div class="cook-v7-top">${names.map(rn=>`<div class="cook-v7-recipe"><div><b>${esc(rn.toUpperCase())}</b><div class="cook-v7-source">${esc((MEAL.recipes?.[rn]?.sourceLabel||'ORIGINAL VERIFIED RECIPE').toUpperCase())}</div></div>${v7RecipeSource(rn)?`<a class="tinybtn" href="${esc(v7RecipeSource(rn))}" target="_blank" rel="noopener">ORIGINAL RECIPE ↗</a>`:''}</div>`).join('')}</div>`}
function v7SessionNames(){
 if(selectedKey()==='2026-10-01')return ['Ham & Lentil Soup','Cheesy Cottage Pie','Chicken & Dumplings','Chicken Cobbler'];
 return (todayMeal()?.cook||[]).map(cookRecipeName);
}
function v7ActualName(rn){if(selectedKey()==='2026-10-01'&&rn==='Chicken & Dumplings')return 'CHICKEN + VEG/BROTH BASE';return rn.toUpperCase()}
function v7InventoryExact(raw){
 let all=[];for(let cat of ['Fridge','Freezer','Pantry','Seasonings'])for(let x of state.inventory?.[cat]||[])all.push({cat,x});
 let low=String(raw||'').toLowerCase();
 let pref=[];
 if(/carrot/.test(low))pref=['baby carrots'];
 else if(/celery/.test(low))pref=['celery'];
 else if(/onion/.test(low))pref=['onion'];
 else if(/garlic/.test(low))pref=['minced garlic','garlic'];
 else if(/fairlife|milk/.test(low))pref=['fairlife milk'];
 else if(/heavy cream/.test(low))pref=['heavy cream'];
 else if(/butter/.test(low))pref=['butter'];
 else if(/cheddar/.test(low))pref=['cheddar'];
 else if(/chicken stock|chicken broth/.test(low))pref=['chicken broth','chicken stock'];
 else if(/beef broth/.test(low))pref=['beef broth'];
 else if(/liquid aminos/.test(low))pref=['liquid aminos'];
 else if(/flour/.test(low))pref=['ap flour','flour'];
 else if(/lentil/.test(low))pref=['green lentils','lentils'];
 else if(/tomato paste/.test(low))pref=['tomato paste'];
 else if(/ground chicken/.test(low))pref=['ground chicken'];
 else if(/chicken/.test(low))pref=['frozen chicken','chicken'];
 else if(/ham/.test(low))pref=['honey ham','ham'];
 else if(/corn/.test(low))pref=['corn'];
 else if(/potato/.test(low))pref=['potato'];
 else if(/cornstarch/.test(low))pref=['cornstarch'];
 for(let p of pref){let hit=all.find(z=>String(z.x.name||'').toLowerCase().includes(p));if(hit)return {name:hit.x.name,cat:hit.cat,qty:hit.x.qty||''}}
 let cleaned=String(raw||'').replace(/^\s*[~≈]?\d+(?:\.\d+)?\s*(?:g|kg|ml|mL|oz|lb|cups?|tbsp|tsp)?\s*/i,'').replace(/\s*[—-].*$/,'').trim();
 return {name:cleaned||String(raw||''),cat:'Pantry',qty:''};
}
function v7GetOutGroups(names){
 let groups={FRIDGE:[],FREEZER:[],PRODUCE:[],PANTRY:[],SEASONINGS:[]};
 let seen=new Set();
 names.forEach(rn=>(MEAL.recipes?.[rn]?.ingredients||[]).forEach(raw=>{
   let hit=v7InventoryExact(raw),n=String(hit.name||'').toUpperCase(); if(!n||seen.has(n))return;seen.add(n);
   let k=/CARROT|CELERY|ONION|GARLIC|POTATO/.test(n)?'PRODUCE':hit.cat==='Fridge'?'FRIDGE':hit.cat==='Freezer'?'FREEZER':hit.cat==='Seasonings'?'SEASONINGS':'PANTRY'; groups[k].push(n);
 }));
 return groups;
}
function v7Stage1(names){let g=v7GetOutGroups(names),sess=v7Session();let expected=v7ExpectedContainers(sess);let sections=['FRIDGE','FREEZER','PRODUCE','PANTRY','SEASONINGS'];return `${sections.map(k=>`<details class="cook-v7-group"><summary>${k}</summary><div class="cook-v7-group-body">${g[k].length?g[k].map((x,i)=>v7Check(`getout|${k}|${i}`,x)).join(''):'<p class="muted">NOTHING REQUIRED.</p>'}</div></details>`).join('')}
<details class="cook-v7-group"><summary>COOKWARE + TOOLS</summary><div class="cook-v7-group-body">${['REQUIRED POTS','REQUIRED SKILLETS','BAKING DISH','CUTTING BOARD','KNIFE','MEASURING JUGS','APPROPRIATE PREP BOWLS','PAPER PLATES FOR MEAT','FOOD SCALE','FOOD THERMOMETER','COOKING UTENSILS'].map((x,i)=>v7Check(`getout|TOOLS|${i}`,x)).join('')}</div></details>
<details class="cook-v7-group"><summary>PORTION + STORAGE</summary><div class="cook-v7-group-body">${v7Check('getout|STORAGE|0',`GET ${expected} CONTAINERS + ${expected} MATCHING LIDS`)}${v7Check('getout|STORAGE|1','LABELING SUPPLIES')}</div></details>`}
function v7Check(key,label){let sess=v7Session();sess.checks=sess.checks||{};return `<label class="cook-v7-check"><input type="checkbox" data-v7-check="${esc(key)}" ${sess.checks[key]?'checked':''}><span>${esc(label)}</span></label>`}
function v7PrepDefs(){
 if(selectedKey()==='2026-10-01')return {
 'Ham & Lentil Soup':[
  {id:'soup-veg',title:'SOUP • BOWL 1 • VEGETABLES',lines:['WEIGH 114 G BABY CARROTS • CHOP','WEIGH 80 G ONION • CHOP','WEIGH 80 G CELERY • CHOP','ADD TO THIS BOWL']},
  {id:'soup-garlic',title:'SOUP • SMALL BOWL 2 • GARLIC',lines:['WEIGH 12 G MINCED GARLIC','KEEP SEPARATE SO IT DOES NOT GET LOST']},
  {id:'soup-lentils',title:'SOUP • BOWL 3 • LENTILS + SEASONING',lines:['WEIGH 180 G DRY GREEN LENTILS • RINSE','ADD 2 G THYME','ADD 2 G PAPRIKA']},
  {id:'soup-stock',title:'SOUP • JUG 1 • STOCK',lines:['POUR 720 ML CHICKEN STOCK DIRECTLY FROM CARTON']},
  {id:'soup-ham',title:'SOUP • PAPER PLATE 1 • HAM',lines:['WEIGH ACTUAL HAM','DICE AS DIRECTED']}
 ],
 'Cheesy Cottage Pie':[
  {id:'pie-potato',title:'COTTAGE PIE • BOWL 1 • POTATOES',lines:['WEIGH 500 G POTATOES','PEEL / CUT FOR BOILING']},
  {id:'pie-veg',title:'COTTAGE PIE • BOWL 2 • FILLING VEGETABLES',lines:['WEIGH 120 G CORN','WEIGH 114 G BABY CARROTS • CHOP','WEIGH 80 G ONION • CHOP']},
  {id:'pie-garlic',title:'COTTAGE PIE • SMALL BOWL 3 • GARLIC',lines:['WEIGH 12 G MINCED GARLIC']},
  {id:'pie-gravy',title:'COTTAGE PIE • JUG 1 • GRAVY',lines:['30 G TOMATO PASTE','300 ML BEEF BROTH','30 ML LIQUID AMINOS • ACTUAL MAY BE EDITED LATER','15 G FLOUR','WHISK SMOOTH']},
  {id:'pie-mash',title:'COTTAGE PIE • BOWL 4 • MASH FINISH',lines:['42 G BUTTER','120 ML FAIRLIFE MILK • ACTUAL MAY BE REPLACED','85 G CHEDDAR']},
  {id:'pie-meat',title:'COTTAGE PIE • PAPER PLATE 1 • GROUND CHICKEN',lines:['WEIGH 454 G BELL & EVANS GROUND CHICKEN','BREAK UP / SEASON AS DIRECTED']}
 ],
 'Chicken & Dumplings':[
  {id:'dum-veg',title:'DUMPLINGS • BOWL 1 • VEGETABLES',lines:['WEIGH 113 G BABY CARROTS • CHOP','WEIGH 80 G ONION • CHOP','WEIGH 80 G CELERY • CHOP']},
  {id:'dum-garlic',title:'DUMPLINGS • SMALL BOWL 2 • GARLIC',lines:['WEIGH 12 G MINCED GARLIC']},
  {id:'dum-stock',title:'DUMPLINGS • JUG 1 • BROTH BASE',lines:['POUR 480 ML CHICKEN STOCK DIRECTLY FROM CARTON','POUR 120 ML FAIRLIFE MILK IF USING PLANNED BASE']},
  {id:'dum-dry',title:'DUMPLINGS • BOWL 3 • DUMPLING DRY MIX',lines:['140 G FLOUR','8 G BAKING POWDER','2 G POULTRY SEASONING','1 G THYME','KEEP DRY UNTIL NEEDED']},
  {id:'dum-finish',title:'DUMPLINGS • BOWL 4 • DUMPLING FINISH',lines:['60 ML FAIRLIFE MILK','28 G BUTTER • MELT ONLY WHEN READY']},
  {id:'dum-panbutter',title:'DUMPLINGS • SMALL BOWL 5 • PAN BUTTER',lines:['14 G BUTTER']},
  {id:'dum-chicken',title:'DUMPLINGS • PAPER PLATE 1 • CHICKEN',lines:['WEIGH 454 G DETWILER’S CHICKEN','TRIM IF NEEDED','CUT TO REQUIRED SIZE','SEASON BEFORE HEAT']}
 ],
 'Chicken Cobbler':[
  {id:'cob-veg',title:'COBBLER • BOWL 1 • VEGETABLES',lines:['WEIGH 113 G BABY CARROTS • CHOP','WEIGH 80 G ONION • CHOP','WEIGH 120 G CORN']},
  {id:'cob-garlic',title:'COBBLER • SMALL BOWL 2 • GARLIC',lines:['WEIGH 12 G MINCED GARLIC']},
  {id:'cob-gravy',title:'COBBLER • JUG 1 • GRAVY',lines:['360 ML CHICKEN STOCK','180 ML FAIRLIFE MILK','20 G CORNSTARCH','WHISK SMOOTH']},
  {id:'cob-dry',title:'COBBLER • BOWL 3 • TOPPING DRY MIX',lines:['140 G FLOUR','8 G BAKING POWDER','2 G THYME','2 G POULTRY SEASONING','KEEP IDENTIFIED + DRY']},
  {id:'cob-chicken',title:'COBBLER • PAPER PLATE 1 • CHICKEN',lines:['WEIGH APPROX. 454 G DETWILER’S CHICKEN','TRIM / CUT BEFORE HEAT','SEASON AS DIRECTED']}
 ]};
 let out={};for(let rn of v7SessionNames()){let r=MEAL.recipes?.[rn];out[rn]=(r?.bowls||[]).map((b,i)=>({id:`${rn}|${i}`,title:(String(b).split(':')[0]||`${rn} • VESSEL ${i+1}`).toUpperCase(),lines:[String(b).split(':').slice(1).join(':').trim()||'PREP AS LISTED']}))}return out;
}
function v7Stage2(){let defs=v7PrepDefs();return Object.entries(defs).map(([rn,arr])=>`<details class="cook-v7-group"><summary>${esc(rn.toUpperCase())} • ${arr.filter(v=>v.lines.every((_,i)=>v7Session().checks?.[`prep|${v.id}|${i}`])).length}/${arr.length} PREP VESSELS READY</summary><div class="cook-v7-group-body">${v7RecipeSource(rn)?`<a class="tinybtn" href="${esc(v7RecipeSource(rn))}" target="_blank" rel="noopener">RECIPE ↗</a>`:''}${arr.map(v=>`<div class="cook-v7-vessel"><h4>${esc(v.title)}</h4>${v.lines.map((x,i)=>v7Check(`prep|${v.id}|${i}`,x)).join('')}</div>`).join('')}</div></details>`).join('')}
function v7ReadyAudit(){let defs=v7PrepDefs(),sess=v7Session(),missing=[];for(let [rn,arr] of Object.entries(defs))for(let v of arr)for(let i=0;i<v.lines.length;i++)if(!sess.checks?.[`prep|${v.id}|${i}`])missing.push(`${v.title} • ${v.lines[i]}`);let required=['getout|TOOLS|4','getout|TOOLS|7','getout|TOOLS|8','getout|STORAGE|0'];for(let k of required)if(!sess.checks?.[k])missing.push('REQUIRED EQUIPMENT / STORAGE ITEM NOT CHECKED');return [...new Set(missing)]}
function v7Stage3(){let m=v7ReadyAudit(),ready=!m.length;return `<div class="${ready?'cook-v7-ok':'cook-v7-warn'}">${ready?'READY TO COOK • 100%':`NOT READY • ${m.length} ITEM${m.length===1?'':'S'}`}</div>${m.length?`<div class="cook-v7-audit">${m.slice(0,20).map(x=>`<div class="cook-v7-warn">${esc(x)}</div>`).join('')}</div>`:`<div class="cook-v7-audit">${['EVERY PLANNED INGREDIENT ACCOUNTED FOR','MEAT PREPPED BEFORE HEAT','LIQUIDS / SAUCES ASSIGNED','NO MYSTERY BOWLS / JUGS','COOKWARE + THERMOMETER + SCALE READY','CONTAINERS READY'].map(x=>`<div class="cook-v7-ok">✓ ${x}</div>`).join('')}</div>`}<div class="cook-v7-pillrow" style="margin-top:10px"><button class="btn primary" data-v7-start ${ready?'':'disabled'}>START COOKING</button>${!ready?`<button class="btn" data-v7-start-anyway>START ANYWAY</button>`:''}</div>`}
function v7TimelineRows(){if(selectedKey()==='2026-10-01')return [
 ['ALL RECIPES','OVEN + STOVETOP','PREHEAT OVEN TO 400°F. SET OUT SOUP POT, COTTAGE-PIE POT/SKILLET, AND CHICKEN-BASE POT.','400°F / BURNERS OFF','PREHEAT','OVEN READY','START POTATO WATER + SOUP NEXT.'],
 ['HAM & LENTIL SOUP','SOUP POT','MELT 14 G BUTTER. ADD SOUP • BOWL 1 • VEGETABLES. COOK 5–6 MINUTES. ADD SOUP • SMALL BOWL 2 • GARLIC FOR THE FINAL 30–60 SECONDS.','MEDIUM','6–8 MIN','VEGETABLES SOFTENING; GARLIC FRAGRANT','START COTTAGE-PIE POTATOES.'],
 ['CHEESY COTTAGE PIE','POT + SKILLET','START COTTAGE PIE • BOWL 1 • POTATOES IN COLD WATER. BROWN COTTAGE PIE • PAPER PLATE 1 • GROUND CHICKEN.','HIGH → SIMMER / MEDIUM-HIGH','12–18 MIN / 6–8 MIN','POTATOES FORK-TENDER; CHICKEN NO PINK','ADD SOUP LENTILS + STOCK WHEN READY.'],
 ['HAM & LENTIL SOUP','SOUP POT','ADD SOUP • BOWL 3 • LENTILS + SEASONING, THEN SOUP • JUG 1 • STOCK. BRING TO BOIL, REDUCE TO STEADY SIMMER.','LOW SIMMER','25–35 MIN','LENTILS TENDER','PARTIALLY COVER POT • LEAVE A GAP. STIR OCCASIONALLY.'],
 ['CHEESY COTTAGE PIE','SKILLET','ADD COTTAGE PIE • BOWL 2 • FILLING VEGETABLES, THEN SMALL BOWL 3 • GARLIC. WHISK AND ADD COTTAGE PIE • JUG 1 • GRAVY.','MEDIUM','5 MIN + 3–5 MIN','THICK, GENEROUS GRAVY','DRAIN POTATOES AND MAKE MASH.'],
 ['CHICKEN + VEG/BROTH BASE','WIDE POT','BROWN DUMPLINGS • PAPER PLATE 1 • CHICKEN USING DUMPLINGS • SMALL BOWL 5 • PAN BUTTER. ADD DUMPLINGS • BOWL 1 • VEGETABLES, THEN GARLIC. POUR DUMPLINGS • JUG 1 • BROTH BASE. ADD 1 SÁZON PACKET AS ACTUAL CHANGE.','MEDIUM-HIGH → MEDIUM-LOW','UNTIL CHICKEN 165°F','CHICKEN COOKED; VEGETABLES TENDER','LEAVE UNCOVERED OR PARTIALLY COVER ONLY AS NEEDED TO CONTROL SIMMER.'],
 ['CHEESY COTTAGE PIE','BOWL / BAKING DISH','MASH POTATOES WITH ACTUAL MASH FINISH. TODAY: HEAVY CREAM REPLACED THE PLANNED FAIRLIFE WHERE APPLICABLE. COMBINE FILLING + MASH FOR TODAY’S FINAL MIXED-DISH ACTUAL.','OFF → 400°F','15–20 MIN BAKE','HOT THROUGH; TOP LIGHTLY BROWNED','TODAY’S FINAL COMPONENT IS WHOLE MIXED COTTAGE PIE.'],
 ['HAM & LENTIL SOUP','SOUP POT','ADD SOUP • PAPER PLATE 1 • HAM FOR FINAL 5 MINUTES.','LOW SIMMER','5 MIN','HAM HOT; LENTILS TENDER','LEAVE PARTIALLY COVERED • GAP.'],
 ['CHICKEN + VEG/BROTH BASE','SCALE','STOP — WEIGH BEFORE COMBINING. WEIGH CHICKEN SEPARATELY FROM BROTH + VEGETABLES.','HEAT OFF','NOW','454 G CHICKEN TOTAL RECORDED; BROTH/VEG SEPARATE','DO NOT ADD DUMPLING TOPPING IF PLAN IS PAUSED.'],
 ['CHICKEN COBBLER','PAUSED / RESERVED','PAUSE RECIPE. KEEP DETWILER’S CHICKEN, IDENTIFIED TOPPING DRY MIX, AND PRE-MEASURED FAIRLIFE AS RESERVED PREP.','NO HEAT','PAUSED','ALL PREP IDENTIFIED + STORED','SAVE EXACT RESTART POINT; DO NOT RETURN RESERVED ITEMS TO GENERAL INVENTORY.']
];return (cookTimelineMarkup?.()||'').split('</div>').filter(Boolean).slice(0,8).map((x,i)=>[`STEP ${i+1}`,'COOK STATION',x.replace(/<[^>]+>/g,' ').trim(),'AS LISTED','AS LISTED','USE DONENESS CUE','CONTINUE SAFE PARALLEL ACTION'])}
function v7Stage4(){let rows=v7TimelineRows(),sess=v7Session();let late=sess.lateMinutes||0,plan=sess.planAction||'';return `<section class="cook-v7-control"><h3>I’M RUNNING LATE</h3><div class="cook-v7-pillrow">${[15,30,45,60].map(n=>`<button class="tinybtn ${late===n?'on':''}" data-v7-late-min="${n}">${n} MIN${late===n?' ✓':''}</button>`).join('')}</div>${late?`<div class="cook-v7-warn"><b>${late} MINUTES LATE</b><br>FINISH NOW: FOOD-SAFETY-CRITICAL + ALREADY-STARTED FOOD.<br>SIMPLIFY: NONESSENTIAL FINISHING STEPS.<br>PAUSE: SAFE PREPPED COMPONENTS THAT CAN BE STORED IDENTIFIED.<br>DO NOT START: A REMAINING RECIPE/COMPONENT THAT CANNOT BE SAFELY FINISHED IN THE TIME LEFT.</div>`:''}</section><section class="cook-v7-control"><h3>CHANGE PLAN</h3><div class="cook-v7-pillrow">${['PAUSE RECIPE','SKIP REMAINING COMPONENT','CHANGE INGREDIENT','ADD INGREDIENT','REMOVE INGREDIENT','CHANGE COOKING METHOD'].map(v=>`<button class="tinybtn ${plan===v?'on':''}" data-v7-plan="${esc(v)}">${esc(v)}${plan===v?' ✓':''}</button>`).join('')}</div>${plan?`<div class="cook-v7-ok">PLANNED RECIPE REMAINS SAVED • ACTUAL CHANGE: ${esc(plan)}</div>`:''}</section><div class="cook-v7-timeline" style="margin-top:10px">${rows.map((r,i)=>`<div class="cook-v7-step"><h4>${i+1}. ${esc(r[0])}</h4><div class="cook-v7-grid"><div><small>PAN / POT / APPLIANCE</small>${esc(r[1])}</div><div><small>HEAT / TEMP</small>${esc(r[3])}</div><div style="grid-column:1/-1"><small>ADD / DO</small>${esc(r[2])}</div><div><small>TIME</small>${esc(r[4])}</div><div><small>DONE WHEN</small>${esc(r[5])}</div><div style="grid-column:1/-1"><small>WHILE THIS COOKS</small>${esc(r[6])}</div></div>${/SIMMER|BAKE|MIN/.test(r[4])?`<button class="tinybtn" data-v7-timer="${esc(r[0])}|${esc(r[4])}">START LABELED TIMER</button>`:''}</div>`).join('')}</div>`}
function v7SeedOct1(){let v=v7Ensure();if(Number(v.sessions['2026-10-01']?.handoffVersion||0)>=9)return;let sess=v.sessions['2026-10-01']={date:'2026-10-01',stage:5,checks:{},handoffApplied:true,handoffVersion:9,batchActuals:{'Ham & Lentil Soup':{finishedGrams:1233,status:'ACTUAL'},'Chicken + Veg/Broth Base':{finishedGrams:1133,status:'ACTUAL',chickenGrams:454,brothVegGrams:679,brothVegStatus:'CALCULATED / APPROX.'},'Cheesy Cottage Pie':{finishedGrams:1347,status:'ACTUAL'}},inventoryCommitted:false,inventoryStatus:'KNOWN OCT 1 CORRECTIONS APPLIED • FULL INGREDIENT-BY-INGREDIENT RECONCILIATION NEEDS ACTUALS',actualPlan:{planned:['Ham & Lentil Soup','Cheesy Cottage Pie','Chicken & Dumplings','Chicken Cobbler'],actual:['Ham & Lentil Soup','Cheesy Cottage Pie','Chicken + Veg/Broth Base'],paused:['Chicken Cobbler']},components:{},portions:{},leftovers:{},reservedPrep:[
 {name:"COBBLER • CHICKEN",recipe:'Chicken Cobbler',amount:'APPROX. 454 G',storage:'REFRIGERATED',state:'RESERVED / PREPPED',restart:'RESUME AT CHICKEN COOK STEP'},
 {name:'COBBLER • TOPPING DRY MIX',recipe:'Chicken Cobbler',amount:'FLOUR + BAKING POWDER + THYME',storage:'KEPT DRY',state:'RESERVED / PREPPED',restart:'USE AS IDENTIFIED TOPPING DRY MIX'},
 {name:'COBBLER • PRE-MEASURED FAIRLIFE',recipe:'Chicken Cobbler',amount:'PRE-MEASURED CUP',storage:'REFRIGERATED',state:'RESERVED / PREPPED',restart:'USE ONLY FOR COBBLER; NOT GENERAL MILK'}]};
 let mk=(id,meal,label,weight,ings)=>({id,meal,label,madeAsPlanned:false,weight,ingredients:ings,saved:true});
 sess.components['soup-main']=mk('soup-main','Ham & Lentil Soup','COMPLETE SOUP',1233,[{name:'PLANNED SOUP INGREDIENTS',actual:'UNRESOLVED / NEEDS ACTUAL WHERE NOT CONFIRMED',timing:'BEFORE / DURING COOKING',source:'PLANNED REFERENCE'}]);
 sess.components['base-chicken']=mk('base-chicken','Chicken + Veg/Broth Base','CHICKEN',454,[{name:"DETWEILER’S CHICKEN",actual:'454 G',timing:'BEFORE COOKING',source:'INVENTORY'}]);
 sess.components['base-brothveg']=mk('base-brothveg','Chicken + Veg/Broth Base','BROTH + VEGETABLES • CALCULATED / APPROX.',679,[{name:'PLANNED VEGETABLES + BROTH',actual:'UNRESOLVED / NEEDS ACTUAL WHERE NOT CONFIRMED',timing:'BEFORE / DURING COOKING',source:'PLANNED REFERENCE'},{name:'SÁZON',actual:'1 PACKET',timing:'DURING COOKING',source:'INVENTORY'}]);
 sess.components['pie-main']=mk('pie-main','Cheesy Cottage Pie','COMPLETE MIXED COTTAGE PIE',1347,[{name:'LIQUID AMINOS',actual:'44 G',timing:'DURING COOKING',source:'INVENTORY'},{name:'HEAVY CREAM',actual:'USED IN MASH IN PLACE OF PLANNED FAIRLIFE WHERE APPLICABLE',timing:'AFTER BOILING / DURING MASH',source:'INVENTORY'},{name:'OTHER PLANNED COTTAGE PIE INGREDIENTS',actual:'UNRESOLVED / NEEDS ACTUAL WHERE NOT CONFIRMED',timing:'AS PLANNED',source:'PLANNED REFERENCE'}]);
 sess.portions={
  'soup-1':{meal:'Ham & Lentil Soup',number:1,components:{'soup-main':590},assignment:{date:'2026-10-02',meal:'DINNER',storage:'FRIDGE'},labelApplied:false,saved:true},
  'soup-2':{meal:'Ham & Lentil Soup',number:2,components:{'soup-main':590},assignment:null,labelApplied:false,saved:true,assignmentStatus:'UNRESOLVED / NEEDS ACTUAL'},
  'base-1':{meal:'Chicken + Veg/Broth Base',number:1,components:{'base-chicken':220,'base-brothveg':315},assignment:{date:'2026-10-01',meal:'DINNER',storage:'FRIDGE'},labelApplied:false,saved:true},
  'base-2':{meal:'Chicken + Veg/Broth Base',number:2,components:{'base-chicken':220,'base-brothveg':315},assignment:{date:'2026-10-04',meal:'DINNER',storage:'FREEZER'},labelApplied:false,saved:true},
  'pie-1':{meal:'Cheesy Cottage Pie',number:1,components:{'pie-main':653},assignment:{date:'2026-10-01',meal:'LUNCH',storage:'FRIDGE'},labelApplied:false,saved:true},
  'pie-2':{meal:'Cheesy Cottage Pie',number:2,components:{'pie-main':653},assignment:{date:'2026-10-03',meal:'DINNER',storage:'FREEZER'},labelApplied:false,saved:true}
 };
 sess.leftovers={'soup-main':{grams:53,resolution:''},'base-chicken':{grams:14,resolution:''},'base-brothveg':{grams:49,resolution:''},'pie-main':{grams:41,resolution:''}};
 v7ApplyInventoryCorrections();save();
}
function v7ApplyInventoryCorrections(){
 let set=(cat,rx,qty,notes)=>{let arr=state.inventory?.[cat]||[],hits=arr.filter(x=>rx.test(String(x.name||'')));if(hits.length)hits.forEach(x=>{x.qty=qty;if(notes)x.notes=notes});else if(qty!=='0 — OUT')arr.push({name:String(rx).replace(/\W+/g,' ').trim(),qty,notes:notes||''})};
 ['Fridge','Pantry'].forEach(cat=>set(cat,/chicken (?:stock|broth)/i,'0 — OUT','OCT 1 LIVE COOK ACTUAL • CHICKEN STOCK/BROTH USED UP'));
 set('Fridge',/^Butter$/i,'~178 g','OCT 1 LIVE COOK ACTUAL');
 set('Fridge',/^Fairlife milk$/i,'GENERAL REMAINING AMOUNT UNRESOLVED','OCT 1 CURRENT TRUTH • PRE-MEASURED COBBLER FAIRLIFE CUP IS RESERVED PREP AND IS NOT GENERAL MILK INVENTORY.');
 set('Fridge',/Liquid Aminos — partial/i,'0 — EMPTY','OCT 1 LIVE COOK ACTUAL • PARTIAL BOTTLE EMPTIED');
 set('Pantry',/^Liquid Aminos$/i,'473 mL • FULL','OCT 1 LIVE COOK ACTUAL • FULL BACKUP REMAINS');
 set('Pantry',/^AP flour$/i,'~1/4 cup LOOSE','PREPARED COBBLER DRY MIX IS RESERVED PREP AND IS NOT INCLUDED IN THIS LOOSE FLOUR AMOUNT');
 let p=state.inventory.Pantry||[];if(!p.some(x=>/^Potatoes$/i.test(x.name||'')))p.push({name:'Potatoes',qty:'0 — OUT',notes:'OCT 1 LIVE COOK ACTUAL'});else p.filter(x=>/^Potatoes$/i.test(x.name||'')).forEach(x=>x.qty='0 — OUT');
}
v7ApplyInventoryCorrections();
function v7Session(){let v=v7Ensure(),k=selectedKey();if(k==='2026-10-01')v7SeedOct1();if(!v.sessions[k])v.sessions[k]={date:k,stage:1,checks:{},components:{},portions:{},leftovers:{},reservedPrep:[]};return v.sessions[k]}
function v7ExpectedContainers(sess){if(selectedKey()==='2026-10-01')return 6;let n=0;for(let rn of v7SessionNames())n+=Math.max(1,(cookAssignments(rn)||[]).length||2);return n}
function v7GenericComponents(){let sess=v7Session();if(Object.keys(sess.components||{}).length)return sess.components;for(let rn of v7SessionNames()){let r=MEAL.recipes?.[rn];let id=rn.toLowerCase().replace(/[^a-z0-9]+/g,'-');sess.components[id]={id,meal:rn,label:`${rn.toUpperCase()} • COMPLETE MEAL`,madeAsPlanned:false,weight:'',ingredients:(r?.ingredients||[]).map((x,i)=>({name:x,actual:'',timing:'AS PLANNED',source:'PLANNED',plannedIndex:i})),saved:false}}return sess.components}
function v7CompMacros(c){let m=emptyMacros(),known=true;for(let ing of c.ingredients||[]){if(ing.removed)continue;let n=ing.nutrition;if(n){let g=Number(ing.grams)||0,sg=Number(n.servingGrams)||100,sc=g>0&&sg>0?g/sg:1;for(let k of ['calories','protein','carbs','fat','fiber'])m[k]=(m[k]||0)+(Number(n[k])||0)*sc}else if(Number.isInteger(ing.plannedIndex)){let b=ingredientMacroBase(c.meal,ing.plannedIndex);if(b)m=addMacros(m,b);else known=false}else known=false}return {macros:roundMacros(m),known}}
function v7Stage5(){let sess=v7Session(),comps=v7GenericComponents();let batch=sess.batchActuals||{};return `${Object.keys(batch).length?`<section class="card soft"><h3>ACTUAL FINISHED BATCH WEIGHTS</h3>${Object.entries(batch).map(([n,x])=>`<div class="cook-v7-ok"><b>${esc(n.toUpperCase())}</b> • ${Number(x.finishedGrams).toFixed(0)} G • ${esc(x.status||'ACTUAL')}${x.chickenGrams?`<br>CHICKEN: ${x.chickenGrams} G ACTUAL • BROTH + VEGETABLES: ~${x.brothVegGrams} G ${esc(x.brothVegStatus||'')}`:''}</div>`).join('')}</section>`:''}${Object.values(comps).map(c=>{let targets=v7ComponentTargetCount(c.meal),sug=Number(c.weight)>0?Number(c.weight)/targets:0,cm=v7CompMacros(c);return `<details class="cook-v7-component"><summary><span>${esc(c.meal.toUpperCase())} • ${esc(c.label.toUpperCase())}</span><span>${c.saved?'SAVED ✓':'EDIT ACTUALS'}</span></summary><div class="cook-v7-component-body"><label class="cook-v7-check"><input type="checkbox" data-v7-planned="${esc(c.id)}" ${c.madeAsPlanned?'checked':''}><span>MADE AS INSTRUCTED / PLANNED</span></label><p class="cook-v7-mini">CHECKING THIS POPULATES THE PLANNED RECORD. EVERYTHING REMAINS EDITABLE.</p>${(c.ingredients||[]).map((ing,i)=>`<div class="cook-v7-ing"><label class="cook-v7-wide">INGREDIENT<input data-v7-ing="${esc(c.id)}|${i}|name" value="${esc(ing.name||'')}"></label><label>ACTUAL AMOUNT<input data-v7-ing="${esc(c.id)}|${i}|actual" value="${esc(ing.actual||'')}"></label><label>WHEN ADDED<select data-v7-ing="${esc(c.id)}|${i}|timing"><option ${ing.timing==='BEFORE COOKING'?'selected':''}>BEFORE COOKING</option><option ${ing.timing==='DURING COOKING'?'selected':''}>DURING COOKING</option><option ${ing.timing==='AFTER COOKING'?'selected':''}>AFTER COOKING</option><option ${ing.timing==='AS PLANNED'?'selected':''}>AS PLANNED</option></select></label><button class="tinybtn" data-v7-remove-ing="${esc(c.id)}|${i}">REMOVE</button></div>`).join('')}<div class="cook-v7-pillrow"><button class="tinybtn" data-v7-add-ing="${esc(c.id)}|inventory">+ INVENTORY</button><button class="tinybtn" data-v7-add-ing="${esc(c.id)}|generic">+ GENERIC</button><button class="tinybtn" data-v7-add-ing="${esc(c.id)}|lookup">+ NUTRITION LOOKUP</button></div><div class="cook-v7-divider"></div><label><b>ACTUAL COOKED / FINISHED WEIGHT</b><input type="number" min="0" step="1" data-v7-weight="${esc(c.id)}" value="${esc(c.weight??'')}" placeholder="0 G"></label><div class="cook-v7-suggest"><b>${targets} CONTAINER${targets===1?'':'S'}</b><br>${Number(c.weight)>0?`SUGGESTED PER CONTAINER: ${(Number(c.weight)/targets).toFixed(1)} G`:'ENTER FINISHED WEIGHT TO CALCULATE SUGGESTED GRAMS'}<br><span class="cook-v7-mini">SUGGESTION ONLY. ACTUAL PACKED GRAMS WIN.</span></div><div class="cook-v7-mini">${cm.known?`CURRENT COMPONENT MACROS: ${macroLine(cm.macros)} • DENSITY CALCULATES FROM ${Number(c.weight)||0} G FINISHED WEIGHT.`:'MACROS WILL FINALIZE WHEN EVERY ACTUAL INGREDIENT HAS A NUTRITION BASIS.'}</div><button class="btn primary" data-v7-save-comp="${esc(c.id)}">${c.saved?'COMPONENT SAVED ✓':'SAVE COMPONENT'}</button></div></details>`}).join('')}${(sess.reservedPrep||[]).length?`<section class="card soft"><h3>PAUSED / RESERVED PREP</h3><p class="muted">PREPPED FOOD STAYS RESERVED UNTIL YOU CHOOSE WHAT HAPPENS TO IT.</p>${sess.reservedPrep.map((x,i)=>`<div class="cook-v7-warn"><b>${esc(x.name)}</b><br>${esc(x.amount)} • ${esc(x.storage)}<br><b>${esc(x.state)}</b><br><span class="cook-v7-mini">RESTART: ${esc(x.restart)}</span><div class="cook-v7-pillrow">${['SAVE FOR NEXT COOK','RETURN TO GENERAL INVENTORY WHEN APPROPRIATE','REASSIGN','DISCARD'].map(a=>`<button class="tinybtn ${x.resolution===a?'on':''}" data-v7-prep-action="${i}|${esc(a)}">${esc(a)}${x.resolution===a?' ✓':''}</button>`).join('')}</div></div>`).join('')}</section>`:''}`}
function v7ComponentTargetCount(meal){if(selectedKey()==='2026-10-01')return 2;let rn=meal==='Chicken + Veg/Broth Base'?'Chicken & Dumplings':meal;return Math.max(1,(cookAssignments(rn)||[]).length||2)}
function v7PortionGroups(){let sess=v7Session(),arr=Object.entries(sess.portions||{});if(!arr.length){let comps=Object.values(v7GenericComponents()).filter(c=>c.saved);let meals=[...new Set(comps.map(c=>c.meal))];for(let meal of meals){let count=v7ComponentTargetCount(meal);for(let i=0;i<count;i++){let rn=meal==='Chicken + Veg/Broth Base'?'Chicken & Dumplings':meal,ass=(cookAssignments(rn)||[])[i]||null;sess.portions[`${meal}|${i+1}`]={meal,number:i+1,components:{},assignment:ass,labelApplied:false,saved:false}}}arr=Object.entries(sess.portions)}let grouped={};arr.forEach(([k,p])=>(grouped[p.meal]||(grouped[p.meal]=[])).push([k,p]));return grouped}
function v7PortionMacros(p){let sess=v7Session(),m=emptyMacros(),known=true;for(let [id,g] of Object.entries(p.components||{})){let c=sess.components?.[id];if(!c||!(Number(c.weight)>0)){known=false;continue}let cm=v7CompMacros(c);if(!cm.known){known=false;continue}let scale=Number(g)/Number(c.weight);m=addMacros(m,cm.macros,scale)}for(let x of p.extras||[]){let n=x.nutrition;if(!n){known=false;continue}let g=Number(x.grams)||0,sg=Number(n.servingGrams)||100,sc=sg>0?g/sg:0;for(let k of ['calories','protein','carbs','fat','fiber'])m[k]=(m[k]||0)+(Number(n[k])||0)*sc}return {macros:roundMacros(m),known}}
function v7Stage6(){let sess=v7Session(),groups=v7PortionGroups();return `${Object.entries(groups).map(([meal,rows])=>`<section class="card soft"><h3>${esc(meal.toUpperCase())}</h3>${rows.map(([key,p])=>{let total=Object.values(p.components||{}).reduce((a,b)=>a+(Number(b)||0),0),lab=physicalLabel(p.assignment),pm=v7PortionMacros(p);return `<div class="cook-v7-portion"><div class="cook-v7-label-context">PORTION ${p.number} • ACTUAL PACKED ${total?total.toFixed(0)+' G':'—'}</div>${Object.values(sess.components||{}).filter(c=>c.saved&&c.meal===meal).map(c=>`<label>${esc(c.label.toUpperCase())} • ACTUAL G <span class="cook-v7-mini">SUGGESTED ${Number(c.weight)>0?(Number(c.weight)/v7ComponentTargetCount(c.meal)).toFixed(1):'—'} G</span><input type="number" min="0" step="1" data-v7-portion="${esc(key)}|${esc(c.id)}" value="${esc(p.components?.[c.id]??'')}"></label>`).join('')}${p.extra?'<div class="cook-v7-warn">EXTRA PORTION • ASSIGN EATING DAY / MEAL / STORAGE BEFORE LABELING.</div>':''}${lab.length?`<div class="cook-v7-label-box">${esc(lab.join('\n'))}</div><button class="tinybtn" data-v7-copy-label="${esc(key)}">COPY LABEL</button><label class="cook-v7-check"><input type="checkbox" data-v7-label-applied="${esc(key)}" ${p.labelApplied?'checked':''}><span>LABEL APPLIED</span></label>`:`<div class="cook-v7-warn">LABEL PENDING • ASSIGN THIS PORTION TO A MEAL-PLAN SLOT FIRST.</div>`}<details class="cook-v7-group"><summary>ADD SOMETHING TO THIS CONTAINER</summary><div class="cook-v7-group-body"><div class="cook-v7-pillrow"><button class="tinybtn" data-v7-extra-add="${esc(key)}|inventory">+ INVENTORY</button><button class="tinybtn" data-v7-extra-add="${esc(key)}|generic">+ GENERIC</button><button class="tinybtn" data-v7-extra-add="${esc(key)}|lookup">+ NUTRITION LOOKUP</button></div>${(p.extras||[]).map((x,i)=>`<div class="cook-v7-ing"><label class="cook-v7-wide">ITEM<input data-v7-extra="${esc(key)}|${i}|name" value="${esc(x.name||'')}"></label><label>GRAMS<input type="number" min="0" step=".1" data-v7-extra="${esc(key)}|${i}|grams" value="${esc(x.grams??'')}"></label><label>SOURCE<input value="${esc((x.source||'GENERIC').toUpperCase())}" disabled></label><button class="tinybtn" data-v7-extra-remove="${esc(key)}|${i}">REMOVE</button></div>`).join('')}</div></details><div class="macro-preview"><b>ACTUAL CONTAINER MACROS</b><br>${pm.known?macroLine(pm.macros):'PENDING COMPLETE COMPONENT / ADDITION NUTRITION'}</div><button class="btn primary" data-v7-save-portion="${esc(key)}">SAVE CONTAINER → INVENTORY</button></div>`}).join('')}</section>`).join('')}${v7LeftoversMarkup()}`}
function v7ReconcileLeftovers(){let s=v7Session();s.leftovers=s.leftovers||{};for(let [id,c] of Object.entries(s.components||{})){if(!(Number(c.weight)>0))continue;let assigned=0;for(let p of Object.values(s.portions||{}))assigned+=Number(p.components?.[id])||0;let grams=Math.max(0,Number(c.weight)-assigned),prev=s.leftovers[id]||{};s.leftovers[id]={grams:+grams.toFixed(1),resolution:grams>0?(prev.resolution||''):''}}return s.leftovers}
function v7LeftoversMarkup(){let s=v7Session();v7ReconcileLeftovers();let rows=Object.entries(s.leftovers||{}).filter(([id,x])=>Number(x.grams)>0);if(!rows.length)return '<section class="card"><div class="cook-v7-ok">ALL FINISHED COMPONENT GRAMS ARE ACCOUNTED FOR ✓</div></section>';return `<section class="card"><h3>UNPORTIONED FOOD REMAINING</h3><p class="muted">NOTHING DISAPPEARS. RESOLVE EVERY DIFFERENCE.</p>${rows.map(([id,x])=>{let c=s.components?.[id];return `<div class="cook-v7-leftover"><b>${esc((c?.meal||'COMPONENT').toUpperCase())} • ${esc((c?.label||id).toUpperCase())}</b><br>${Number(x.grams||0).toFixed(0)} G UNALLOCATED<div class="cook-v7-pillrow">${['EXTRA CONTAINER','ATE / TASTED','DISCARDED','OTHER'].map(v=>`<button class="tinybtn" data-v7-leftover="${esc(id)}|${esc(v)}">${esc(v)}${x.resolution===v?' ✓':''}</button>`).join('')}</div></div>`}).join('')}</section>`}
function v7Stage7(){let s=v7Session(),problems=[];for(let c of Object.values(s.components||{}))if(c.saved&&!(Number(c.weight)>0))problems.push(`${c.label}: ACTUAL FINISHED WEIGHT MISSING`);for(let [k,p] of Object.entries(s.portions||{})){if(!p.saved)problems.push(`${p.meal} PORTION ${p.number}: CONTAINER NOT SAVED`);if(p.assignment){let l=physicalLabel(p.assignment);if(!l.length)problems.push(`${p.meal} PORTION ${p.number}: LABEL INVALID`);if(!p.labelApplied)problems.push(`${p.meal} PORTION ${p.number}: LABEL NOT MARKED APPLIED`)}else problems.push(`${p.meal} PORTION ${p.number}: EATING SLOT / LABEL NOT ASSIGNED`)}for(let [id,x] of Object.entries(s.leftovers||{}))if(Number(x.grams)>0&&!x.resolution)problems.push(`${s.components?.[id]?.label||id}: ${x.grams} G UNALLOCATED FOOD NOT RESOLVED`);if((s.reservedPrep||[]).some(x=>!x.resolution))problems.push('UNRESOLVED PREP REMAINS • CHOOSE SAVE FOR NEXT COOK / RETURN / REASSIGN / DISCARD');let ok=!problems.length;return `<div class="${ok?'cook-v7-ok':'cook-v7-warn'}">${ok?'COOKING COMPLETE ✓':`COOKING NOT COMPLETE • ${problems.length} ITEM${problems.length===1?'':'S'} NEED ATTENTION`}</div>${problems.map(x=>`<div class="cook-v7-warn">${esc(x)}</div>`).join('')}<div class="cook-v7-divider"></div><div class="cook-v7-audit">${['ALL COOKED FOOD ACCOUNTED FOR','ALL COMPONENTS HAVE ACTUAL FINISHED WEIGHTS','ALL PORTIONS USE ACTUAL PACKED WEIGHTS','UNALLOCATED FOOD RESOLVED','LABELS VALIDATED + GROUPED UNDER CORRECT MEAL','FRIDGE / FREEZER LOCATIONS RECORDED','KNOWN INVENTORY CORRECTIONS APPLIED • UNKNOWN ACTUAL USE STAYS UNRESOLVED','PAUSED PREP PRESERVED','ACTUAL MACROS SAVED','NO UNIDENTIFIED PREP REMAINS'].map(x=>`<div class="${ok?'cook-v7-ok':'cook-v7-mini'}">${ok?'✓ ':''}${x}</div>`).join('')}</div>${ok?'<button class="btn primary" data-v7-complete>COOKING COMPLETE ✓</button>':''}`}
function cookCanonicalV7(){let names=v7SessionNames();if(!names.length)return hero('Cooking',DAYS[state.day])+back('Food')+`<section class="card"><p>NO COOKING SCHEDULED TODAY.</p></section>`;let s=v7Session(),stage=Number(s.stage)||1,stageMarkup=[['GET EVERYTHING OUT',()=>v7Stage1(names)],['PREP + MEASURE EVERYTHING',()=>v7Stage2()],['READY TO COOK',()=>v7Stage3()],['COOK ALL MEALS TOGETHER',()=>v7Stage4()],['MEASUREMENTS + COMPONENTS',()=>v7Stage5()],['PORTION + STORE',()=>v7Stage6()],['COOKING COMPLETE',()=>v7Stage7()]];return hero('Cooking',DAYS[state.day])+back('Food')+`<section class="card soft"><h2>PERMANENT COOKING LIMIT</h2><p><b>NO OVEN RECIPES • EXACTLY 2 RECIPES PER FUTURE COOK DAY • 90 MINUTES ALL-IN MAXIMUM.</b></p><p class="muted">THE 90-MINUTE CLOCK INCLUDES GET EVERYTHING OUT, PREP, COOKING, MEASUREMENTS, PORTIONING, LABELS, STORAGE + BASIC CLEANUP.</p></section><section class="card"><div class="section-head"><div><h2>TODAY’S COOK</h2><p>PHYSICAL COOKING WORKFLOW • ONE CURRENT STAGE AT A TIME.</p><small class="muted">OCT 1 FULL HANDOFF • CONSOLIDATED</small></div></div>${v7RecipeCards(names)}<div class="cook-v7-steps">${stageMarkup.map((x,i)=>`<details class="cook-v7-stage" ${stage===i+1?'open':''}><summary><span>${i+1}. ${x[0]}</span><span>${stage>i+1?'DONE / REOPEN':stage===i+1?'CURRENT':'UP NEXT'}</span></summary><div class="cook-v7-body">${x[1]()}</div></details>`).join('')}</div></section>`}

function v7FindComp(id){return v7Session().components?.[id]}
function v7FindPortion(key){return v7Session().portions?.[key]}
document.addEventListener('change',e=>{let el=e.target,s=v7Session();if(el.dataset.v7Check!==undefined){s.checks=s.checks||{};s.checks[el.dataset.v7Check]=!!el.checked;save();return}if(el.dataset.v7Planned!==undefined){let c=v7FindComp(el.dataset.v7Planned);if(c){c.madeAsPlanned=!!el.checked;save();render()}return}if(el.dataset.v7Ing!==undefined){let [id,i,f]=el.dataset.v7Ing.split('|'),c=v7FindComp(id);if(c?.ingredients?.[+i]){c.ingredients[+i][f]=el.value;save()}return}if(el.dataset.v7Weight!==undefined){let c=v7FindComp(el.dataset.v7Weight);if(c){c.weight=Number(el.value)||'';c.saved=false;save();render()}return}if(el.dataset.v7Portion!==undefined){let [key,id]=el.dataset.v7Portion.split('|'),p=v7FindPortion(key);if(p){p.components=p.components||{};p.components[id]=Number(el.value)||0;p.saved=false;save();render()}return}if(el.dataset.v7LabelApplied!==undefined){let p=v7FindPortion(el.dataset.v7LabelApplied);if(p){p.labelApplied=!!el.checked;save()}return}if(el.dataset.v7Extra!==undefined){let [key,i,f]=el.dataset.v7Extra.split('|'),p=v7FindPortion(key);if(p?.extras?.[+i]){p.extras[+i][f]=el.value;save()}return}});
document.addEventListener('click',async e=>{let b=e.target.closest?.('button');if(!b)return;let s=v7Session();if(b.dataset.v7LateMin!==undefined){s.lateMinutes=Number(b.dataset.v7LateMin)||0;save();render();return}if(b.dataset.v7Plan!==undefined){s.planAction=b.dataset.v7Plan;save();render();return}if(b.dataset.v7Start!==undefined||b.dataset.v7StartAnyway!==undefined){s.stage=4;s.startedAnyway=b.dataset.v7StartAnyway!==undefined;save();render();return}if(b.dataset.v7Late!==undefined){uiSheet={type:'confirm',title:"I’M RUNNING LATE",message:'CHOOSE HOW MUCH TIME YOU LOST: 15 / 30 / 45 / 60 MINUTES. FINISH FOOD-SAFETY-CRITICAL AND MOST-COMPLETE DISHES FIRST; PAUSE WHAT HAS NOT SAFELY STARTED.',action:'noop',confirmText:'OK'};render();return}if(b.dataset.v7Change!==undefined){showToast('PLANNED RECIPE STAYS SAVED. PAUSE / SKIP / CHANGE ACTUALS IN COMPONENTS; ACTUAL FOOD DRIVES MACROS + INVENTORY.','CHANGE PLAN');return}if(b.dataset.v7Timer!==undefined){let [name,time]=b.dataset.v7Timer.split('|');showToast(`${name.toUpperCase()} • ${time.toUpperCase()}`,'LABELED TIMER');return}if(b.dataset.v7SaveComp!==undefined){let c=v7FindComp(b.dataset.v7SaveComp);if(c){if(!(Number(c.weight)>0)){showToast('ENTER THE ACTUAL FINISHED COMPONENT WEIGHT FIRST.','WEIGHT REQUIRED');return}c.saved=true;c.savedAt=new Date().toISOString();save();render()}return}if(b.dataset.v7AddIng!==undefined){let [id,source]=b.dataset.v7AddIng.split('|'),c=v7FindComp(id);if(c){let item={name:'',actual:'',timing:'DURING COOKING',source:source.toUpperCase()};if(source==='lookup'){let q=prompt('NUTRITION LOOKUP — PRODUCT NAME OR BARCODE');if(!q)return;let hit=await nutritionLookupV90(q);if(hit){item.name=hit.name;item.nutrition=hit.nutrition;item.source=hit.source||'NUTRITION LOOKUP'}else{showToast('NO LOOKUP RESULT FOUND. YOU CAN STILL ADD IT AS GENERIC.','NOT FOUND')}}c.ingredients=c.ingredients||[];c.ingredients.push(item);c.saved=false;save();render()}return}if(b.dataset.v7RemoveIng!==undefined){let [id,i]=b.dataset.v7RemoveIng.split('|'),c=v7FindComp(id);if(c?.ingredients?.[+i]){c.ingredients[+i].removed=true;c.ingredients.splice(+i,1);c.saved=false;save();render()}return}if(b.dataset.v7ExtraAdd!==undefined){let [key,source]=b.dataset.v7ExtraAdd.split('|'),p=v7FindPortion(key);if(p){let item={name:'',grams:'',source:source.toUpperCase()};if(source==='lookup'){let q=prompt('NUTRITION LOOKUP — PRODUCT NAME OR BARCODE');if(!q)return;let hit=await nutritionLookupV90(q);if(hit){item.name=hit.name;item.nutrition=hit.nutrition;item.source=hit.source||'NUTRITION LOOKUP'}}p.extras=p.extras||[];p.extras.push(item);p.saved=false;save();render()}return}if(b.dataset.v7ExtraRemove!==undefined){let [key,i]=b.dataset.v7ExtraRemove.split('|'),p=v7FindPortion(key);if(p?.extras?.[+i]){p.extras.splice(+i,1);p.saved=false;save();render()}return}if(b.dataset.v7CopyLabel!==undefined){let p=v7FindPortion(b.dataset.v7CopyLabel),txt=physicalLabel(p?.assignment).join('\n');if(txt){try{await navigator.clipboard.writeText(txt);showToast('ONLY THE PHYSICAL LABEL LINES WERE COPIED.','LABEL COPIED')}catch(e){showToast(txt,'COPY THIS LABEL')}}return}if(b.dataset.v7SavePortion!==undefined){let key=b.dataset.v7SavePortion,p=v7FindPortion(key);if(p){let grams=Object.values(p.components||{}).reduce((a,x)=>a+(Number(x)||0),0);if(!(grams>0)){showToast('ENTER THE ACTUAL GRAMS OF THE SAVED COMPONENTS IN THIS CONTAINER.','ACTUAL GRAMS REQUIRED');return}p.saved=true;p.savedAt=new Date().toISOString();let label=physicalLabel(p.assignment);let idx=(state.inventory.Containers||[]).findIndex(x=>x.v7PortionKey===selectedKey()+'|'+key);let rec={name:`${p.meal} • PORTION ${p.number}`,qty:`${grams.toFixed(0)} G • ${(p.assignment?.storage||'UNASSIGNED').toUpperCase()}`,storage:p.assignment?.storage||'',eat:p.assignment?.date||'',meal:p.assignment?.meal||'',labelRows:label,recipe:p.meal,created:selectedKey(),actualPackedGrams:grams,v7PortionKey:selectedKey()+'|'+key,macros:v7PortionMacros(p).macros,nutritionComplete:v7PortionMacros(p).known};if(idx>=0)state.inventory.Containers[idx]=rec;else state.inventory.Containers.push(rec);save();render()}return}if(b.dataset.v7Leftover!==undefined){let [id,res]=b.dataset.v7Leftover.split('|');if(s.leftovers?.[id]){s.leftovers[id].resolution=res;save();render()}return}if(b.dataset.v7PrepAction!==undefined){let [i,action]=b.dataset.v7PrepAction.split('|'),x=s.reservedPrep?.[+i];if(x){x.resolution=action;if(action==='SAVE FOR NEXT COOK')x.state='RESERVED / PREPPED';else if(action==='RETURN TO GENERAL INVENTORY WHEN APPROPRIATE')x.state='RETURNED';else if(action==='REASSIGN')x.state='RESERVED / PREPPED • REASSIGNMENT NEEDED';else if(action==='DISCARD')x.state='DISCARDED';state.inventoryLifecycle[selectedKey()+'|reserved|'+i]={name:x.name,state:x.state,action,updatedAt:new Date().toISOString()};save();render()}return}if(b.dataset.v7Complete!==undefined){s.completedAt=new Date().toISOString();s.stage=7;save();showToast('COOKING SESSION RECONCILED + SAVED.','COOKING COMPLETE ✓');render();return}});
(function v11PermanentInventoryMigration(){v7Ensure();const mark='migration|oct1PermanentInventoryTruthV11|2026-10-01';if(!state.checks[mark]){v7SeedOct1();v7ApplyInventoryCorrections();state.checks[mark]=true;save()}})();
window.__EMMELLI_COOK_BUILD='OCT1-PERMANENT-HANDOFF-V11-2026-10-01';

})();
